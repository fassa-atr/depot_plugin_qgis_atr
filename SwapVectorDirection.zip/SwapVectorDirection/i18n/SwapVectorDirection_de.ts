<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0">
<context>
    <name>SwapVectorDirection</name>
    <message>
        <location filename="../SwapVectorDirection.py" line="181"/>
        <source>&amp;Swap Vector Direction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SwapVectorDirection.py" line="171"/>
        <source>Reverse direction of geometry</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>SwapVectorDirectionDialogBase</name>
    <message>
        <location filename="../SwapVectorDirection_dialog_base.ui" line="14"/>
        <source>Swap Vector Direction</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../SwapVectorDirection_dialog_base.ui" line="42"/>
        <source>Crée par Christophe MAGINOT</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
