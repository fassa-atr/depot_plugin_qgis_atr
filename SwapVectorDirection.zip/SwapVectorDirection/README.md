SwapVectorDirection
===================

Plugin QGIS permettant dinverser le sens d'un vecteur.
Supporte les géométries de type ligne, multi-lignes,ligne 3D, multi-lignes 3D.
