import processing,xlrd,psycopg2,sys,xlwt
from qgis.PyQt.QtCore import *
from qgis.PyQt.QtGui import *
from qgis.core import * 
from qgis.utils import *
from qgis.PyQt.QtWidgets import *
import time
import datetime

#Parameter connexion base
# DB = 'MCD_ADN_sans_ct'
# user = 'postgres'
# MP = 'postgres'
# host = '192.168.30.218'
# port = '5432'
# schema = 'pr_baba_exe_v_20251231'

def function_general_spatialisation_upnview(DB,user,MP,host,port,schema):

    prefix_id_error_UPNview='UPV_'
    now = datetime.datetime.now().strftime("%y%m%d")

    #Declaration de la variable pour les messages derreur
    w = QWidget()

    #Connexion a la base
    try:
        connection = psycopg2.connect(user=user,password=MP,host=host,port=port,database=DB)
    except(Exception, psycopg2.DatabaseError) as error:
        QMessageBox.warning(w, "Message de connexion de la base", 'Erreur de connexion de la base')


    #Function pour la progession bar
    def progress_bar(name_etape):
        prog = QProgressDialog(name_etape + ' : Veillez Patienter', 'Cancel', 0, 100)
        prog.setWindowModality(Qt.WindowModal)
        prog.setMinimumDuration(1)
        return prog
        
    def progress_processing(index,count_entite,progress_dialog):
        f = int(index + 1)
        pcnt = int(f/count_entite * 100/1)
        progress_dialog.setValue(pcnt)
        
    #Function pour executer une requete sql dans la base
    def function_execute_requete(requete_execute,req_fetch,connection):
        curs=connection.cursor()
        try:
            curs.execute(requete_execute)
            if req_fetch:
                data_req=[row for row in curs.fetchall()]
                if data_req:
                    return data_req
        except(Exception, psycopg2.DatabaseError) as error:
            QMessageBox.warning(w, "Message dexecution de requete", 'Requete Non Executer : '+unicode(requete_execute))
        curs.close()
        

    def function_spatialisation_upnview():
        Fichier_upnview=QFileDialog.getOpenFileName(None, "Selectionner le fichier danalyse de Fichier_upnview ", "", "xlsx files (*.xlsx)")
        if Fichier_upnview:
            #Vider les controls realisees par le script
            requete_delete="""delete from """+schema+""".erreur_control_adn where id like 'UPV%';"""
            function_execute_requete(requete_delete,'',connection)
            
            bar_progress=progress_bar('Preparation de la liste des erreurs de upNview')
            xl_workbook = xlrd.open_workbook(Fichier_upnview[0])
            list_sheet_name=xl_workbook.sheet_names()
            len_list_sheet_name=len(list_sheet_name)
            headers = []
            sdata = []
            for index_sheet, sheet in enumerate(list_sheet_name):
                if sheet == 'Rapport Détaillé':
                    xl_sheet = xl_workbook.sheet_by_index(index_sheet)
                    for row in range(9,xl_sheet.nrows):
                        values = []
                        for col in range(xl_sheet.ncols):
                            data = xl_sheet.cell(row,col).value
                            if data:
                                if row == 0:
                                    headers.append(data)
                                else:   
                                    values.append(data)
                        sdata.append(values)
                progress_processing(index_sheet,len_list_sheet_name,bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break
            
            requete="""select 
                    distinct 
                    s.column_name,
                    s.table_schema,
                    s.table_name,
                    'select * from ' || s.table_schema || '.' || s.table_name || ' where ' || s.column_name || 
                    '=' as requete
                from information_schema.columns s
                WHERE 
                    (s.table_schema = '"""+schema+"""' and  s.table_name in 
                    ('t_adresse', 't_cableline','t_cheminement','t_noeud',
                    't_zdep','t_znro','t_zpbo','t_zsro',
                    'vs_elem_ba_lt_st_nd','vs_elem_cl_cb','vs_elem_cs_bp_pt_nd'
                    ,'vs_elem_cd_dm_cm','vs_elem_bp_sf_nd','vs_elem_bp_pt_nd'
                    ,'vs_elem_fo_cb_cl','vs_elem_lv_nd','vs_elem_lt_st_nd'
                    ,'vs_elem_mq_nd','vs_elem_pt_nd','vs_elem_rt_fo_cb_cl'
                    ,'vs_elem_se_nd','vs_elem_st_nd','vs_elem_sf_nd'
                    ,'vs_elem_ti_ba_lt_st_nd'))
            """
            
            list_value_requete=function_execute_requete(requete,'bab',connection)
            dict_tab_view = {
                        "t_baie":"vs_elem_ba_lt_st_nd",
                        "t_cable":"vs_elem_cl_cb",
                        "t_cassette":"vs_elem_cs_bp_pt_nd",
                        "t_conduite":"vs_elem_cd_dm_cm",
                        "t_ebp":"vs_elem_bp_pt_nd",
                        "t_fibre":"vs_elem_fo_cb_cl",
                        "t_love":"vs_elem_lv_nd",
                        "t_ltech":"vs_elem_lt_st_nd",
                        "t_masque":"vs_elem_mq_nd",
                        "t_ptech":"vs_elem_pt_nd",
                        "t_sitetech":"vs_elem_st_nd",
                        "t_suf":"vs_elem_sf_nd",
                        "t_ropt":"vs_elem_rt_fo_cb_cl",
                        "t_siteemission":"vs_elem_se_nd",
                        "t_tiroir":"vs_elem_ti_ba_lt_st_nd"
                    }
            count=0
            for index_upnview, var_upnview in enumerate(sdata):
                #print (var_upnview[2])
                requete_insertion_finale='-1'
                for index_req, var_req in enumerate(list_value_requete):
                    #print (var_req[0],';',var_req[1],';',var_req[2],';',var_req[3] )
                    if var_upnview[2] == var_req[0]:
                        count += 1
                        id_code=prefix_id_error_UPNview+now+'_'+str(count).zfill(4)
                        if var_upnview[1] in ('t_adresse', 't_cableline','t_cheminement','t_noeud',\
                            't_zdep','t_znro','t_zpbo','t_zsro'):
                            requete_correspondance=var_req[3].replace('*', "'"+id_code+"'"+','+"'"+\
                                var_upnview[8]+"'"+','+"'"+' UPV Pas de zone sro trouvee' + "'" +','+ 'st_buffer('+ 'geom' +\
                                ',0.1)' ) + "'" + str(var_upnview[5]) + "'"
                            req_insert_correspondance=\
                                'INSERT INTO '+schema+'.erreur_control_adn ' + \
                                requete_correspondance
                            requete_insertion_finale=req_insert_correspondance
                            #function_execute_requete(req_insert_correspondance,'',connection)
                        
                        for key_dict, value_dict in dict_tab_view.items():
                            if var_upnview[1] == key_dict and var_req[2] == value_dict:
                                requete_correspondance_csv=var_req[3].replace('*', "'"+id_code+"'"+','+"'"+\
                                var_upnview[8]+"'"+','+"'"+' UPV Pas de zone sro trouvee' + "'" +','+ 'st_buffer('+ 'geom' +\
                                ',0.1)' ) + "'" + str(var_upnview[5]) + "'"
                                requete_insertion_finale=requete_correspondance_csv
                if requete_insertion_finale != '-1':
                    function_execute_requete(requete_insertion_finale,'',connection)
                
                
                progress_processing(index_upnview,len(sdata),bar_progress)
                if bar_progress.wasCanceled():
                    iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
                    break
                    
            requete_update="""UPDATE """+schema+""".erreur_control_adn error set zapm = zsro.zs_refpm
            from """+schema+""".t_zsro as zsro
            where id like 'UPV%' and  st_intersects(zsro.geom,error.geom);"""
            function_execute_requete(requete_update,'',connection)
    
    function_spatialisation_upnview()
    connection.commit()
    connection.close()
    QMessageBox.information(w, "Message-Execution-Plugin", 'Fin Dexecution du Plugin Spatialisation')
    

#function_general_spatialisation_upnview(DB,user,MP,host,port,schema)