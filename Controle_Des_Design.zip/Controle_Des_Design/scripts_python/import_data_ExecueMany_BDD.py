''''
/***************************************************************************
 *                                                                         *
 *   Ce script permet de faire des imports dans la base de donnees sans    *
 *   pour autant passer par les fichiers batch                             *
 *                                                                         *
 ***************************************************************************/
'''

import processing,xlrd,psycopg2
from qgis.PyQt.QtCore import *
from qgis.PyQt.QtGui import *
from qgis.core import * 
from qgis.utils import *
from qgis.PyQt.QtWidgets import *


#Declaration des Parameters de connexion de la base
# DB = 'MCD_ADN_sans_ct'
# user = 'postgres'
# MP = 'postgres'
# host = '192.168.30.218'#'192.168.30.218'
# port = '5432'
# schema = 'test_baba'#pr_2_5_dexe


def function_import_layer_BDD(DB,user,MP,host,port,schema):

	path_folder= QFileDialog.getExistingDirectory(None, 'Selection Repertoire ou se trouve les shapes a charger dans qgis')
	w = QWidget()
	connection = psycopg2.connect(user=user,password=MP,host=host,port=port,database=DB)
	cursor = connection.cursor()
	cur = connection.cursor()

	def function_create_schema(conn,schema):
		
		curs = conn#.cursor()

		requete_create_schema="""DROP SCHEMA if exists """+schema+""" CASCADE;
		CREATE SCHEMA """+schema+"""
		  AUTHORIZATION postgres;

		SET search_path TO """+schema+""", public;

		DROP TABLE IF EXISTS l_adresse_etat CASCADE;
		DROP TABLE IF EXISTS l_avancement CASCADE;
		DROP TABLE IF EXISTS l_baie_type CASCADE;
		DROP TABLE IF EXISTS l_bp_racco CASCADE;
		DROP TABLE IF EXISTS l_bp_type_log CASCADE;
		DROP TABLE IF EXISTS l_bp_type_phy CASCADE;
		DROP TABLE IF EXISTS l_cable_type CASCADE;
		DROP TABLE IF EXISTS l_cassette_type CASCADE;
		DROP TABLE IF EXISTS l_conduite_type CASCADE;
		DROP TABLE IF EXISTS l_clim_type CASCADE;
		DROP TABLE IF EXISTS l_doc_tab CASCADE;
		DROP TABLE IF EXISTS l_doc_type CASCADE;
		DROP TABLE IF EXISTS l_etat_type CASCADE;
		DROP TABLE IF EXISTS l_fo_color CASCADE;
		DROP TABLE IF EXISTS l_fo_type CASCADE;
		DROP TABLE IF EXISTS l_geoloc_classe CASCADE;
		DROP TABLE IF EXISTS l_geoloc_mode CASCADE;
		DROP TABLE IF EXISTS l_immeuble_type CASCADE;
		DROP TABLE IF EXISTS l_implantation_type CASCADE;
		DROP TABLE IF EXISTS l_infra_nature CASCADE;
		DROP TABLE IF EXISTS l_infra_type_log CASCADE;
		DROP TABLE IF EXISTS l_masque_face CASCADE;
		DROP TABLE IF EXISTS l_noeud_type CASCADE;
		DROP TABLE IF EXISTS l_nro_etat CASCADE;
		DROP TABLE IF EXISTS l_nro_type CASCADE;
		DROP TABLE IF EXISTS l_occupation_type CASCADE;
		DROP TABLE IF EXISTS l_passage_type CASCADE;
		DROP TABLE IF EXISTS l_pose_type CASCADE;
		DROP TABLE IF EXISTS l_position_fonction CASCADE;
		DROP TABLE IF EXISTS l_position_type CASCADE;
		DROP TABLE IF EXISTS l_propriete_type CASCADE;
		DROP TABLE IF EXISTS l_ptech_nature CASCADE;
		DROP TABLE IF EXISTS l_ptech_type_log CASCADE;
		DROP TABLE IF EXISTS l_ptech_type_phy CASCADE;
		DROP TABLE IF EXISTS l_qualite_info CASCADE;
		DROP TABLE IF EXISTS l_reference_etat CASCADE;
		DROP TABLE IF EXISTS l_reference_type CASCADE;
		DROP TABLE IF EXISTS l_site_emission_type CASCADE;
		DROP TABLE IF EXISTS l_site_type_log CASCADE;
		DROP TABLE IF EXISTS l_site_type_phy CASCADE;
		DROP TABLE IF EXISTS l_sro_etat CASCADE;
		DROP TABLE IF EXISTS l_sro_emplacement CASCADE;
		DROP TABLE IF EXISTS l_statut CASCADE;
		DROP TABLE IF EXISTS l_suf_racco CASCADE;
		DROP TABLE IF EXISTS l_suf_type CASCADE;
		DROP TABLE IF EXISTS l_technologie_type CASCADE;
		DROP TABLE IF EXISTS l_tiroir_type CASCADE;
		DROP TABLE IF EXISTS l_tube CASCADE;
		DROP TABLE IF EXISTS l_zone_densite CASCADE;

		CREATE TABLE l_adresse_etat(code VARCHAR(2), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_adresse_etat_pk" PRIMARY KEY (code));
		CREATE TABLE l_avancement(code VARCHAR(1), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_avancement_pk" PRIMARY KEY (code));
		CREATE TABLE l_baie_type(code VARCHAR(10), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_baie_type_pk" PRIMARY KEY (code));
		CREATE TABLE l_bp_racco(code VARCHAR(6), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_bp_racco_pk" PRIMARY KEY (code));
		CREATE TABLE l_bp_type_log(code VARCHAR(3), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_bp_type_log_pk" PRIMARY KEY (code));
		CREATE TABLE l_bp_type_phy(code VARCHAR(5), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_bp_type_phy_pk" PRIMARY KEY (code));
		CREATE TABLE l_cable_type(code VARCHAR(1), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_cable_type_pk" PRIMARY KEY (code));
		CREATE TABLE l_cassette_type(code VARCHAR(1), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_cassette_type_pk" PRIMARY KEY (code));
		CREATE TABLE l_conduite_type(code VARCHAR(10), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_conduite_type_pk" PRIMARY KEY (code));
		CREATE TABLE l_clim_type(code VARCHAR(6), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_clim_type_pk" PRIMARY KEY (code));
		CREATE TABLE l_doc_tab(code VARCHAR(2), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_doc_tab_pk" PRIMARY KEY (code));
		CREATE TABLE l_doc_type(code VARCHAR(3), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_doc_type_pk" PRIMARY KEY (code));
		CREATE TABLE l_etat_type(code VARCHAR(3), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_etat_type_pk" PRIMARY KEY (code));
		CREATE TABLE l_fo_color(code VARCHAR(10), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_fo_color_pk" PRIMARY KEY (code));
		CREATE TABLE l_fo_type(code VARCHAR(20), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_fo_type_pk" PRIMARY KEY (code));
		CREATE TABLE l_geoloc_classe(code VARCHAR(2), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_geoloc_classe_pk" PRIMARY KEY (code));
		CREATE TABLE l_geoloc_mode(code VARCHAR(4), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_geoloc_mode_pk" PRIMARY KEY (code));
		CREATE TABLE l_immeuble_type(code VARCHAR(1), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_immeuble_type_pk" PRIMARY KEY (code));
		CREATE TABLE l_implantation_type(code VARCHAR(2), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_implantation_type_pk" PRIMARY KEY (code));
		CREATE TABLE l_infra_nature(code VARCHAR(3), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_infra_nature_pk" PRIMARY KEY (code));
		CREATE TABLE l_infra_type_log(code VARCHAR(2), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_infra_type_log_pk" PRIMARY KEY (code));
		CREATE TABLE l_masque_face(code VARCHAR(2), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_masque_face_pk" PRIMARY KEY (code));
		CREATE TABLE l_noeud_type(code VARCHAR(2), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_noeud_type_pk" PRIMARY KEY (code));
		CREATE TABLE l_nro_etat(code VARCHAR(2), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_nro_etat_pk" PRIMARY KEY (code));
		CREATE TABLE l_nro_type(code VARCHAR(7), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_nro_type_pk" PRIMARY KEY (code));
		CREATE TABLE l_occupation_type(code VARCHAR(10), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_occupation_type_pk" PRIMARY KEY (code));
		CREATE TABLE l_passage_type(code VARCHAR(10), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_passage_type_pk" PRIMARY KEY (code));
		CREATE TABLE l_pose_type(code VARCHAR(20), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_pose_type_pk" PRIMARY KEY (code));
		CREATE TABLE l_position_fonction(code VARCHAR(2), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_position_fonction_pk" PRIMARY KEY (code));
		CREATE TABLE l_position_type(code VARCHAR(10), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_position_type_pk" PRIMARY KEY (code));
		CREATE TABLE l_propriete_type(code VARCHAR(3), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_propriete_type_pk" PRIMARY KEY (code));
		CREATE TABLE l_ptech_nature(code VARCHAR(20), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_ptech_nature_pk" PRIMARY KEY (code));
		CREATE TABLE l_ptech_type_log(code VARCHAR(1), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_ptech_type_log_pk" PRIMARY KEY (code));
		CREATE TABLE l_ptech_type_phy(code VARCHAR(1), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_ptech_type_phy_pk" PRIMARY KEY (code));
		CREATE TABLE l_qualite_info(code VARCHAR(3), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_qualite_info_pk" PRIMARY KEY (code));
		CREATE TABLE l_reference_etat(code VARCHAR(1), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_reference_etat_pk" PRIMARY KEY (code));
		CREATE TABLE l_reference_type(code VARCHAR(2), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_reference_type_pk" PRIMARY KEY (code));
		CREATE TABLE l_site_emission_type(code VARCHAR(10), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_site_emission_type_pk" PRIMARY KEY (code));
		CREATE TABLE l_site_type_log(code VARCHAR(10), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_site_type_log_pk" PRIMARY KEY (code));
		CREATE TABLE l_site_type_phy(code VARCHAR(3), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_site_type_phy_pk" PRIMARY KEY (code));
		CREATE TABLE l_sro_etat(code VARCHAR(2), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_sro_etat_pk" PRIMARY KEY (code));
		CREATE TABLE l_sro_emplacement(code VARCHAR(3), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_sro_emplacement_pk" PRIMARY KEY (code));
		CREATE TABLE l_statut(code VARCHAR(3), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_statut_pk" PRIMARY KEY (code));
		CREATE TABLE l_suf_racco(code VARCHAR(2), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_suf_racco_pk" PRIMARY KEY (code));
		CREATE TABLE l_suf_type(code VARCHAR(1), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_suf_type_pk" PRIMARY KEY (code));
		CREATE TABLE l_technologie_type(code VARCHAR(10), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_technologie_type_pk" PRIMARY KEY (code));
		CREATE TABLE l_tiroir_type(code VARCHAR(10), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_tiroir_type_pk" PRIMARY KEY (code));
		CREATE TABLE l_tube(code VARCHAR(5), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_tube_pk" PRIMARY KEY (code));
		CREATE TABLE l_zone_densite(code VARCHAR(1), libelle VARCHAR(254), definition VARCHAR(254), CONSTRAINT "l_zone_densite_pk" PRIMARY KEY (code));


		BEGIN;
		INSERT INTO l_adresse_etat VALUES ('CI', 'CIBLE', '');
		INSERT INTO l_adresse_etat VALUES ('SI', 'SIGNE', '');
		INSERT INTO l_adresse_etat VALUES ('EC', 'EN COURS DE DEPLOIEMENT', '');
		INSERT INTO l_adresse_etat VALUES ('DE', 'DEPLOYE', '');
		INSERT INTO l_adresse_etat VALUES ('AB', 'ABANDONNE', '');
		INSERT INTO l_avancement VALUES ('E', 'EXISTANT', '');
		INSERT INTO l_avancement VALUES ('C', 'A CREER', '');
		INSERT INTO l_avancement VALUES ('T', 'TRAVAUX', '');
		INSERT INTO l_avancement VALUES ('S', 'EN SERVICE', '');
		INSERT INTO l_avancement VALUES ('H', 'HORS SERVICE', '');
		INSERT INTO l_avancement VALUES ('A', 'ABANDONNE', '');
		INSERT INTO l_baie_type VALUES ('BAIE', 'BAIE', '');
		INSERT INTO l_baie_type VALUES ('FERME', 'FERME', '');
		INSERT INTO l_bp_racco VALUES ('FCLI01', 'CLIENT : CONTACT ERRONE', 'Le client ne peut être joint, exemple son nom ou ses coordonnées téléphoniques sont erronnées
		Utilisé dans le cas de raccordement par l OI');
		INSERT INTO l_bp_racco VALUES ('FCLI02', 'CLIENT : CLIENT INJOIGNABLE IMPOSSIBLE DE PRENDRE RDV', 'Les coordonnées ne sont pas nécessairement erronnées mais le client n est pas joignable (ne répond pas). La définition précise de ne répond pas n est pas normalisée Interop
		Utilisé dans le cas de raccordement par l OI');
		INSERT INTO l_bp_racco VALUES ('FCLI03', 'CLIENT : CLIENT N HABITE PAS A L ADRESSE INDIQUEE', 'Le RDV a été pris, lors du déplacement le technicien constate que le client n habite pas à l adresse indiquée par l OC');
		INSERT INTO l_bp_racco VALUES ('FCLI04', 'CLIENT : DEMANDE ANNULATION DE LA COMMANDE PAR LE CLIENT FINAL', 'Que ce soit en amont du RDV ou lors du RDV, le client demande à annuler sa commande
		Utilisé dans le cas de raccordement par l OI');
		INSERT INTO l_bp_racco VALUES ('FCLI05', 'CLIENT : REFUS TRAVAUX CLIENT ', 'Que ce soit en amont du RDV ou lors du RDV, le client refuse les travaux (percement, etc.) 
		Utilisé dans le cas de raccordement par l OI');
		INSERT INTO l_bp_racco VALUES ('FCLI06', 'CLIENT : REFUS GESTIONNAIRE IMMEUBLE', 'Lors du raccordement client, un passage en apparent sur le palier est nécessaire et a été refusé par le gestionnaire (par exemple car les goulottes sont saturées ou le palier a été refait)');
		INSERT INTO l_bp_racco VALUES ('FCLI07', 'CLIENT : CLIENT ABSENT LORS DE L INTERVENTION', 'Lors du RDV, le client est absent. Utilisé dans le cas de raccordement par l OI');
		INSERT INTO l_bp_racco VALUES ('FADR01', 'ADRESSE : CODE ADRESSE IMMEUBLE INEXISTANT DANS LE REFERENTIEL OI', 'L OC envoie des codes adresses inexistants de l OI
		Les informations d adresse sont contrôlées dans l ordre suivant :
		1 Hexaclé 
		2 INSEE/RIVOLI/NUM VOIE/ COMPL VOIE
		3 Triplet Hexavia/numéro de voie /complément de voie 
		4 coordonnées xy');
		INSERT INTO l_bp_racco VALUES ('FADR02', 'ADRESSE : BATIMENT MANQUANT OU INEXISTANT DANS LE REFERENTIEL OI', 'L adresse a été reconnue mais le batiment est manquant ou inexistant dans le référentiel de l OI');
		INSERT INTO l_bp_racco VALUES ('FADR03', 'ADRESSE : ESCALIER MANQUANT OU INEXISTANT DANS LE REFERENTIEL OI', 'L adresse et le batiment ont été reconnus mais l escalier est manquant ou inexistant dans le référentiel de l OI');
		INSERT INTO l_bp_racco VALUES ('FADR04', 'ADRESSE : ETAGE MANQUANT OU INEXISTANT DANS LE REFERENTIEL OI', 'L adresse, le batiment et l escalier ont été reconnus mais l étage est manquant ou inexistant dans le référentiel de l OI');
		INSERT INTO l_bp_racco VALUES ('FIMP01', 'TRAITEMENT IMPOSSIBLE : PTO REQUISE', 'L OC est tenu de passer une référence PTO dans sa commande. L OI refuse la commande.');
		INSERT INTO l_bp_racco VALUES ('FIMP02', 'TRAITEMENT IMPOSSIBLE : PTO INEXISTANTE DANS LE REFERENTIEL OI', 'L OC a fourni une référence PTO dans sa commande mais elle est inconnue de l OI');
		INSERT INTO l_bp_racco VALUES ('FIMP03', 'TRAITEMENT IMPOSSIBLE : PTO INCONNUE A L ADRESSE', 'L OC a fourni une référence PTO dans sa commande, elle est connue de l OI mais est incohérente par rapport à l adresse complète (y compris batiment/escalier/étage) dans le référentiel de l OI');
		INSERT INTO l_bp_racco VALUES ('FIMP04', 'TRAITEMENT IMPOSSIBLE : REF PRESTATION PM INEXISTANTE DANS LE REFERENTIEL OI', 'L OC a renvoyé une référence prestation PM inconnue de l OI (exemple l OC se trompe dans la référence PM ou l OI n a pas communiqué un changement de référence PM)');
		INSERT INTO l_bp_racco VALUES ('FIMP05', 'TRAITEMENT IMPOSSIBLE : REF PRESTATION PM ET ADRESSE INCOHERENTES', 'La reference prestation PM existe mais n est pas cohérente avec l adresse communiquée');
		INSERT INTO l_bp_racco VALUES ('FIMP06', 'TRAITEMENT IMPOSSIBLE : TYPE DE COMMANDE IRRECEVABLE SUR CETTE REF PRESTATION PM', 'La reference prestation PM existe, elle est cohérente avec l adresse communiquée mais elle est irrecevable (par exemple le type de commande est incompatible avec le choix de cofinancement ou de location du PM)');
		INSERT INTO l_bp_racco VALUES ('FIMP07', 'TRAITEMENT IMPOSSIBLE : PM INEXISTANT DANS LE REFERENTIEL OI', 'L OC envoie une commande d accès sur un PM inexistant dans le référentiel de l OI (exemple changement de reference PM par l OI non communiqué à l OC ou erreur de l OC dans l envoi de la référence)');
		INSERT INTO l_bp_racco VALUES ('FIMP08', 'TRAITEMENT IMPOSSIBLE : PM ET ADRESSE INCOHERENTS', 'L OC envoie une commande d accès sur un PM connu dans le référentiel de l OI mais incohérent avec l adresse');
		INSERT INTO l_bp_racco VALUES ('FIMP09', 'TRAITEMENT IMPOSSIBLE : COMMANDE IRRECEVABLE SUR CE PM', 'L OC n est pas adducté au PM ou il n a pas retourné toutes les infos ou documents attendus ou l OI n a pas intégré les données retournées par l OC ou l OI rejette la commande qui est passée avant la date de MESC ARCEP');
		INSERT INTO l_bp_racco VALUES ('FIMP10', 'TRAITEMENT IMPOSSIBLE : COMMANDE IRRECEVABLE SUR CETTE ADRESSE', 'L adresse n a pas été mise à disposition à l OC (le CR MAD n a pas été emis sur cette adresse)');
		INSERT INTO l_bp_racco VALUES ('FIMP11', 'TRAITEMENT IMPOSSIBLE : ADRESSE INELIGIBLE TEMPORAIREMENT', 'Le site est temporairement ineligible par exemple en maintenance');
		INSERT INTO l_bp_racco VALUES ('FIMP12', 'TRAITEMENT IMPOSSIBLE : TYPE COMMANDE ERRONNE', 'La valeur du champ TypeCommandeDemande n est pas une des valeurs attendues ');
		INSERT INTO l_bp_racco VALUES ('FIMP13', 'TRAITEMENT IMPOSSIBLE : IDENTIFIANT COMMANDE INTERNE OC DEJA UTILISE', 'L OC envoie une commande en utilisant une commande interne déjà envoyée. Il s agit potentiellement d un doublon de commande');
		INSERT INTO l_bp_racco VALUES ('FIMP14', 'TRAITEMENT IMPOSSIBLE : IDENTIFIANT COMMANDE INTERNE OC INCONNUE', 'L OC annule ou résilie une commande en utilisant un identifiant inconnu de l OI ');
		INSERT INTO l_bp_racco VALUES ('FIMP15', 'TRAITEMENT IMPOSSIBLE : CHAMPS OBLIGATOIRES MANQUANTS', 'L OC envoie une commande incomplète 
		Bonne pratique : l opérateur emetteur du flux de rejet indique dans le champ commentaire du rejet le premier champ obligatoire manquant');
		INSERT INTO l_bp_racco VALUES ('FIMP16', 'TRAITEMENT IMPOSSIBLE : CHAMPS INCOHERENTS', 'L OC envoie la commande avec une erreur de format (exemple chaine de caractère envoyée vs date attendue, champ présent non attendu...) ... (cf Interop)');
		INSERT INTO l_bp_racco VALUES ('FIMP17', 'TRAITEMENT IMPOSSIBLE : PTO INEXISTANTE', 'Lorsqu une commande a été passée avec PTO posée, qu elle n exite pas dans le logement et que le problème n a pas pu être résolu par un reprovisionning à chaud. ');
		INSERT INTO l_bp_racco VALUES ('FIMP18', 'TRAITEMENT IMPOSSIBLE : PTO EXISTANTE', 'Lorsqu une commande a été passée sans PTO (construction de ligne), qu il s avère qu elle existait le logement et que le problème n a pas pu être résolu par un reprovisionning à chaud. La référence de la PTO doit alors être indiquée... (cf Interop)');
		INSERT INTO l_bp_racco VALUES ('FIMP19', 'TRAITEMENT IMPOSSIBLE : PTO DEJA AFFECTEE A L OC', 'Lorsque d un OC détient déjà une ligne FTTH sur une PTO et repasse une commande d accès sur cette même PTO. L OI répond alors, s il refues ce cas de gestion, par un CR de commande KO, avec le motif PTO déjà affectée à l OC ');
		INSERT INTO l_bp_racco VALUES ('FINT01', 'ECHEC PRODUCTION : PB OU PM SATURE', 'L OI signifie à l OC qu il n est pas en mesure de fournir une route optique parce que vu de son SI le PB ou le PM est saturé');
		INSERT INTO l_bp_racco VALUES ('FINT02', 'ECHEC PRODUCTION : SATURATION VIRTUELLE PB OU PM', 'L OI signifie à l OC qu il n est pas en mesure de fournir une route optique en raison d une saturation virtuelle identifiée mais non traitée simultanément. ... (cf Interop)');
		INSERT INTO l_bp_racco VALUES ('FINT03', 'ECHEC PRODUCTION : HOTLINE OI INJOIGNABLE', 'L OC n a pas réussi à joindre la hotline sur le terrain et envoi un code rejet à l OI pour passer en reprovisionning à froid. ');
		INSERT INTO l_bp_racco VALUES ('FINT04', 'ECHEC PRODUCTION : ABSENCE DE CONTINUITE OPTIQUE', 'L OC constate sur le terrain qu il n y a pas de continuité sur la fibre et n a pas pu obtenir une nouvelle route optique via la hotline');
		INSERT INTO l_bp_racco VALUES ('FINT05', 'ECHEC PRODUCTION : AFFAIBLISSEMENT TROP IMPORTANT', 'L OC constate sur le terrain que l affaiblissement sur la fibre est hors norme et n a pas pu obtenir correction via la hotline');
		INSERT INTO l_bp_racco VALUES ('FINT06', 'ECHEC PRODUCTION : ROUTE OPTIQUE DEJA UTILISEE', 'L OC constate sur le terrain que la route qui lui a été transmise est déjà soudée pour un autre raccordement et n a pas pu obtenir une route optique appropriée via la hotline');
		INSERT INTO l_bp_racco VALUES ('FINT07', 'ECHEC PRODUCTION : INFORMATIONS ROUTE OPTIQUE ERRONEES', 'L OC constate sur le terrain que la route optique donnée n existe pas et n a pas pu obtenir une route optique appropriée');
		INSERT INTO l_bp_racco VALUES ('FINT08', 'ECHEC PRODUCTION : POSITION BRASSAGE BAIE OPERATEUR INTROUVABLE', 'Dans le cas d un brassage par l OI, l OI signale à l OC une position de brassage introuvable');
		INSERT INTO l_bp_racco VALUES ('FINT09', 'ECHEC PRODUCTION : POSITION BRASSAGE BAIE OPERATEUR DEJA UTILISEE', 'Dans le cas d un brassage par l OI, l OI signale à l OC une position de brassage déjà utilisée');
		INSERT INTO l_bp_racco VALUES ('FINT10', 'ECHEC PRODUCTION : AUTRE PROBLEME TECHNIQUE', 'Autre problème technique constaté lors de l intervention de raccordement et n étant pas référencé dans les motifs de rejets');
		INSERT INTO l_bp_racco VALUES ('FINT11', 'ECHEC PRODUCTION : INFRA TIERS INDISPONIBLE OU DELAI', 'Dans le cas d un raccordement necessitant l utilisation d infrastructure tiers (poteau, fourreau), ces infra ne sont pas utilisable (bouchée, cassée, …) ou le délais de mise à disposition de ces infra est très important');
		INSERT INTO l_bp_racco VALUES ('FINT12', 'ECHEC PRODUCTION : PBO NON CONFORME', 'Dans le cas où le raccordement est impossible en raison d un problème lié au PBO (exemple : PBO mal fixé, fibre trop courte pour souder..)');
		INSERT INTO l_bp_racco VALUES ('FINT13', 'ECHEC PRODUCTION : DEFAUT DE VERTICALITE', 'Dans le cas d un problème physique identifié sur la colonne montante (exemple colonne HS, vandalisme…). Ce code permet de qualifier les problèmes collectifs c est-à-dire pouvant impacter plusieurs fibres.');
		INSERT INTO l_bp_racco VALUES ('FAUT01', 'AUTRE MOTIF : COMMENTAIRES LIBRES', 'Autre motif technique hors constatation de problème sur le terrain');
		INSERT INTO l_bp_racco VALUES ('FRDV01', 'RDV : NOMBRE MAX DE MODIFICATIONS DE RDV DEPASSE', 'Dans le cas d un raccordment par l OI et d une demande de RDV manuelle, l OC a dépassé le nombre maximum de modifications de RDV autorisé contractuellement par l OI... (cf Interop)');
		INSERT INTO l_bp_racco VALUES ('FRDV02', 'RDV : PAS DE PLAGES DE RDV DISPONIBLES SUR CES CRENEAUX', 'Dans le cas d un raccordement par OI, et d une demande de RDV manuelle, l OC indique des créneaux à l aveugle à l OI. Ce rejet indique que les créneaux proposés par l OC ne sont pas disponibles dans le plan de charge de l OI.... (cf Interop)');
		INSERT INTO l_bp_racco VALUES ('FRDV03', 'RDV : PLAGE DE RDV NON RESERVEE', 'Dans le cas d un raccordement par l OI, l OC a dépassé le délai pour passer sa commande. La réservation du RDV n a donc pas été confirmée par l OI');
		INSERT INTO l_bp_racco VALUES ('FRDV04', 'RDV : ETAT RDV NON VALIDE ', 'Dans le cas où la commande est passée avec un rdv dont l’état n’est pas valide, par exemple annulé, terminé, …');
		INSERT INTO l_bp_racco VALUES ('FRDV05', 'RDV : RDV SUR PRODUIT NON FTTH ', 'Dans le cas où la commande est passée avec un rdv qui a été pris sur un produit autre que le produit accès FTTH');
		INSERT INTO l_bp_racco VALUES ('FRDV06', 'RDV : RDV SUR ADRESSE DIFFERENTE', 'Dans le cas où la commande est passée avec un rdv qui a été pris sur une autre adresse que celle de la commande (exemple n° ou nom de rue différents de l adresse de la commande)');
		INSERT INTO l_bp_type_log VALUES ('BPE', 'BOITIER PROTECTION EPISSURE', '');
		INSERT INTO l_bp_type_log VALUES ('PTO', 'POINT DE TERMINAISON OPTIQUE', '');
		INSERT INTO l_bp_type_log VALUES ('PBO', 'POINT DE BRANCHEMENT OPTIQUE', '');
		INSERT INTO l_bp_type_log VALUES ('DTI', 'DISPOSITIF DE TERMINAISON INTERIEUR OPTIQUE', 'PTO pose par le constructeur d immeuble. ');
		INSERT INTO l_bp_type_phy VALUES ('B006', 'BPE 6FO', '');
		INSERT INTO l_bp_type_phy VALUES ('B012', 'BPE 12FO', '');
		INSERT INTO l_bp_type_phy VALUES ('B024', 'BPE 24FO', '');
		INSERT INTO l_bp_type_phy VALUES ('B036', 'BPE 36FO', '');
		INSERT INTO l_bp_type_phy VALUES ('B048', 'BPE 48FO', '');
		INSERT INTO l_bp_type_phy VALUES ('B072', 'BPE 72FO', '');
		INSERT INTO l_bp_type_phy VALUES ('B096', 'BPE 96FO', '');
		INSERT INTO l_bp_type_phy VALUES ('B144', 'BPE 144FO', '');
		INSERT INTO l_bp_type_phy VALUES ('B288', 'BPE 288FO', '');
		INSERT INTO l_bp_type_phy VALUES ('B432', 'BPE 432FO', '');
		INSERT INTO l_bp_type_phy VALUES ('B576', 'BPE 576FO', '');
		INSERT INTO l_bp_type_phy VALUES ('B720', 'BPE 720FO', '');
		INSERT INTO l_bp_type_phy VALUES ('COF', 'COFFRET', '');
		INSERT INTO l_bp_type_phy VALUES ('DTI1', 'DTIO 1FO', '');
		INSERT INTO l_bp_type_phy VALUES ('DTI2', 'DTIO 2FO', '');
		INSERT INTO l_bp_type_phy VALUES ('DTI4', 'DTIO 4FO', '');
		INSERT INTO l_bp_type_phy VALUES ('AUTR', 'AUTRE', '');
		INSERT INTO l_cable_type VALUES ('C', 'CABLE', '');
		INSERT INTO l_cable_type VALUES ('B', 'BREAKOUT', '');
		INSERT INTO l_cable_type VALUES ('J', 'JARRETIERE', '');
		INSERT INTO l_cassette_type VALUES ('P', 'PLATEAU DE LOVAGE BPE', '');
		INSERT INTO l_cassette_type VALUES ('E', 'EPISSURE', '');
		INSERT INTO l_cassette_type VALUES ('S', 'SPLITTER', '');
		INSERT INTO l_cassette_type VALUES ('C', 'CONNECTEUR', '');
		INSERT INTO l_clim_type VALUES ('SANS', 'SANS', '');
		INSERT INTO l_clim_type VALUES ('VENTIL', 'VENTILLATION', '');
		INSERT INTO l_clim_type VALUES ('CLIM', 'CLIMATISATION', '');
		INSERT INTO l_conduite_type VALUES ('PEHD', 'PEHD', '');
		INSERT INTO l_conduite_type VALUES ('PVC', 'PVC', '');
		INSERT INTO l_conduite_type VALUES ('TPC', 'TPC', '');
		INSERT INTO l_conduite_type VALUES ('CUC', 'CONDUITE UNITAIRE CIMENT', '');
		INSERT INTO l_conduite_type VALUES ('CAN', 'ALVEOLE DE CANIVEAU', 'Possibilite de realiser des masques pour les caniveaux. ');
		INSERT INTO l_conduite_type VALUES ('GOU', 'ALVEOLE DE GOULOTTE', 'Possibilite de realiser des masques pour les goulottes avec multiples alveoles. ');
		INSERT INTO l_conduite_type VALUES ('AER', 'CONDUITE AERIENNE VIRTUELLE', 'Utilise pour creer la relation entre le cable et le cheminement dans le cas de cheminement aerien. ');
		INSERT INTO l_conduite_type VALUES ('AUTRE', 'AUTRE', '');
		INSERT INTO l_conduite_type VALUES ('NC', 'NON COMMUNIQUE', '');
		INSERT INTO l_doc_tab VALUES ('CB', 'CABLE', '');
		INSERT INTO l_doc_tab VALUES ('CD', 'CONDUITE', '');
		INSERT INTO l_doc_tab VALUES ('BP', 'ELEMENT BRANCHEMENT PASSIF', '');
		INSERT INTO l_doc_tab VALUES ('MQ', 'MASQUE', '');
		INSERT INTO l_doc_tab VALUES ('ND', 'NOEUD', '');
		INSERT INTO l_doc_tab VALUES ('PT', 'POINT TECHNIQUE', '');
		INSERT INTO l_doc_tab VALUES ('ST', 'SITE TECHNIQUE', '');
		INSERT INTO l_doc_tab VALUES ('SF', 'SITE UTILISATEUR FINAL', '');
		INSERT INTO l_doc_tab VALUES ('LT', 'LOCAL TECHNIQUE', '');
		INSERT INTO l_doc_tab VALUES ('AD', 'ADRESSE', '');
		INSERT INTO l_doc_tab VALUES ('BA', 'BAIE', '');
		INSERT INTO l_doc_tab VALUES ('CS', 'CASSETTE', '');
		INSERT INTO l_doc_tab VALUES ('EQ', 'EQUIPEMENT', '');
		INSERT INTO l_doc_tab VALUES ('TI', 'TIROIR', '');
		INSERT INTO l_doc_tab VALUES ('OR', 'ORGANISME', '');
		INSERT INTO l_doc_tab VALUES ('ZN', 'ZONE DE NRO', '');
		INSERT INTO l_doc_tab VALUES ('ZD', 'ZONE DE DEPLOIEMENT', '');
		INSERT INTO l_doc_tab VALUES ('ZS', 'ZONE DE SRO', '');
		INSERT INTO l_doc_tab VALUES ('RF', 'REFERENCE', '');
		INSERT INTO l_doc_tab VALUES ('RT', 'ROUTE OPTIQUE', '');
		INSERT INTO l_doc_tab VALUES ('CM', 'CHEMINEMENT', '');
		INSERT INTO l_doc_tab VALUES ('FO', 'FIBRE', '');
		INSERT INTO l_doc_tab VALUES ('PS', 'POSITION', '');
		INSERT INTO l_doc_tab VALUES ('SE', 'SITE EMISSION', '');
		INSERT INTO l_doc_tab VALUES ('LV', 'LOVE', '');
		INSERT INTO l_doc_tab VALUES ('ZP', 'ZONE ARRIERE DE PBO', '');
		INSERT INTO l_doc_tab VALUES ('ZC', 'ZONE COAX', '');
		INSERT INTO l_doc_type VALUES ('DIG', 'DOSSIER D INGENIERIE : REGLES D INGENIERIE UTILISEES', '');
		INSERT INTO l_doc_type VALUES ('ETU', 'RAPPORT D ETUDE', '');
		INSERT INTO l_doc_type VALUES ('PSI', 'PLAN DE SITUATION, SYNOPTIQUE GEOGRAPHIQUE', '');
		INSERT INTO l_doc_type VALUES ('PPH', 'PLAN DE PHASAGE', '');
		INSERT INTO l_doc_type VALUES ('PCB', 'PLAN DE CABLAGE', '');
		INSERT INTO l_doc_type VALUES ('PMQ', 'PLAN DE MASQUE OU FICHE FOA', '');
		INSERT INTO l_doc_type VALUES ('DPO', 'DOSSIER APPUIS AERIENS', '');
		INSERT INTO l_doc_type VALUES ('FOT', 'PHOTO', '');
		INSERT INTO l_doc_type VALUES ('PGC', 'PLAN DE GENIE CIVIL', '');
		INSERT INTO l_doc_type VALUES ('DLV', 'DOSSIER DE LEVE OU D INVESTIGATIONS COMPLEMENTAIRES', '');
		INSERT INTO l_doc_type VALUES ('SGC', 'DETAIL OU SCHEMA DE GENIE CIVIL', '');
		INSERT INTO l_doc_type VALUES ('DPI', 'DOSSIER DE PIQUETAGE', '');
		INSERT INTO l_doc_type VALUES ('DBL', 'DOSSIER DE RELEVE BOITES AUX LETTRES', '');
		INSERT INTO l_doc_type VALUES ('KRV', 'REGLEMENT DE VOIRIE', '');
		INSERT INTO l_doc_type VALUES ('CPV', 'PERMISSION OU AUTORISATION DE VOIRIE', '');
		INSERT INTO l_doc_type VALUES ('DTT', 'DT EMISES DANS LE CADRE DU PROJET DE DEPLOIEMENT', '');
		INSERT INTO l_doc_type VALUES ('DIT', 'DICT EMISES DANS LE CADRE DU PROJET DE DEPLOIEMENT', '');
		INSERT INTO l_doc_type VALUES ('DAM', 'DIAGNOSTIC AMIANTE ENROBE', '');
		INSERT INTO l_doc_type VALUES ('CIN', 'CONTRAT OU CONVENTION DE LOCATION/CESSION/ACHAT/OCCUPATION D INFRASTRUCTURE', '');
		INSERT INTO l_doc_type VALUES ('CMU', 'CONTRAT OU CONVENTION DE CO-CONSTRUCTION OU MUTUALISATION DE TRAVAUX', '');
		INSERT INTO l_doc_type VALUES ('DIP', 'DOSSIER D IMPLANTATION (SRO, NRO, BPI…)', '');
		INSERT INTO l_doc_type VALUES ('SOP', 'SYNOPTIQUE OPTIQUE', '');
		INSERT INTO l_doc_type VALUES ('SBP', 'PLAN DE BOITE, OU AUTRE ELEMENT DE BRANCHEMENT PASSIF', '');
		INSERT INTO l_doc_type VALUES ('SRA', 'SCHEMA DE RACCORDEMENT (BAIE, ARMOIRE, REPARTITEUR…)', '');
		INSERT INTO l_doc_type VALUES ('KEQ', 'DOCUMENTATION TECHNIQUE D EQUIPEMENT', '');
		INSERT INTO l_doc_type VALUES ('CIM', 'CONVENTION THD IMMEUBLE', '');
		INSERT INTO l_doc_type VALUES ('CIS', 'CONVENTION CADRE BAILLEUR SOCIAL', '');
		INSERT INTO l_doc_type VALUES ('CDS', 'REGLEMENT DE SERVICE', '');
		INSERT INTO l_doc_type VALUES ('COC', 'AUTRE CONVENTION D OCCUPATION EMPRISE PRIVEE', '');
		INSERT INTO l_doc_type VALUES ('MRF', 'MESURE DE REFLECTOMETRIE', '');
		INSERT INTO l_doc_type VALUES ('MFX', 'TEST D ETANCHEITE DE FOURREAUX ET/OU TESTS DE MANDRINAGE, AIGUILLAGE', '');
		INSERT INTO l_doc_type VALUES ('RGC', 'PV DE RECEPTION GENIE CIVIL', '');
		INSERT INTO l_doc_type VALUES ('DIF', 'DOSSIER INFRASTRUCTURE D ACCUEIL', '');
		INSERT INTO l_doc_type VALUES ('DCB', 'DOSSIER DE CABLAGE', '');
		INSERT INTO l_doc_type VALUES ('DOP', 'DOSSIER OPTIQUE', '');
		INSERT INTO l_doc_type VALUES ('DPR', 'DOSSIER DE PROJET', '');
		INSERT INTO l_doc_type VALUES ('DLG', 'DOSSIER DE LIVRABLES GRACETHD', '');
		INSERT INTO l_doc_type VALUES ('DCI', 'DOSSIER DE COMMANDE POUR LOCATION/OCCUPATION D INFRASTRUCTURE', '');
		INSERT INTO l_doc_type VALUES ('DCS', 'DOSSIER DE CREATION DE SITE', '');
		INSERT INTO l_doc_type VALUES ('DRS', 'DOSSIER DE RACCORDEMENT DE SITE', '');
		INSERT INTO l_doc_type VALUES ('KPL', 'PLAN LOCAL D URBANISME', '');
		INSERT INTO l_doc_type VALUES ('RFR', 'FICHE DE RECETTE', '');
		INSERT INTO l_doc_type VALUES ('RVR', 'PV DE RECEPTION DE VOIRIE', '');
		INSERT INTO l_doc_type VALUES ('DTA', 'DIAGNOSTIC TECHNIQUE AMIANTE POUR UN IMMEUBLE', '');
		INSERT INTO l_etat_type VALUES ('HS', 'A CHANGER', 'L infrastructure doit etre changee car la moindre intervention peut etre prejudiciable a la fourniture du service');
		INSERT INTO l_etat_type VALUES ('ME', 'MAUVAIS ETAT', 'Mauvais etat general de l infrastructure qui ne permet pas certaines interventions');
		INSERT INTO l_etat_type VALUES ('OK', 'BON ETAT', 'Bon etat general qui permet de realiser toute operation de maintenance, d exploitation ou d evolution');
		INSERT INTO l_etat_type VALUES ('NC', 'NON CONCERNE', '');
		INSERT INTO l_fo_color VALUES ('1', 'ROUGE (R)', '#FF0000 - Standard Orange');
		INSERT INTO l_fo_color VALUES ('2', 'BLEU (BL)', '#0070C0 - Standard Orange');
		INSERT INTO l_fo_color VALUES ('3', 'VERT (VE)', '#92D050 - Standard Orange');
		INSERT INTO l_fo_color VALUES ('4', 'JAUNE (J)', '#FFFF00 - Standard Orange');
		INSERT INTO l_fo_color VALUES ('5', 'VIOLET (V)', '#7638A3 - Standard Orange');
		INSERT INTO l_fo_color VALUES ('6', 'BLANC (B)', '#FFFFFF - Standard Orange');
		INSERT INTO l_fo_color VALUES ('7', 'ORANGE (OR)', '#FFC000 - Standard Orange');
		INSERT INTO l_fo_color VALUES ('8', 'GRIS (GR)', '#C1C1C1 - Standard Orange');
		INSERT INTO l_fo_color VALUES ('9', 'MARRON (BR)', '#993300 - Standard Orange');
		INSERT INTO l_fo_color VALUES ('10', 'NOIR (N)', '#000000 - Standard Orange');
		INSERT INTO l_fo_color VALUES ('11', 'TURQUOISE (TU)', '#00B0F0 - Standard Orange');
		INSERT INTO l_fo_color VALUES ('12', 'ROSE (RS)', '#FF65CC - Standard Orange');
		INSERT INTO l_fo_color VALUES ('1.1', 'BLEU (BL)', '#0070C0 -  FOTAG IEEE 802.8');
		INSERT INTO l_fo_color VALUES ('1.2', 'ORANGE (OR)', '#FFC000 -  FOTAG IEEE 802.8');
		INSERT INTO l_fo_color VALUES ('1.3', 'VERT (VE)', '#92D050 -  FOTAG IEEE 802.8');
		INSERT INTO l_fo_color VALUES ('1.4', 'JAUNE (J)', '#FFFF00 -  FOTAG IEEE 802.8');
		INSERT INTO l_fo_color VALUES ('1.5', 'VIOLET (V)', '#7638A3 -  FOTAG IEEE 802.8');
		INSERT INTO l_fo_color VALUES ('1.6', 'BLANC (B)', '#FFFFFF -  FOTAG IEEE 802.8');
		INSERT INTO l_fo_color VALUES ('1.7', 'ORANGE (OR)', '#FFC000 -  FOTAG IEEE 802.8');
		INSERT INTO l_fo_color VALUES ('1.8', 'GRIS (GR)', '#C1C1C1 -  FOTAG IEEE 802.8');
		INSERT INTO l_fo_color VALUES ('1.9', 'MARRON (BR)', '#993300 -  FOTAG IEEE 802.8');
		INSERT INTO l_fo_color VALUES ('1.10', 'NOIR (N)', '#000000 -  FOTAG IEEE 802.8');
		INSERT INTO l_fo_color VALUES ('1.11', 'TURQUOISE (TU)', '#00B0F0 -  FOTAG IEEE 802.8');
		INSERT INTO l_fo_color VALUES ('1.12', 'ROSE (RS)', '#FF65CC -  FOTAG IEEE 802.8');
		INSERT INTO l_fo_type VALUES ('G651', 'G651', 'Norme ITU : Fibre multimode a gradient d indice type 50/125μm');
		INSERT INTO l_fo_type VALUES ('G652', 'G652', 'Norme ITU : Fibre monomode standard SMF pour utilisation a 1300 nm et eventuellement a 1550 nm ');
		INSERT INTO l_fo_type VALUES ('G652A', 'G652A', 'Norme ITU : Version de base de la fibre G652, definie a 1310 nm et a 1550 nm');
		INSERT INTO l_fo_type VALUES ('G652B', 'G652B', 'Norme ITU : Version de la fibre G652, definie à 1625nm avec des affaiblissements ameliores a 1310nm et a 1550nm par rapport a la version a, et avec une meilleure PMD.');
		INSERT INTO l_fo_type VALUES ('G652C', 'G652C', 'Norme ITU : Version  de  la  fibre  G652,  definie  a  1383nm  (faible  pic  OH)  avec  un  affaiblissement 
		ameliore a 1550nm par rapport à la version b.');
		INSERT INTO l_fo_type VALUES ('G652D', 'G652D', 'Norme ITU : Version de la fibre G652 la plus performante (meilleures caracteristiques des versions b et c)');
		INSERT INTO l_fo_type VALUES ('G653', 'G653', 'Norme ITU : Fibre monomode a dispersion decalee DSF');
		INSERT INTO l_fo_type VALUES ('G654', 'G654', 'Norme ITU : Fibre monomode a longueur d onde de coupure decalee. ');
		INSERT INTO l_fo_type VALUES ('G655', 'G655', 'Norme ITU : Fibre a dispersion decalee non nulle NZ-DSF ');
		INSERT INTO l_fo_type VALUES ('G656', 'G656', 'Norme ITU : Fibre monomode a dispersion non nulle pour large bande. ');
		INSERT INTO l_fo_type VALUES ('G657', 'G657', 'Norme ITU : Fibre monomode pour reseaux d acces FTTH. ');
		INSERT INTO l_fo_type VALUES ('G657A', 'G657A', 'Norme ITU : Fibre G657 compatible avec la fibre optique G652d');
		INSERT INTO l_fo_type VALUES ('G657A1', 'G657A1', 'Norme ITU : Fibre  G657  compatible  a  la  fibre  G652d  et  offrant  une  insensibilite aux courbes de plus de 10mm. ');
		INSERT INTO l_fo_type VALUES ('G657A2', 'G657A2', 'Norme ITU : Fibre  G657  compatible  a  la  fibre  G652d  et  offrant  une  insensibilite aux courbes de plus de 7,5mm. ');
		INSERT INTO l_fo_type VALUES ('G657A3', 'G657A3', 'Norme ITU : Fibre  G657  compatible  a  la  fibre  G652d  et  offrant  une  insensibilite aux courbes de plus de 5mm. ');
		INSERT INTO l_fo_type VALUES ('G657B', 'G657B', 'Norme ITU : Fibre  G657  non  compatible  avec  la  fibre  optique  G652  mais  avec  des  meilleures caracteristiques d insensibilite aux courbes que la version a.');
		INSERT INTO l_fo_type VALUES ('G657B1', 'G657B1', 'Norme ITU : Fibre  G657  non  compatible  avec  la  fibre  optique  G652  et offrant une insensibilite aux courbes de plus de 10mm. ');
		INSERT INTO l_fo_type VALUES ('G657B2', 'G657B2', 'Norme ITU : Fibre  G657  non  compatible  avec  la  fibre  optique  G652  et offrant une insensibilite aux courbes de plus de 7,5mm. ');
		INSERT INTO l_fo_type VALUES ('G657B3', 'G657B3', 'Norme ITU : Fibre  G657  non  compatible  avec  la  fibre  optique  G652  et offrant une insensibilite aux courbes de plus de 5mm. ');
		INSERT INTO l_fo_type VALUES ('OM1', 'OM1', 'Norme ISO/IEC 11801 : Caracteristique  d une  fibre  optique  multimode  avec  une  bande passante minimum de 200MHz.km a 850nm. Peut transmettre 100Mbits sur 2km et 1 Gbit sur 275m a 850nm.');
		INSERT INTO l_fo_type VALUES ('OM2', 'OM2', 'Norme ISO/IEC 11801 : Caracteristique d une fibre optique multimode avec une bande passante minimum de 500MHz.km à 850nm. Peut transmettre 100Mbits sur 5km, 1 Gbits sur 550m et 10Gbits sur 82m a 850m. ');
		INSERT INTO l_fo_type VALUES ('OM3', 'OM3', 'Norme ISO/IEC 11801 : Caracteristique d une fibre optique multimode avec une bande de passante minimum de 1500MHz.km.. Peut transmettre 10 Gbits sur 330m à 850nm.');
		INSERT INTO l_fo_type VALUES ('OM4', 'OM4', 'Norme ISO/IEC 11801 : Caracteristique d une fibre optique multimode. Peut transmettre 10 Gbits sur 550m a 850nm.');
		INSERT INTO l_fo_type VALUES ('OS1', 'OS1', 'Norme ISO/EN : fibre monomode d attenuation maximum 1.0 dB par km (1310 et 1550nm). Pour des transmissions de 2km maximum. ');
		INSERT INTO l_fo_type VALUES ('OS2', 'OS2', 'Norme ISO/EN : fibre monomode d attenuation maximum 0.4 dB par km (1310 et 1550nm). Pour des transmissions superieures a 2km. ');
		INSERT INTO l_geoloc_classe VALUES ('A', 'CLASSE DE PRECISION A', 'Décret du 15 février 2012 : un ouvrage ou tronçon d ouvrage est rangé dans la classe A si l incertitude maximale de localisation indiquée par son exploitant est inférieure ou égale à 40 cm et s il est rigide, ou à 50 cm s il est flexible. ');
		INSERT INTO l_geoloc_classe VALUES ('AP', 'CLASSE DE PRECISION A, EN PLANIMETRIE UNIQUEMENT', 'Idem classe A, mais uniquement pour les valeurs x et y (hors z)');
		INSERT INTO l_geoloc_classe VALUES ('B', 'CLASSE DE PRECISION B', 'Décret du 15 février 2012 : un ouvrage ou tronçon d ouvrage est rangé dans la classe B si l incertitude maximale de localisation indiquée par son exploitant est supérieure à celle relative à la classe A et inférieure ou égale à 1,5 mètre.');
		INSERT INTO l_geoloc_classe VALUES ('C', 'CLASSE DE PRECISION C', 'Décret du 15 février 2012 : un ouvrage ou tronçon d ouvrage est rangé dans la classe C si l incertitude maximale de localisation indiquée par son exploitant est supérieure à 1,5 mètre, ou si son exploitant n est pas en mesure de fournir la localisation.');
		INSERT INTO l_geoloc_mode VALUES ('LTRO', 'LEVE DURANT LA POSE', 'Objet positionne grace à un leve durant la phase travaux. Dans le cas de tranchee, ce leve a ete realise tranchee ouverte.');
		INSERT INTO l_geoloc_mode VALUES ('LVIS', 'LEVE APRES LA POSE', 'Objet positionne grace a un leve. Dans le cas d une tranchee, uniquement les elements visibles ont ete leves (rustines sur le revetement, chambres encadrantes). Des cotations prises pendant la pose ont permis de completer ce lever.');
		INSERT INTO l_geoloc_mode VALUES ('DETC', 'LEVE AVEC DETECTION', 'Un appareil de detection a ete utilise pour positionner les elements à lever.');
		INSERT INTO l_geoloc_mode VALUES ('FDPL', 'COTATION PAR RAPPORT A UN LEVE DE GEOMETRE', 'Objet implante en reportant des cotations prises par rapport à un fond de plan precedemment leve.');
		INSERT INTO l_geoloc_mode VALUES ('CBDU', 'COTATION PAR RAPPORT A UN FOND DE PLAN TIERS TYPE BDU', 'Objet implante en reportant des cotations prises par rapport au meilleur fond de plan actuellement disponible.');
		INSERT INTO l_geoloc_mode VALUES ('CADA', 'POSITIONNEMENT SUR CADASTRE', 'Objet positionne par rapport aux planches cadastrales.');
		INSERT INTO l_geoloc_mode VALUES ('ORTO', 'POSITIONNEMENT SUR ORTHOPHOTOGRAPHIE OU FOND DE PLAN CARTOGRAPHIQUE', 'Objet positionne par rapport à des orthophotos, ou des fonds cartographiques type RGE, FRANCE RASTER, OSM ou Bing');
		INSERT INTO l_geoloc_mode VALUES ('INDT', 'INDETERMINE', '');
		INSERT INTO l_immeuble_type VALUES ('P', 'PAVILLON', '');
		INSERT INTO l_immeuble_type VALUES ('I', 'IMMEUBLE', '');
		INSERT INTO l_implantation_type VALUES ('0', 'AERIEN TELECOM', '');
		INSERT INTO l_implantation_type VALUES ('1', 'AERIEN ENERGIE', '');
		INSERT INTO l_implantation_type VALUES ('2', 'FACADE', '');
		INSERT INTO l_implantation_type VALUES ('3', 'IMMEUBLE', '');
		INSERT INTO l_implantation_type VALUES ('4', 'PLEINE TERRE', '');
		INSERT INTO l_implantation_type VALUES ('5', 'CANIVEAU', '');
		INSERT INTO l_implantation_type VALUES ('6', 'GALERIE', '');
		INSERT INTO l_implantation_type VALUES ('7', 'CONDUITE', '');
		INSERT INTO l_implantation_type VALUES ('8', 'EGOUT', '');
		INSERT INTO l_implantation_type VALUES ('9', 'SPECIFIQUE', '');
		INSERT INTO l_infra_nature VALUES ('ASS', 'ASSAINISSEMENT', '');
		INSERT INTO l_infra_nature VALUES ('EAU', 'EAU', '');
		INSERT INTO l_infra_nature VALUES ('ELE', 'ELECTRICITE', '');
		INSERT INTO l_infra_nature VALUES ('GAZ', 'GAZ', '');
		INSERT INTO l_infra_nature VALUES ('NC', 'NON COMMUNIQUE', '');
		INSERT INTO l_infra_nature VALUES ('TEL', 'TELECOM', '');
		INSERT INTO l_infra_nature VALUES ('HTZ', 'HERTZIEN', 'Faisceau hertzien. ');
		INSERT INTO l_infra_type_log VALUES ('CX', 'COLLECTE TRANSPORT DISTRIBUTION', '');
		INSERT INTO l_infra_type_log VALUES ('CO', 'COLLECTE', 'Infrastructures en amont d’un NRO, d un NRA ou d un POP, permettant de faire transiter les flux mutualises des abonnes vers le cœur de reseau de l operateur.');
		INSERT INTO l_infra_type_log VALUES ('CT', 'COLLECTE TRANSPORT', '');
		INSERT INTO l_infra_type_log VALUES ('CD', 'COLLECTE DISTRIBUTION', '');
		INSERT INTO l_infra_type_log VALUES ('TD', 'TRANSPORT DISTRIBUTION', 'Mutualisation des fonctions transport et distribution');
		INSERT INTO l_infra_type_log VALUES ('TR', 'TRANSPORT', 'Infrastructure situee entre un noeud de raccordement (NRO, NRA, …) et les sous-repartiteurs (SRO, ...). ');
		INSERT INTO l_infra_type_log VALUES ('DI', 'DISTRIBUTION', 'Infrastructure situee entre le sous-repartiteur (SRO, ...) et les points de branchement (PBO, ...). ');
		INSERT INTO l_infra_type_log VALUES ('RA', 'RACCORDEMENT FINAL', 'Infrastructure  situee  entre  le  point de branchement (PBO, ...) et la prise terminale (DTIO, ...). ');
		INSERT INTO l_infra_type_log VALUES ('BM', 'BOUCLE METROPOLITAINE', '');
		INSERT INTO l_infra_type_log VALUES ('LH', 'LONGUE DISTANCE (LONG HAUL)', '');
		INSERT INTO l_infra_type_log VALUES ('NC', 'NON COMMUNIQUE', '');
		INSERT INTO l_masque_face VALUES ('A', 'A', '');
		INSERT INTO l_masque_face VALUES ('B', 'B', '');
		INSERT INTO l_masque_face VALUES ('C', 'C', '');
		INSERT INTO l_masque_face VALUES ('D', 'D', '');
		INSERT INTO l_masque_face VALUES ('E', 'E', '');
		INSERT INTO l_masque_face VALUES ('F', 'F', '');
		INSERT INTO l_masque_face VALUES ('G', 'G', '');
		INSERT INTO l_masque_face VALUES ('H', 'H', '');
		INSERT INTO l_masque_face VALUES ('I', 'I', '');
		INSERT INTO l_masque_face VALUES ('J', 'J', '');
		INSERT INTO l_noeud_type VALUES ('PT', 'POINT TECHNIQUE', '');
		INSERT INTO l_noeud_type VALUES ('ST', 'SITE TECHNIQUE', '');
		INSERT INTO l_noeud_type VALUES ('SF', 'SITE UTILISATEUR FINAL', '');
		INSERT INTO l_noeud_type VALUES ('SE', 'SITE EMISSION', '');
		INSERT INTO l_noeud_type VALUES ('JX', 'DISJONCTION', 'Positionner un nœud de type disjonction lorsqu un cheminement se separe pour former par exemple un Y, sans qu il y ait pour autant de point technique physique au niveau de la disjonction (pas de manchonnage, pas de chambre, ...). ');
		INSERT INTO l_noeud_type VALUES ('SH ', 'SITE FTTH COMPLEXE ', 'Immeuble raccorde a un reseau FTTH et accueillant notamment un ou des PBI');
		INSERT INTO l_noeud_type VALUES ('SC ', 'SITE TECHNIQUE COMPLEXE ', 'Site technique avec points techniques');
		INSERT INTO l_noeud_type VALUES ('PC ', 'POINT TECHNIQUE COMPLEXE ', '');
		INSERT INTO l_noeud_type VALUES ('EC ', 'SITE EMISSION COMPLEXE', '');
		INSERT INTO l_noeud_type VALUES ('SP', 'SPECIFIQUE', '');
		INSERT INTO l_nro_type VALUES ('PON', 'NRO-PON', '');
		INSERT INTO l_nro_type VALUES ('PTP', 'NRO-PTP', '');
		INSERT INTO l_nro_type VALUES ('PON-PTP', 'NRO-PON-PTP', '');
		INSERT INTO l_nro_etat VALUES ('PL', 'PLANIFIE', '');
		INSERT INTO l_nro_etat VALUES ('EC', 'EN COURS DE DEPLOIEMENT', 'En cours d installation, sans qu une definition precise n ait ete partagee en Interop. ');
		INSERT INTO l_nro_etat VALUES ('DP', 'DEPLOYE', 'Installe. Doit alors etre mis a disposition des operateurs ayant achete le PM. ');
		INSERT INTO l_nro_etat VALUES ('AB', 'ABANDONNE', 'Le PM est abandonne. Cet etat doit apparaitre pendant 3 mois.');
		INSERT INTO l_occupation_type VALUES ('0', 'VIDE', 'Infrastructure vide');
		INSERT INTO l_occupation_type VALUES ('1.1', 'NON VIDE EXPLOITABLE', 'Infrastructure non vide mais exploitable car rangee');
		INSERT INTO l_occupation_type VALUES ('1.2', 'NON VIDE NON EXPLOITABLE', 'Infrastructure non vide mais non exploitable car non rangee');
		INSERT INTO l_occupation_type VALUES ('2', 'SATUREE', 'Infrastructure saturee');
		INSERT INTO l_passage_type VALUES ('ACC', 'ACCOTEMENT', '');
		INSERT INTO l_passage_type VALUES ('CHAU', 'CHAUSSEE', '');
		INSERT INTO l_passage_type VALUES ('TROT', 'TROTTOIR', '');
		INSERT INTO l_passage_type VALUES ('TER', 'TERRE', '');
		INSERT INTO l_passage_type VALUES ('EMP', 'EMPIERRE', '');
		INSERT INTO l_passage_type VALUES ('PON', 'PONT', '');
		INSERT INTO l_passage_type VALUES ('SNC', 'PASSAGE SNCF', '');
		INSERT INTO l_passage_type VALUES ('CAN', 'CANIVEAU TECHNIQUE', '');
		INSERT INTO l_passage_type VALUES ('PAV', 'PAVES', '');
		INSERT INTO l_passage_type VALUES ('AQU', 'AQUATIQUE', '');
		INSERT INTO l_passage_type VALUES ('NC', 'NON COMMUNIQUE', '');
		INSERT INTO l_pose_type VALUES ('NC', 'NON COMMUNIQUE', '');
		INSERT INTO l_pose_type VALUES ('TRA', 'TRADITIONNELLE', '');
		INSERT INTO l_pose_type VALUES ('MEC', 'MECANISEE', '');
		INSERT INTO l_pose_type VALUES ('MIC', 'MICRO TRANCHEE', '');
		INSERT INTO l_pose_type VALUES ('FOR', 'FORAGE DIRIGE', '');
		INSERT INTO l_pose_type VALUES ('ENS', 'ENSOUILLAGE', '');
		INSERT INTO l_pose_type VALUES ('FON', 'FONÇAGE', '');
		INSERT INTO l_pose_type VALUES ('ENC', 'ENCORBELLEMENT', '');
		INSERT INTO l_pose_type VALUES ('STU', 'SOUS-TUBAGE', 'Sous-tubage infra existante');
		INSERT INTO l_position_fonction VALUES ('CO', 'CONNECTEUR', '');
		INSERT INTO l_position_fonction VALUES ('EP', 'EPISSURE', '');
		INSERT INTO l_position_fonction VALUES ('PI', 'PIGTAIL', '');
		INSERT INTO l_position_fonction VALUES ('AT', 'ATTENTE', '');
		INSERT INTO l_position_fonction VALUES ('PA', 'PASSAGE', '');
		INSERT INTO l_position_type VALUES ('CEA', 'CONNECTEUR E2000-APC', 'Connecteur a verrouillage de type push/pull avec protection poussiere. Polissage permettant d avoir une reflectance meilleure que -60dB.');
		INSERT INTO l_position_type VALUES ('CEU', 'CONNECTEUR E2000-UPC', 'Connecteur a verrouillage de type push/pull avec protection poussiere. Polissage permettant d avoir une reflectance meilleure que -50dB.');
		INSERT INTO l_position_type VALUES ('CEP', 'CONNECTEUR E2000-PC', 'Connecteur a verrouillage de type push/pull avec protection poussiere. Polissage permettant d avoir une reflectance meilleure que -30dB.');
		INSERT INTO l_position_type VALUES ('CFA', 'CONNECTEUR FC-APC', 'Connecteur a verrouillage a vis. Polissage permettant d avoir une reflectance meilleure que -60dB.');
		INSERT INTO l_position_type VALUES ('CFU', 'CONNECTEUR FC-UPC', 'Connecteur a verrouillage a vis. Polissage permettant d avoir une reflectance meilleure que -50dB.');
		INSERT INTO l_position_type VALUES ('CFP', 'CONNECTEUR FC-PC', 'Connecteur a verrouillage a vis. Polissage permettant d avoir une reflectance meilleure que -30dB.');
		INSERT INTO l_position_type VALUES ('CLA', 'CONNECTEUR LC-APC', 'Connecteur a verrouillage de type push/pull et par languette. Polissage permettant d avoir une reflectance meilleure que -60dB.');
		INSERT INTO l_position_type VALUES ('CLU', 'CONNECTEUR LC-UPC', 'Connecteur a verrouillage de type push/pull et par languette. Polissage permettant d avoir une reflectance meilleure que -50dB.');
		INSERT INTO l_position_type VALUES ('CLP', 'CONNECTEUR LC-PC', 'Connecteur a verrouillage de type push/pull et par languette. Polissage permettant d avoir une reflectance meilleure que -30dB.');
		INSERT INTO l_position_type VALUES ('CMA', 'CONNECTEUR MU-APC', 'Connecteur a verrouillage de type push/pull diametre 1.25mm. Polissage permettant d avoir une reflectance meilleure que -60dB.');
		INSERT INTO l_position_type VALUES ('CMU', 'CONNECTEUR MU-UPC', 'Connecteur a verrouillage de type push/pull diametre 1.25mm. Polissage permettant d avoir une reflectance meilleure que -50dB.');
		INSERT INTO l_position_type VALUES ('CMP', 'CONNECTEUR MU-PC', 'Connecteur a verrouillage de type push/pull diametre 1.25mm. Polissage permettant d avoir une reflectance meilleure que -30dB.');
		INSERT INTO l_position_type VALUES ('CSA', 'CONNECTEUR SC-APC', 'Connecteur a verrouillage de type push/pull diametre 2.5mm. Polissage permettant d avoir une reflectance meilleure que -60dB.');
		INSERT INTO l_position_type VALUES ('CSU', 'CONNECTEUR SC-UPC', 'Connecteur a verrouillage de type push/pull diametre 2.5mm. Polissage permettant d avoir une reflectance meilleure que -50dB.');
		INSERT INTO l_position_type VALUES ('CSP', 'CONNECTEUR SC-PC', 'Connecteur a verrouillage de type push/pull diametre 2.5mm. Polissage permettant d avoir une reflectance meilleure que -30dB.');
		INSERT INTO l_position_type VALUES ('CTU', 'CONNECTEUR ST-UPC', 'Connecteur a verrouillage de type baionnette. Polissage permettant d avoir une reflectance meilleure que -50dB.');
		INSERT INTO l_position_type VALUES ('CTP', 'CONNECTEUR ST-PC', 'Connecteur a verrouillage de type baionette. Polissage permettant d avoir une reflectance meilleure que -30dB.');
		INSERT INTO l_position_type VALUES ('CPO', 'CONNECTEUR MT MPO', 'Fiche polymère intégrant plusieurs fibres SM ou MM. MTRJ pour la version 2 fibres. ');
		INSERT INTO l_position_type VALUES ('SFU', 'SOUDURE FUSION', 'Raccordement sous l effet d une chaleur intense avec une soudeuse. ');
		INSERT INTO l_position_type VALUES ('SME', 'SOUDURE MECANIQUE', 'Raccordement mecanique, generalement par sertissage. ');
		INSERT INTO l_propriete_type VALUES ('CST', 'CONSTRUCTION', '');
		INSERT INTO l_propriete_type VALUES ('RAC', 'RACHAT', '');
		INSERT INTO l_propriete_type VALUES ('CES', 'CESSION', '');
		INSERT INTO l_propriete_type VALUES ('IRU', 'IRU', '');
		INSERT INTO l_propriete_type VALUES ('LOC', 'LOCATION', '');
		INSERT INTO l_propriete_type VALUES ('OCC', 'OCCUPATION', 'Convention d occupation');
		INSERT INTO l_ptech_nature VALUES ('A1', 'CHAMBRE A1', '');
		INSERT INTO l_ptech_nature VALUES ('A2', 'CHAMBRE A2', '');
		INSERT INTO l_ptech_nature VALUES ('A3', 'CHAMBRE A3', '');
		INSERT INTO l_ptech_nature VALUES ('A4', 'CHAMBRE A4', '');
		INSERT INTO l_ptech_nature VALUES ('A10', 'CHAMBRE A10', '');
		INSERT INTO l_ptech_nature VALUES ('A11', 'CHAMBRE A11', '');
		INSERT INTO l_ptech_nature VALUES ('A12', 'CHAMBRE A12', '');
		INSERT INTO l_ptech_nature VALUES ('A13', 'CHAMBRE A13', '');
		INSERT INTO l_ptech_nature VALUES ('A14', 'CHAMBRE A14', '');
		INSERT INTO l_ptech_nature VALUES ('A15', 'CHAMBRE A15', '');
		INSERT INTO l_ptech_nature VALUES ('A16', 'CHAMBRE A16', '');
		INSERT INTO l_ptech_nature VALUES ('A17', 'CHAMBRE A17', '');
		INSERT INTO l_ptech_nature VALUES ('A18', 'CHAMBRE A18', '');
		INSERT INTO l_ptech_nature VALUES ('B1', 'CHAMBRE B1', '');
		INSERT INTO l_ptech_nature VALUES ('B2', 'CHAMBRE B2', '');
		INSERT INTO l_ptech_nature VALUES ('B3', 'CHAMBRE B3', '');
		INSERT INTO l_ptech_nature VALUES ('B4', 'CHAMBRE B4', '');
		INSERT INTO l_ptech_nature VALUES ('C1', 'CHAMBRE C1', '');
		INSERT INTO l_ptech_nature VALUES ('C2', 'CHAMBRE C2', '');
		INSERT INTO l_ptech_nature VALUES ('C3', 'CHAMBRE C3', '');
		INSERT INTO l_ptech_nature VALUES ('C4', 'CHAMBRE C4', '');
		INSERT INTO l_ptech_nature VALUES ('D1', 'CHAMBRE D1', '');
		INSERT INTO l_ptech_nature VALUES ('D1C', 'CHAMBRE D1C', '');
		INSERT INTO l_ptech_nature VALUES ('D1T', 'CHAMBRE D1T', '');
		INSERT INTO l_ptech_nature VALUES ('D2', 'CHAMBRE D2', '');
		INSERT INTO l_ptech_nature VALUES ('D2C', 'CHAMBRE D2C', '');
		INSERT INTO l_ptech_nature VALUES ('D2T', 'CHAMBRE D2T', '');
		INSERT INTO l_ptech_nature VALUES ('D3', 'CHAMBRE D3', '');
		INSERT INTO l_ptech_nature VALUES ('D3C', 'CHAMBRE D3C', '');
		INSERT INTO l_ptech_nature VALUES ('D3T', 'CHAMBRE D3T', '');
		INSERT INTO l_ptech_nature VALUES ('D4', 'CHAMBRE D4', '');
		INSERT INTO l_ptech_nature VALUES ('D4C', 'CHAMBRE D4C', '');
		INSERT INTO l_ptech_nature VALUES ('D4T', 'CHAMBRE D4T', '');
		INSERT INTO l_ptech_nature VALUES ('D5', 'CHAMBRE D5', '');
		INSERT INTO l_ptech_nature VALUES ('D5C', 'CHAMBRE D5C', '');
		INSERT INTO l_ptech_nature VALUES ('D6', 'CHAMBRE D6', '');
		INSERT INTO l_ptech_nature VALUES ('D6C', 'CHAMBRE D6C', '');
		INSERT INTO l_ptech_nature VALUES ('D11', 'CHAMBRE D11', '');
		INSERT INTO l_ptech_nature VALUES ('D12', 'CHAMBRE D12', '');
		INSERT INTO l_ptech_nature VALUES ('D13', 'CHAMBRE D13', '');
		INSERT INTO l_ptech_nature VALUES ('D14', 'CHAMBRE D14', '');
		INSERT INTO l_ptech_nature VALUES ('E1', 'CHAMBRE E1', '');
		INSERT INTO l_ptech_nature VALUES ('E2', 'CHAMBRE E2', '');
		INSERT INTO l_ptech_nature VALUES ('E3', 'CHAMBRE E3', '');
		INSERT INTO l_ptech_nature VALUES ('E4', 'CHAMBRE E4', '');
		INSERT INTO l_ptech_nature VALUES ('J2C', 'CHAMBRE J2C', '');
		INSERT INTO l_ptech_nature VALUES ('J2CR', 'CHAMBRE J2C REHAUSSEE', '');
		INSERT INTO l_ptech_nature VALUES ('K1C', 'CHAMBRE K1C', '');
		INSERT INTO l_ptech_nature VALUES ('K1CR', 'CHAMBRE K1C REHAUSSEE', '');
		INSERT INTO l_ptech_nature VALUES ('K1T', 'CHAMBRE K1T', '');
		INSERT INTO l_ptech_nature VALUES ('K2C', 'CHAMBRE K2C', '');
		INSERT INTO l_ptech_nature VALUES ('K2CR', 'CHAMBRE K2C REHAUSSEE', '');
		INSERT INTO l_ptech_nature VALUES ('K2T', 'CHAMBRE K2T', '');
		INSERT INTO l_ptech_nature VALUES ('K3C', 'CHAMBRE K3C', '');
		INSERT INTO l_ptech_nature VALUES ('K3CR', 'CHAMBRE K3C REHAUSSEE', '');
		INSERT INTO l_ptech_nature VALUES ('K3T', 'CHAMBRE K3T', '');
		INSERT INTO l_ptech_nature VALUES ('L0T', 'CHAMBRE L0T', '');
		INSERT INTO l_ptech_nature VALUES ('L0TR', 'CHAMBRE L0T REHAUSSEE', '');
		INSERT INTO l_ptech_nature VALUES ('L1C', 'CHAMBRE L1C', '');
		INSERT INTO l_ptech_nature VALUES ('L1T', 'CHAMBRE L1T', '');
		INSERT INTO l_ptech_nature VALUES ('L1TR', 'CHAMBRE L1T REHAUSSEE', '');
		INSERT INTO l_ptech_nature VALUES ('L2C', 'CHAMBRE L2C', '');
		INSERT INTO l_ptech_nature VALUES ('L2T', 'CHAMBRE L2T', '');
		INSERT INTO l_ptech_nature VALUES ('L2TR', 'CHAMBRE L2T REHAUSSEE', '');
		INSERT INTO l_ptech_nature VALUES ('L3C', 'CHAMBRE L3C', '');
		INSERT INTO l_ptech_nature VALUES ('L3T', 'CHAMBRE L3T', '');
		INSERT INTO l_ptech_nature VALUES ('L3TR', 'CHAMBRE L3T REHAUSSEE', '');
		INSERT INTO l_ptech_nature VALUES ('L4C', 'CHAMBRE L4C', '');
		INSERT INTO l_ptech_nature VALUES ('L4T', 'CHAMBRE L4T', '');
		INSERT INTO l_ptech_nature VALUES ('L4TR', 'CHAMBRE L4T REHAUSSEE', '');
		INSERT INTO l_ptech_nature VALUES ('L5C', 'CHAMBRE L5C', '');
		INSERT INTO l_ptech_nature VALUES ('L5T', 'CHAMBRE L5T', '');
		INSERT INTO l_ptech_nature VALUES ('L5TR', 'CHAMBRE L5T REHAUSSEE', '');
		INSERT INTO l_ptech_nature VALUES ('L6T', 'CHAMBRE L6T', '');
		INSERT INTO l_ptech_nature VALUES ('L6TR', 'CHAMBRE L6T REHAUSSEE', '');
		INSERT INTO l_ptech_nature VALUES ('M1C', 'CHAMBRE M1C', '');
		INSERT INTO l_ptech_nature VALUES ('M1CR', 'CHAMBRE M1C REHAUSSEE', '');
		INSERT INTO l_ptech_nature VALUES ('M2T', 'CHAMBRE M2T', '');
		INSERT INTO l_ptech_nature VALUES ('M2TR', 'CHAMBRE M2T REHAUSSEE', '');
		INSERT INTO l_ptech_nature VALUES ('M3C', 'CHAMBRE M3C', '');
		INSERT INTO l_ptech_nature VALUES ('M3CR', 'CHAMBRE M3C REHAUSSEE', '');
		INSERT INTO l_ptech_nature VALUES ('P1C', 'CHAMBRE P1C', '');
		INSERT INTO l_ptech_nature VALUES ('P1CR', 'CHAMBRE P1C REHAUSSEE', '');
		INSERT INTO l_ptech_nature VALUES ('P1T', 'CHAMBRE P1T', '');
		INSERT INTO l_ptech_nature VALUES ('P1TR', 'CHAMBRE P1T REHAUSSEE', '');
		INSERT INTO l_ptech_nature VALUES ('P2C', 'CHAMBRE P2C', '');
		INSERT INTO l_ptech_nature VALUES ('P2CR', 'CHAMBRE P2C REHAUSSEE', '');
		INSERT INTO l_ptech_nature VALUES ('P2T', 'CHAMBRE P2T', '');
		INSERT INTO l_ptech_nature VALUES ('P2TR', 'CHAMBRE P2T REHAUSSEE', '');
		INSERT INTO l_ptech_nature VALUES ('P3C', 'CHAMBRE P3C', '');
		INSERT INTO l_ptech_nature VALUES ('P3T', 'CHAMBRE P3T', '');
		INSERT INTO l_ptech_nature VALUES ('P4C', 'CHAMBRE P4C', '');
		INSERT INTO l_ptech_nature VALUES ('P4T', 'CHAMBRE P4T', '');
		INSERT INTO l_ptech_nature VALUES ('P5C', 'CHAMBRE P5C', '');
		INSERT INTO l_ptech_nature VALUES ('P5T', 'CHAMBRE P5T', '');
		INSERT INTO l_ptech_nature VALUES ('P6C', 'CHAMBRE P6C', '');
		INSERT INTO l_ptech_nature VALUES ('P6T', 'CHAMBRE P6T', '');
		INSERT INTO l_ptech_nature VALUES ('R1T', 'CHAMBRE R1T', '');
		INSERT INTO l_ptech_nature VALUES ('R2T', 'CHAMBRE R2T', '');
		INSERT INTO l_ptech_nature VALUES ('R3T', 'CHAMBRE R3T', '');
		INSERT INTO l_ptech_nature VALUES ('S1', 'CHAMBRE S1', 'SNCF Reseau : Chambre prefabriquee aux dimensions standardisees. ');
		INSERT INTO l_ptech_nature VALUES ('S2', 'CHAMBRE S2', 'SNCF Reseau : Chambre prefabriquee aux dimensions standardisees. ');
		INSERT INTO l_ptech_nature VALUES ('S3', 'CHAMBRE S3', 'SNCF Reseau : Chambre prefabriquee aux dimensions standardisees. ');
		INSERT INTO l_ptech_nature VALUES ('S4', 'CHAMBRE S4', 'SNCF Reseau : Chambre prefabriquee aux dimensions standardisees. ');
		INSERT INTO l_ptech_nature VALUES ('S5', 'CHAMBRE S5', 'SNCF Reseau : Chambre prefabriquee aux dimensions standardisees. ');
		INSERT INTO l_ptech_nature VALUES ('S6', 'CHAMBRE S6', 'SNCF Reseau : Chambre prefabriquee aux dimensions standardisees. ');
		INSERT INTO l_ptech_nature VALUES ('S6bis', 'CHAMBRE S6bis', 'SNCF Reseau : Chambre prefabriquee aux dimensions standardisees. ');
		INSERT INTO l_ptech_nature VALUES ('S7', 'CHAMBRE S7', 'SNCF Reseau : Chambre prefabriquee aux dimensions standardisees. ');
		INSERT INTO l_ptech_nature VALUES ('TU1', 'CHAMBRE TU1', 'SNCF Reseau : chambre avec trappes unifiees. ');
		INSERT INTO l_ptech_nature VALUES ('TU2', 'CHAMBRE TU2', 'SNCF Reseau : chambre avec trappes unifiees. ');
		INSERT INTO l_ptech_nature VALUES ('TU4', 'CHAMBRE TU4', 'SNCF Reseau : chambre avec trappes unifiees. ');
		INSERT INTO l_ptech_nature VALUES ('TU6', 'CHAMBRE TU6', 'SNCF Reseau : chambre avec trappes unifiees. ');
		INSERT INTO l_ptech_nature VALUES ('TU8', 'CHAMBRE TU8', 'SNCF Reseau : chambre avec trappes unifiees. ');
		INSERT INTO l_ptech_nature VALUES ('TU10', 'CHAMBRE TU10', 'SNCF Reseau : chambre avec trappes unifiees. ');
		INSERT INTO l_ptech_nature VALUES ('OHN', 'OUVRAGE HORS NORMES', '');
		INSERT INTO l_ptech_nature VALUES ('PBOI', 'POTEAU BOIS', '');
		INSERT INTO l_ptech_nature VALUES ('PBET', 'POTEAU BETON', '');
		INSERT INTO l_ptech_nature VALUES ('PMET', 'POTEAU METAL', '');
		INSERT INTO l_ptech_nature VALUES ('PIND', 'POTEAU INDETERMINE', '');
		INSERT INTO l_ptech_nature VALUES ('POTL', 'POTELET', '');
		INSERT INTO l_ptech_nature VALUES ('BOU', 'BOUCHON', '');
		INSERT INTO l_ptech_nature VALUES ('REG', 'REGARD 30X30', '');
		INSERT INTO l_ptech_nature VALUES ('BAL', 'BALCON', '');
		INSERT INTO l_ptech_nature VALUES ('CRO', 'CROCHET', '');
		INSERT INTO l_ptech_nature VALUES ('FAI', 'FAITIERE', '');
		INSERT INTO l_ptech_nature VALUES ('STR', 'SOUTERRAIN', '');
		INSERT INTO l_ptech_nature VALUES ('SSO', 'SOUS-SOL', '');
		INSERT INTO l_ptech_nature VALUES ('TRA', 'TRAVERSE', '');
		INSERT INTO l_ptech_nature VALUES ('Y', 'SITE MANCHONNAGE Y', 'Fenêtre ouverture sur fourreaux existant pour mise en Y');
		INSERT INTO l_ptech_nature VALUES ('IND', 'INDETERMINE', '');
		INSERT INTO l_ptech_type_log VALUES ('T', 'TIRAGE', '');
		INSERT INTO l_ptech_type_log VALUES ('R', 'RACCORDEMENT', '');
		INSERT INTO l_ptech_type_log VALUES ('I', 'INDETERMINE', '');
		INSERT INTO l_ptech_type_phy VALUES ('A', 'APPUI', '');
		INSERT INTO l_ptech_type_phy VALUES ('C', 'CHAMBRE', '');
		INSERT INTO l_ptech_type_phy VALUES ('F', 'ANCRAGE FACADE', '');
		INSERT INTO l_ptech_type_phy VALUES ('I', 'IMMEUBLE', '');
		INSERT INTO l_ptech_type_phy VALUES ('Z', 'AUTRE', '');
		INSERT INTO l_qualite_info VALUES ('VA', 'VALIDE', '');
		INSERT INTO l_qualite_info VALUES ('TH', 'THEORIQUE', '');
		INSERT INTO l_qualite_info VALUES ('NC', 'NON COMMUNIQUE', '');
		INSERT INTO l_reference_etat VALUES ('A', 'ACTIVE', '');
		INSERT INTO l_reference_etat VALUES ('N', 'NON DISPONIBLE', '');
		INSERT INTO l_reference_type VALUES ('BA', 'BAIE', '');
		INSERT INTO l_reference_type VALUES ('BP', 'BPE', '');
		INSERT INTO l_reference_type VALUES ('CA', 'CABLE', '');
		INSERT INTO l_reference_type VALUES ('CS', 'CASSETTE', '');
		INSERT INTO l_reference_type VALUES ('EQ', 'EQUIPEMENT', '');
		INSERT INTO l_reference_type VALUES ('PT', 'POINT TECHNIQUE', '');
		INSERT INTO l_reference_type VALUES ('TI', 'TIROIR', '');
		INSERT INTO l_site_emission_type VALUES ('RADIO', 'RADIODIFFUSION', '');
		INSERT INTO l_site_emission_type VALUES ('TEL', 'RADIO TELEPHONIE', '');
		INSERT INTO l_site_emission_type VALUES ('BLR', 'BOUCLE LOCALE RADIO', '');
		INSERT INTO l_site_emission_type VALUES ('FH', 'FAISCEAU HERTZIEN', '');
		INSERT INTO l_site_emission_type VALUES ('WIFI', 'WIFI', '');
		INSERT INTO l_site_emission_type VALUES ('WIMAX', 'WIMAX', '');
		INSERT INTO l_site_type_log VALUES ('NRA', 'NŒUD RACCORDEMENT D ABONNES', '');
		INSERT INTO l_site_type_log VALUES ('NRAHD', 'NŒUD RACCORDEMENT D ABONNES - HAUT DEBIT', '');
		INSERT INTO l_site_type_log VALUES ('NRAMED', 'NŒUD RACCORDEMENT D ABONNES - MONTEE EN DEBIT', '');
		INSERT INTO l_site_type_log VALUES ('NRAZO', 'NŒUD RACCORDEMENT D ABONNES - ZONE D OMBRE', '');
		INSERT INTO l_site_type_log VALUES ('SRP', 'SOUS-REPARTITEUR CUIVRE PRIMAIRE', '');
		INSERT INTO l_site_type_log VALUES ('SRS', 'SOUS-REPARTITEUR CUIVRE SECONDAIRE', '');
		INSERT INTO l_site_type_log VALUES ('SRT', 'SOUS-REPARTITEUR CUIVRE TERTIAIRE', '');
		INSERT INTO l_site_type_log VALUES ('NRO', 'NŒUD RACCORDEMENT OPTIQUE', '');
		INSERT INTO l_site_type_log VALUES ('SRO', 'SOUS-REPARTITEUR OPTIQUE', '');
		INSERT INTO l_site_type_log VALUES ('SROL', 'SOUS-REPARTITEUR OPTIQUE COLOCALISE', 'Sous-repartiteur localise dans le NRO. ');
		INSERT INTO l_site_type_log VALUES ('BRASSAGE', 'SITE DE BRASSAGE', 'Site non prevu pour heberger des equipements actifs (surtout longue distance)');
		INSERT INTO l_site_type_log VALUES ('CLIENT', 'SITE CLIENT', 'Site entreprise ou administration qui n est pas un site utilisateur final (SUF). ');
		INSERT INTO l_site_type_log VALUES ('HEBERG', 'SITE HEBERGEMENT', 'Site d hebergement d equipements actifs qui n est pas un NRO (hors architecture FTTH). ');
		INSERT INTO l_site_type_phy VALUES ('ADR', 'ARMOIRE DE RUE', '');
		INSERT INTO l_site_type_phy VALUES ('BAT', 'BATIMENT', '');
		INSERT INTO l_site_type_phy VALUES ('COF', 'COFFRET', 'Notamment coffrets qui peuvent etre fixes sur des appuis et qui font office d armoires. ');
		INSERT INTO l_site_type_phy VALUES ('SHE', 'SHELTER', '');
		INSERT INTO l_sro_etat VALUES ('PL', 'PLANIFIE', '');
		INSERT INTO l_sro_etat VALUES ('EC', 'EN COURS DE DEPLOIEMENT', 'En cours d installation, sans qu une definition precise n ait ete partagee en Interop. ');
		INSERT INTO l_sro_etat VALUES ('DP', 'DEPLOYE', 'Installe. Doit alors etre mis a disposition des operateurs ayant achete le PM. ');
		INSERT INTO l_sro_etat VALUES ('AB', 'ABANDONNE', 'Le PM est abandonne. Cet etat doit apparaitre pendant 3 mois.');
		INSERT INTO l_sro_emplacement VALUES ('ADR', 'PME-ARMOIRE DE RUE', 'PM Exterieur au sens de la reglementation, contenu dans une armoire de rue. ');
		INSERT INTO l_sro_emplacement VALUES ('SHE', 'PME-SHELTER', 'PM Exterieur au sens de la reglementation, contenu dans un shelter');
		INSERT INTO l_sro_emplacement VALUES ('LTE', 'PME-LOCAL TECHNIQUE', 'PM Exterieur au sens de la reglementation, contenu dans un local technique, par exemple NRO. ');
		INSERT INTO l_sro_emplacement VALUES ('PME', 'PM-EXTERIEUR', 'PM Exterieur au sens de la reglementation, dont l information du contenu n est pas disponible dans le SI de l OI. ');
		INSERT INTO l_sro_emplacement VALUES ('PMI', 'PM-INTERIEUR', 'Situe dans une partie privative necessitant l accord d un tiers (syndic, gestionnaire) en plus de l accord de l OI. ');
		INSERT INTO l_statut VALUES ('PRE', 'ETUDE PRELIMINAIRE', 'Resultat de l etude preliminaire, au sens du decret d application de la loi MOP (n°93-1268 du 29 nov. 1993) : premiere etude de faisabilite pour la construction d ouvrages neufs');
		INSERT INTO l_statut VALUES ('DIA', 'ETUDE DE DIAGNOSTIC', 'Resultat de l etude de diagnostic, au sens du decret d application de la loi MOP (n°93-1268 du 29 nov. 1993) : pour une operation de reutilisation ou de rehabilitation d un ouvrage existant, etat des lieux, analyse technique, etudes complementaires');
		INSERT INTO l_statut VALUES ('AVP', 'AVANT-PROJET', 'Resultat de l etude d avant-Projet, au sens du decret d application de la loi MOP (n°93-1268 du 29 nov. 1993) : confirmation de la faisabilite, premiere implantation de l ouvrage, autorisations administratives');
		INSERT INTO l_statut VALUES ('PRO', 'PROJET', 'Resultat de l etude de projet, au sens du decret d application de la loi MOP (n°93-1268 du 29 nov. 1993) : precise les choix techniques, fixe l implantation topographique, les caracteristiques et le dimensionnement');
		INSERT INTO l_statut VALUES ('ACT', 'PASSATION DES MARCHES DE TRAVAUX', 'Resultat de la mission d assistance a la passation des marches de travaux, au sens du decret d application de la loi MOP (n°93-1268 du 29 nov. 1993) : mise a jour eventuelle de l etude projet ');
		INSERT INTO l_statut VALUES ('EXE', 'ETUDE D EXECUTION', 'Resultat de l etude d execution, au sens du decret d application de la loi MOP (n°93-1268 du 29 nov. 1993) : elaboration des documents a l usage du chantier. Le resultat de cette etude donne generalement lieu a un VISA du maître d oeuvre.');
		INSERT INTO l_statut VALUES ('TVX', 'TRAVAUX', 'Resultat des missions de direction de l execution des travaux, d ordonnancement, de coordination et de pilotage  ainsi que les operations prealables a la reception des travaux, au sens du decret d application de la loi MOP (n°93-1268 du 29 nov. 1993)');
		INSERT INTO l_statut VALUES ('REC', 'RECOLEMENT', 'Resultat de la mission d assistance a la reception des travaux, au sens du decret d application de la loi MOP (n°93-1268 du 29 nov. 1993) : inclus le recolement des ouvrages et la realisation du Dossier des Ouvrages Executes');
		INSERT INTO l_statut VALUES ('MCO', 'MAINTIENT EN CONDITIONS OPERATIONNELLES', 'Le statut MCO permet d identifier les objets qui font l objet d une operation de maintenance, avant le passage en statut REC une fois l operation achevee et son recolement realise');
		INSERT INTO l_suf_racco VALUES ('AB', 'ABONNE', 'Logement dont l occupant a souscrit un abonnement a une offre d un operateur commercial sur un reseau en fibre optique jusqu a l abonne. ');
		INSERT INTO l_suf_racco VALUES ('RA', 'RACCORDE', 'Logement pour lequel il existe une continuite entre le PM et la PTO. ');
		INSERT INTO l_suf_racco VALUES ('RB', 'RACCORDABLE', 'Logement pour lequel il existe une continuite optique entre le PM et le PBO, ou entre le PM et la PTO si le PBO est absent. ');
		INSERT INTO l_suf_racco VALUES ('RD', 'RACCORDABLE SUR DEMANDE', 'Deploiement differe de PBO sous certaines conditions. ');
		INSERT INTO l_suf_racco VALUES ('EL', 'ELIGIBLE', 'Logement pour lequel au moins un operateur a relie le point de mutualisation a son NRO, et pour lequel il manque seulement le raccordement final et un eventuel  brassage au PM pour avoir une continuite optique entre le NRO et la PTO. ');
		INSERT INTO l_suf_racco VALUES ('EM', 'ELIGIBLE MUTUALISE', 'Logement eligible pour lequel plusieurs operateurs ont relie le PM a leur NRO. ');
		INSERT INTO l_suf_racco VALUES ('PR', 'PROGRAMME', 'Logement situe dans la zone arriere d un PM pour lequel le PM a ete installe et mis  a disposition des operateurs tiers, au sens de l annexe OO de la decision 2009-1106. ');
		INSERT INTO l_suf_type VALUES ('R', 'RESIDENTIEL', '');
		INSERT INTO l_suf_type VALUES ('P', 'PROFESSIONNEL', '');
		INSERT INTO l_suf_type VALUES ('O', 'OPERATEUR', '');
		INSERT INTO l_suf_type VALUES ('T', 'TECHNIQUE', '');
		INSERT INTO l_technologie_type VALUES ('CUT', 'CUIVRE TELECOM', '');
		INSERT INTO l_technologie_type VALUES ('OPT', 'OPTIQUE', '');
		INSERT INTO l_technologie_type VALUES ('COA', 'COAXIAL', '');
		INSERT INTO l_technologie_type VALUES ('ECL', 'ECLAIRAGE', '');
		INSERT INTO l_technologie_type VALUES ('ELE', 'ELECTRICITE', '');
		INSERT INTO l_technologie_type VALUES ('VID', 'VIDEO PROTECTION', '');
		INSERT INTO l_technologie_type VALUES ('RAD', 'RADIO', '');
		INSERT INTO l_tiroir_type VALUES ('TIROIR', 'TIROIR', '');
		INSERT INTO l_tiroir_type VALUES ('TETE', 'TETE DE CABLE', '');
		INSERT INTO l_tube VALUES ('1', 'SOUS FAISCEAU ROUGE UNE BAGUE COURTE', '');
		INSERT INTO l_tube VALUES ('2', 'SOUS FAISCEAU BLEU DEUX BAGUES COURTES', '');
		INSERT INTO l_tube VALUES ('3', 'SOUS FAISCEAU VERT TROIS BAGUES COURTES', '');
		INSERT INTO l_tube VALUES ('4', 'SOUS FAISCEAU JAUNE QUATRE BAGUES COURTES', '');
		INSERT INTO l_tube VALUES ('5', 'SOUS FAISCEAU VIOLET UNE BAGUE LONGUE', '');
		INSERT INTO l_tube VALUES ('6', 'SOUS FAISCEAU BLANC UNE BAGUE LONGUE ET UNE BAGUE COURTE', '');
		INSERT INTO l_tube VALUES ('1.1', 'ROUGE (R)', '#FF0000 - Standard Orange');
		INSERT INTO l_tube VALUES ('1.2', 'BLEU (BL)', '#0070C0 - Standard Orange');
		INSERT INTO l_tube VALUES ('1.3', 'VERT (VE)', '#92D050 - Standard Orange');
		INSERT INTO l_tube VALUES ('1.4', 'JAUNE (J)', '#FFFF00 - Standard Orange');
		INSERT INTO l_tube VALUES ('1.5', 'VIOLET (V)', '#7638A3 - Standard Orange');
		INSERT INTO l_tube VALUES ('1.6', 'BLANC (B)', '#FFFFFF - Standard Orange');
		INSERT INTO l_tube VALUES ('1.7', 'ORANGE (OR)', '#FFC000 - Standard Orange');
		INSERT INTO l_tube VALUES ('1.8', 'GRIS (GR)', '#C1C1C1 - Standard Orange');
		INSERT INTO l_tube VALUES ('1.9', 'MARRON (BR)', '#993300 - Standard Orange');
		INSERT INTO l_tube VALUES ('1.10', 'NOIR (N)', '#000000 - Standard Orange');
		INSERT INTO l_tube VALUES ('1.11', 'TURQUOISE (TU)', '#00B0F0 - Standard Orange');
		INSERT INTO l_tube VALUES ('1.12', 'ROSE (RS)', '#FF65CC - une bague noire - Standard Orange');
		INSERT INTO l_tube VALUES ('1.13', 'ROUGE (R) UNE BAGUE NOIRE', '#FF0000 - une bague noire - Standard Orange');
		INSERT INTO l_tube VALUES ('1.14', 'BLEU (BL) UNE BAGUE NOIRE', '#0070C0 - une bague noire - Standard Orange');
		INSERT INTO l_tube VALUES ('1.15', 'VERT (VE) UNE BAGUE NOIRE', '#92D050 - une bague noire - Standard Orange');
		INSERT INTO l_tube VALUES ('1.16', 'JAUNE (J) UNE BAGUE NOIRE', '#FFFF00 - une bague noire - Standard Orange');
		INSERT INTO l_tube VALUES ('1.17', 'VIOLET (V) UNE BAGUE NOIRE', '#7638A3 - une bague noire - Standard Orange');
		INSERT INTO l_tube VALUES ('1.18', 'BLANC (B) UNE BAGUE NOIRE', '#FFFFFF - une bague noire - Standard Orange');
		INSERT INTO l_tube VALUES ('1.19', 'ORANGE (OR) UNE BAGUE NOIRE', '#FFC000 - une bague noire - Standard Orange');
		INSERT INTO l_tube VALUES ('1.20', 'GRIS (GR) UNE BAGUE NOIRE', '#C1C1C1 - une bague noire - Standard Orange');
		INSERT INTO l_tube VALUES ('1.21', 'MARRON (BR) UNE BAGUE NOIRE', '#993300 - une bague noire - Standard Orange');
		INSERT INTO l_tube VALUES ('1.22', 'NOIR (N) UNE BAGUE NOIRE', '#000000 - une bague noire - Standard Orange');
		INSERT INTO l_tube VALUES ('1.23', 'TURQUOISE (TU) UNE BAGUE NOIRE', '#00B0F0 - une bague noire - Standard Orange');
		INSERT INTO l_tube VALUES ('1.24', 'ROSE (RS) UNE BAGUE NOIRE', '#FF65CC - une bague noire - Standard Orange');
		INSERT INTO l_tube VALUES ('1.25', 'ROUGE (R) DEUX BAGUES NOIRES', '#FF0000 - deux bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.26', 'BLEU (BL) DEUX BAGUES NOIRES', '#0070C0 - deux bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.27', 'VERT (VE) DEUX BAGUES NOIRES', '#92D050 - deux bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.28', 'JADEUX (J) DEUX BAGUES NOIRES', '#FFFF00 - deux bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.29', 'VIOLET (V) DEUX BAGUES NOIRES', '#7638A3 - deux bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.30', 'BLANC (B) DEUX BAGUES NOIRES', '#FFFFFF - deux bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.31', 'ORANGE (OR) DEUX BAGUES NOIRES', '#FFC000 - deux bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.32', 'GRIS (GR) DEUX BAGUES NOIRES', '#C1C1C1 - deux bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.33', 'MARRON (BR) DEUX BAGUES NOIRES', '#993300 - deux bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.34', 'NOIR (N) DEUX BAGUES NOIRES', '#000000 - deux bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.35', 'TURQUOISE (TU) DEUX BAGUES NOIRES', '#00B0F0 - deux bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.36', 'ROSE (RS) DEUX BAGUES NOIRES', '#FF65CC - deux bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.37', 'ROUGE (R) TROIS BAGUES NOIRES', '#FF0000 - trois bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.38', 'BLEU (BL) TROIS BAGUES NOIRES', '#0070C0 - trois bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.39', 'VERT (VE) TROIS BAGUES NOIRES', '#92D050 - trois bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.40', 'JATROIS (J) TROIS BAGUES NOIRES', '#FFFF00 - trois bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.41', 'VIOLET (V) TROIS BAGUES NOIRES', '#7638A3 - trois bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.42', 'BLANC (B) TROIS BAGUES NOIRES', '#FFFFFF - trois bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.43', 'ORANGE (OR) TROIS BAGUES NOIRES', '#FFC000 - trois bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.44', 'GRIS (GR) TROIS BAGUES NOIRES', '#C1C1C1 - trois bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.45', 'MARRON (BR) TROIS BAGUES NOIRES', '#993300 - trois bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.46', 'NOIR (N) TROIS BAGUES NOIRES', '#000000 - trois bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.47', 'TURQUOISE (TU) TROIS BAGUES NOIRES', '#00B0F0 - trois bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.48', 'ROSE (RS) TROIS BAGUES NOIRES', '#FF65CC - trois bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.49', 'ROUGE (R) QUATRE BAGUES NOIRES', '#FF0000 - quatre bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.50', 'BLEU (BL) QUATRE BAGUES NOIRES', '#0070C0 - quatre bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.51', 'VERT (VE) QUATRE BAGUES NOIRES', '#92D050 - quatre bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.52', 'JAQUATRE (J) QUATRE BAGUES NOIRES', '#FFFF00 - quatre bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.53', 'VIOLET (V) QUATRE BAGUES NOIRES', '#7638A3 - quatre bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.54', 'BLANC (B) QUATRE BAGUES NOIRES', '#FFFFFF - quatre bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.55', 'ORANGE (OR) QUATRE BAGUES NOIRES', '#FFC000 - quatre bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.56', 'GRIS (GR) QUATRE BAGUES NOIRES', '#C1C1C1 - quatre bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.57', 'MARRON (BR) QUATRE BAGUES NOIRES', '#993300 - quatre bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.58', 'NOIR (N) QUATRE BAGUES NOIRES', '#000000 - quatre bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.59', 'TURQUOISE (TU) QUATRE BAGUES NOIRES', '#00B0F0 - quatre bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.60', 'ROSE (RS) QUATRE BAGUES NOIRES', '#FF65CC - quatre bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.61', 'ROUGE (R) CINQ BAGUES NOIRES', '#FF0000 - cinq bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.62', 'BLEU (BL) CINQ BAGUES NOIRES', '#0070C0 - cinq bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.63', 'VERT (VE) CINQ BAGUES NOIRES', '#92D050 - cinq bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.64', 'JACINQ (J) CINQ BAGUES NOIRES', '#FFFF00 - cinq bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.65', 'VIOLET (V) CINQ BAGUES NOIRES', '#7638A3 - cinq bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.66', 'BLANC (B) CINQ BAGUES NOIRES', '#FFFFFF - cinq bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.67', 'ORANGE (OR) CINQ BAGUES NOIRES', '#FFC000 - cinq bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.68', 'GRIS (GR) CINQ BAGUES NOIRES', '#C1C1C1 - cinq bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.69', 'MARRON (BR) CINQ BAGUES NOIRES', '#993300 - cinq bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.70', 'NOIR (N) CINQ BAGUES NOIRES', '#000000 - cinq bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.71', 'TURQUOISE (TU) CINQ BAGUES NOIRES', '#00B0F0 - cinq bagues noires - Standard Orange');
		INSERT INTO l_tube VALUES ('1.72', 'ROSE (RS) CINQ BAGUES NOIRES', '#FF65CC - cinq bagues noires - Standard Orange');
		INSERT INTO l_zone_densite VALUES ('2', 'ZTD BASSE DENSITE', '');
		INSERT INTO l_zone_densite VALUES ('3', 'ZMD', '');

		COMMIT;



		DROP TABLE IF EXISTS t_refboite CASCADE;
		DROP TABLE IF EXISTS t_refcable CASCADE;
		DROP TABLE IF EXISTS contre_releve CASCADE;
		DROP TABLE IF EXISTS t_cheminement CASCADE;
		DROP TABLE IF EXISTS t_conduite CASCADE;
		DROP TABLE IF EXISTS t_cond_chem CASCADE;
		DROP TABLE IF EXISTS t_cable CASCADE;
		DROP TABLE IF EXISTS t_cableline CASCADE;
		DROP TABLE IF EXISTS t_cab_cond CASCADE;
		DROP TABLE IF EXISTS t_fibre CASCADE;
		DROP TABLE IF EXISTS t_cassette CASCADE;
		DROP TABLE IF EXISTS t_position CASCADE;
		DROP TABLE IF EXISTS t_ropt CASCADE;
		DROP TABLE IF EXISTS t_noeud CASCADE;
		DROP TABLE IF EXISTS t_ptech CASCADE;
		DROP TABLE IF EXISTS t_masque CASCADE;
		DROP TABLE IF EXISTS t_love CASCADE;
		DROP TABLE IF EXISTS t_ebp CASCADE;
		DROP TABLE IF EXISTS t_sitetech CASCADE;
		DROP TABLE IF EXISTS t_ltech CASCADE;
		DROP TABLE IF EXISTS t_baie CASCADE;
		DROP TABLE IF EXISTS t_tiroir CASCADE;
		DROP TABLE IF EXISTS t_equipement CASCADE;
		DROP TABLE IF EXISTS t_reference CASCADE;
		DROP TABLE IF EXISTS t_suf CASCADE;
		DROP TABLE IF EXISTS t_adresse CASCADE;
		DROP TABLE IF EXISTS t_siteemission CASCADE;
		DROP TABLE IF EXISTS t_organisme CASCADE;
		DROP TABLE IF EXISTS t_znro CASCADE;
		DROP TABLE IF EXISTS t_zsro CASCADE;
		DROP TABLE IF EXISTS t_zpbo CASCADE;
		DROP TABLE IF EXISTS t_zdep CASCADE;
		DROP TABLE IF EXISTS t_zcoax CASCADE;
		DROP TABLE IF EXISTS t_document CASCADE;
		DROP TABLE IF EXISTS t_docobj CASCADE;
		DROP TABLE IF EXISTS t_empreinte CASCADE;


		/*CREATE TABLE t_refboite
		(
			rb_code VARCHAR (254) NOT NULL,
			rb_rf_code VARCHAR (254) ,
			rb_ca_nbmax INTEGER ,
			rb_volume INTEGER ,
			rb_pressu BOOLEAN ,
			rb_creadat timestamp ,
			rb_majdate timestamp ,
			rb_majsrc VARCHAR (254) ,
			rb_abddate DATE ,
			rb_abdsrc VARCHAR(254)   ,
			CONSTRAINT t_refboite_pkey PRIMARY KEY (rb_code)
		) ;


		CREATE TABLE t_refcable
		(
			rc_code VARCHAR (254) NOT NULL,
			rc_rf_code VARCHAR (254) ,
			rc_capafo INTEGER ,
			rc_modulo INTEGER ,
			rc_diam INTEGER ,
			rc_typpose VARCHAR (2),
			rc_portee INTEGER ,
			rc_norm VARCHAR (254) ,
			rc_rfcomac VARCHAR (254) ,
			rc_ancref VARCHAR (254) ,
			CONSTRAINT t_refcable_pkey PRIMARY KEY (rc_code)
		) ;


		CREATE TABLE contre_releve
		(
			cr_id SERIAL PRIMARY KEY,
			pt_etiquet character varying(254) COLLATE pg_catalog."default",
			pt_nature character varying(254) COLLATE pg_catalog."default",
			commentaire_ethd character varying(254) COLLATE pg_catalog."default",
			validation_rd character varying(254) COLLATE pg_catalog."default",
			commentaire_rd character varying(254) COLLATE pg_catalog."default",
			geom geometry(Point,2154) NOT NULL)
			;

		CREATE TABLE t_adresse(ad_code VARCHAR (254) NOT NULL  ,
			ad_ban_id VARCHAR (24)   ,
			ad_nomvoie VARCHAR (254)   ,
			ad_fantoir VARCHAR (10)   ,
			ad_numero INTEGER   ,
			ad_rep VARCHAR (20)   ,
			ad_insee VARCHAR(6)   ,
			ad_postal VARCHAR(20)   ,
			ad_alias VARCHAR(254)   ,
			ad_nom_ld VARCHAR(254)   ,
			ad_x_ban NUMERIC   ,
			ad_y_ban NUMERIC   ,
			ad_commune VARCHAR (254)   ,
			ad_section VARCHAR (5)   ,
			ad_idpar VARCHAR (20)   ,
			ad_x_parc NUMERIC   ,
			ad_y_parc NUMERIC   ,
			ad_nat BOOLEAN   ,
			ad_nblhab INTEGER   ,
			ad_nblpro INTEGER   ,
			ad_nbprhab INTEGER   ,
			ad_nbprpro INTEGER   ,
			ad_rivoli VARCHAR (254)   ,
			ad_hexacle VARCHAR (254)   ,
			ad_hexaclv VARCHAR (254)   ,
			ad_distinf NUMERIC   ,
			ad_isole BOOLEAN   ,
			ad_prio BOOLEAN   ,
			ad_racc VARCHAR(2)   ,
			ad_batcode VARCHAR(100)  ,
			ad_nombat VARCHAR(254)   ,
			ad_ietat VARCHAR(2)   ,
			ad_itypeim VARCHAR (1)   ,
			ad_imneuf BOOLEAN   ,
			ad_idatimn DATE   ,
			ad_prop VARCHAR (254)   ,
			ad_gest VARCHAR (20)   ,
			ad_idatsgn DATE   ,
			ad_iaccgst BOOLEAN   ,
			ad_idatcab DATE   ,
			ad_idatcom DATE   ,
			ad_typzone VARCHAR (1)   ,
			ad_comment VARCHAR(254)   ,
			ad_geolqlt NUMERIC(6,2)   ,
			ad_geolmod VARCHAR(4)   ,
			ad_geolsrc VARCHAR(254)   ,
			ad_creadat TIMESTAMP   ,
			ad_majdate TIMESTAMP   ,
			ad_majsrc VARCHAR(254)   ,
			ad_abddate DATE   ,
			ad_abdsrc VARCHAR(254)   ,
			--ad_imp_d date  DEFAULT CURRENT_DATE,/
			--ad_id SERIAL
			geom Geometry(Point,2154) NOT NULL  ,
			CONSTRAINT "t_adresse_pk" PRIMARY KEY (ad_code));
			
		CREATE TABLE t_organisme(or_code VARCHAR (20) NOT NULL  ,
			or_siren VARCHAR(9)    ,
			or_nom VARCHAR(254)   ,
			or_type VARCHAR(254)   ,
			or_activ VARCHAR(254)   ,
			or_l331 VARCHAR(254)   ,
			or_siret VARCHAR(14)   ,
			or_nometab VARCHAR(254)   ,
			or_ad_code VARCHAR(254)   ,
			or_nomvoie VARCHAR (254)   ,
			or_numero INTEGER   ,
			or_rep VARCHAR (20)   ,
			or_local VARCHAR(254)   ,
			or_postal VARCHAR(20)   ,
			or_commune VARCHAR (254)   ,
			or_telfixe VARCHAR(20)  ,
			or_mail VARCHAR(254)   ,
			or_comment VARCHAR(254)   ,
			or_creadat TIMESTAMP   ,
			or_majdate TIMESTAMP   ,
			or_majsrc VARCHAR(254)   ,
			or_abddate DATE   ,
			or_abdsrc VARCHAR(254)   ,
			--or_imp_t date NOT NULL DEFAULT CURRENT_DATE,
		CONSTRAINT "t_organisme_pk" PRIMARY KEY (or_code));	
			
		CREATE TABLE t_reference(	rf_code VARCHAR(254) NOT NULL  ,
			rf_type VARCHAR(2)   ,
			rf_fabric VARCHAR(20)   ,
			rf_design VARCHAR(254)   ,
			rf_etat VARCHAR(1)   ,
			rf_comment VARCHAR(254)   ,
			rf_creadat TIMESTAMP   ,
			rf_majdate TIMESTAMP   ,
			rf_majsrc VARCHAR(254)   ,
			rf_abddate DATE   ,
			rf_abdsrc VARCHAR(254)   ,
			--rf_imp_t date NOT NULL DEFAULT CURRENT_DATE,
		CONSTRAINT "t_reference_pk" PRIMARY KEY (rf_code));	
			
		CREATE TABLE t_noeud(	nd_code VARCHAR(254) NOT NULL  ,
			nd_codeext VARCHAR(254)   ,
			nd_nom VARCHAR(254)   ,
			nd_coderat VARCHAR(254)   ,
			nd_r1_code VARCHAR(100)   ,
			nd_r2_code VARCHAR(100)   ,
			nd_r3_code VARCHAR(100)   ,
			nd_r4_code VARCHAR(100)   ,
			nd_voie VARCHAR(254)   ,
			nd_type VARCHAR(2)   ,
			nd_type_ep VARCHAR (3)   ,
			nd_comment VARCHAR(254)   ,
			nd_dtclass VARCHAR(2)   ,
			nd_geolqlt NUMERIC(6,2)   ,
			nd_geolmod VARCHAR(4)   ,
			nd_geolsrc VARCHAR(254)   ,
			nd_creadat TIMESTAMP   ,
			nd_majdate TIMESTAMP   ,
			nd_majsrc VARCHAR(254)   ,
			nd_abddate DATE   ,
			nd_abdsrc VARCHAR(254)   ,
			--nd_imp_t date NOT NULL DEFAULT CURRENT_DATE,
			geom Geometry(Point,2154) NOT NULL  ,
		CONSTRAINT "t_noeud_pk" PRIMARY KEY (nd_code));	
			
		CREATE TABLE t_znro(	zn_code VARCHAR(254) NOT NULL  ,
			zn_nd_code VARCHAR(254)  ,
			zn_r1_code VARCHAR(100)   ,
			zn_r2_code VARCHAR(100)   ,
			zn_r3_code VARCHAR(100)   ,
			zn_r4_code VARCHAR(100)   ,
			zn_nroref VARCHAR(15)   ,
			zn_nrotype VARCHAR(7)   ,
			zn_etat VARCHAR(2)   ,
			zn_etatlpm VARCHAR(2)   ,
			zn_datelpm DATE   ,
			zn_comment VARCHAR(254)   ,
			zn_geolsrc VARCHAR(254)   ,
			zn_creadat TIMESTAMP   ,
			zn_majdate TIMESTAMP   ,
			zn_majsrc VARCHAR(254)   ,
			zn_abddate DATE   ,
			zn_abdsrc VARCHAR(254)   ,
			--zn_imp_t date NOT NULL DEFAULT CURRENT_DATE,
			geom geometry(MultiPolygon,2154)   NOT NULL,
		CONSTRAINT "t_znro_pk" PRIMARY KEY (zn_code));	
			
		CREATE TABLE t_zsro(	zs_code VARCHAR(254) NOT NULL  ,
			zs_nd_code VARCHAR(254) ,
			zs_zn_code VARCHAR(254)   ,
			zs_r1_code VARCHAR(100)   ,
			zs_r2_code VARCHAR(100)   ,
			zs_r3_code VARCHAR(100)   ,
			zs_r4_code VARCHAR(100)   ,
			zs_refpm VARCHAR(20)   ,
			zs_etatpm VARCHAR(2)   ,
			zs_dateins DATE   ,
			zs_typeemp VARCHAR(3)   ,
			zs_capamax INTEGER   ,
			zs_ad_code VARCHAR(254)   ,
			zs_typeing VARCHAR(254)   ,
			zs_nblogmt INTEGER   ,
			zs_nbcolmt INTEGER   ,
			zs_datcomr DATE   ,
			zs_actif BOOLEAN  ,
			zs_datemad DATE   ,
			zs_accgest BOOLEAN   ,
			zs_brassoi BOOLEAN   ,
			zs_comment VARCHAR(254)   ,
			zs_geolsrc VARCHAR(254)   ,
			zs_creadat TIMESTAMP   ,
			zs_majdate TIMESTAMP   ,
			zs_majsrc VARCHAR(254)   ,
			zs_abddate DATE   ,
			zs_abdsrc VARCHAR(254)   ,
			--zs_imp_t date NOT NULL DEFAULT CURRENT_DATE,
			geom geometry(MultiPolygon,2154)   ,
		CONSTRAINT "t_zsro_pk" PRIMARY KEY (zs_code));	
			
		CREATE TABLE t_zpbo(	zp_code VARCHAR(254) NOT NULL  ,
			zp_nd_code VARCHAR(254)  ,
			zp_zs_code VARCHAR(254)   ,
			zp_r1_code VARCHAR(100)   ,
			zp_r2_code VARCHAR(100)   ,
			zp_r3_code VARCHAR(100)   ,
			zp_r4_code VARCHAR(100)   ,
			zp_capamax INTEGER   ,
			zp_comment VARCHAR(254)   ,
			zp_geolsrc VARCHAR(254)   ,
			zp_creadat TIMESTAMP   ,
			zp_majdate TIMESTAMP   ,
			zp_majsrc VARCHAR(254)   ,
			zp_abddate DATE   ,
			zp_abdsrc VARCHAR(254)   ,
			--zp_imp_t date NOT NULL DEFAULT CURRENT_DATE,
			geom geometry(MultiPolygon,2154)   ,
		CONSTRAINT "t_zpbo_pk" PRIMARY KEY (zp_code));	
			
		CREATE TABLE t_zdep(	zd_code VARCHAR(254) NOT NULL  ,
			zd_nd_code VARCHAR(254)   ,
			zd_zs_code VARCHAR(254)   ,
			zd_r1_code VARCHAR(100)   ,
			zd_r2_code VARCHAR(100)   ,
			zd_r3_code VARCHAR(100)   ,
			zd_r4_code VARCHAR(100)   ,
			zd_r5_code VARCHAR(100)   ,
			zd_r6_code VARCHAR(100)   ,
			zd_prop VARCHAR(20)   ,
			zd_gest VARCHAR(20)   ,
			zd_statut VARCHAR(3) ,
			zd_comment VARCHAR(254)   ,
			zd_geolsrc VARCHAR(254)   ,
			zd_creadat TIMESTAMP  ,
			zd_majdate TIMESTAMP   ,
			zd_majsrc VARCHAR(254)   ,
			zd_abddate DATE   ,
			zd_abdsrc VARCHAR(254)   ,
			zd_datefin DATE   ,
			--zd_imp_t date NOT NULL DEFAULT CURRENT_DATE,
			geom geometry(MultiPolygon,2154)   ,
		CONSTRAINT "t_zdep_pk" PRIMARY KEY (zd_code));	
			
		CREATE TABLE t_zcoax(	zc_code VARCHAR(254) NOT NULL  ,
			zc_codeext VARCHAR(254)   ,
			zc_nd_code VARCHAR(254)   ,
			zc_r1_code VARCHAR(100)   ,
			zc_r2_code VARCHAR(100)   ,
			zc_r3_code VARCHAR(100)   ,
			zc_r4_code VARCHAR(100)   ,
			zc_prop VARCHAR(20)   ,
			zc_gest VARCHAR(20)   ,
			zc_statut VARCHAR(3)  ,
			zc_comment VARCHAR(254)   ,
			zc_geolsrc VARCHAR(254)   ,
			zc_creadat TIMESTAMP   ,
			zc_majdate TIMESTAMP   ,
			zc_majsrc VARCHAR(254)   ,
			zc_abddate DATE   ,
			zc_abdsrc VARCHAR(254)   ,
			--zc_imp_t date NOT NULL DEFAULT CURRENT_DATE,
			geom geometry(MultiPolygon,2154)   ,
		CONSTRAINT "t_zcoax_pk" PRIMARY KEY (zc_code));
			
		CREATE TABLE t_sitetech(	st_code VARCHAR(254) NOT NULL  ,
			st_nd_code VARCHAR(254)    ,
			st_codeext VARCHAR (254)   ,
			st_nom VARCHAR (254)   ,
			st_prop VARCHAR(20)   ,
			st_gest VARCHAR(20)   ,
			st_user VARCHAR(20)   ,
			st_proptyp VARCHAR(3)   ,
			st_statut VARCHAR(3)  ,
			st_etat VARCHAR(3)   ,
			st_dateins DATE   ,
			st_datemes DATE   ,
			st_avct VARCHAR(1)   ,
			st_typephy VARCHAR(3)   ,
			st_typelog VARCHAR(10)   ,
			st_nblines INTEGER   ,
			st_ad_code VARCHAR(254)   ,
			st_comment VARCHAR(254)   ,
			st_creadat TIMESTAMP   ,
			st_majdate TIMESTAMP   ,
			st_majsrc VARCHAR(254)   ,
			st_abddate DATE   ,
			st_abdsrc VARCHAR(254)   ,
			--st_imp_t date NOT NULL DEFAULT CURRENT_DATE,
		CONSTRAINT "t_sitetech_pk" PRIMARY KEY (st_code));	
			
		CREATE TABLE t_ltech(	lt_code VARCHAR(254) NOT NULL  ,
			lt_codeext VARCHAR(254)   ,
			lt_etiquet VARCHAR(20)   ,
			lt_st_code VARCHAR(254) ,
			lt_prop VARCHAR(20)   ,
			lt_gest VARCHAR(20)   ,
			lt_user VARCHAR(20)   ,
			lt_proptyp VARCHAR(3)   ,
			lt_statut VARCHAR(3)  ,
			lt_etat VARCHAR(3)  ,
			lt_dateins DATE   ,
			lt_datemes DATE   ,
			lt_local VARCHAR (254)   ,
			lt_elec BOOLEAN   ,
			lt_clim VARCHAR(6)   ,
			lt_occp VARCHAR(10)   ,
			lt_idmajic VARCHAR(254)   ,
			lt_comment VARCHAR(254)   ,
			lt_creadat TIMESTAMP   ,
			lt_majdate TIMESTAMP   ,
			lt_majsrc VARCHAR(254)   ,
			lt_abddate DATE   ,
			lt_abdsrc VARCHAR(254)   ,
			--lt_imp_t date NOT NULL DEFAULT CURRENT_DATE,
		CONSTRAINT "t_ltech_pk" PRIMARY KEY (lt_code));	
			
		CREATE TABLE t_baie(	ba_code VARCHAR(254) NOT NULL  ,
			ba_codeext VARCHAR(254)   ,
			ba_etiquet VARCHAR(254)   ,
			ba_lt_code VARCHAR(254)   ,
			ba_prop VARCHAR(20)   ,
			ba_gest VARCHAR(20)   ,
			ba_user VARCHAR(20)   ,
			ba_proptyp VARCHAR(3)   ,
			ba_statut VARCHAR(3)   ,
			ba_etat VARCHAR(3)   ,
			ba_rf_code VARCHAR(254)   ,
			ba_type VARCHAR(10)   ,
			ba_nb_u NUMERIC   ,
			ba_haut NUMERIC   ,
			ba_larg NUMERIC   ,
			ba_prof NUMERIC   ,
			ba_comment VARCHAR(254)   ,
			ba_creadat TIMESTAMP   ,
			ba_majdate TIMESTAMP   ,
			ba_majsrc VARCHAR(254)   ,
			ba_abddate DATE   ,
			ba_abdsrc VARCHAR(254)   ,
			--ba_imp_t date NOT NULL DEFAULT CURRENT_DATE,
		CONSTRAINT "t_baie_pk" PRIMARY KEY (ba_code));	
			
		CREATE TABLE t_tiroir(	ti_code VARCHAR(254) NOT NULL  ,
			ti_codeext VARCHAR(254)   ,
			ti_etiquet VARCHAR(254)   ,
			ti_ba_code VARCHAR(254)   ,
			ti_prop VARCHAR(20)   ,
			ti_etat VARCHAR(3)   ,
			ti_type VARCHAR(10)  ,
			ti_rf_code VARCHAR(254)   ,
			ti_taille NUMERIC   ,
			ti_placemt NUMERIC   ,
			ti_localis VARCHAR(254)   ,
			ti_comment VARCHAR(254)   ,
			ti_creadat TIMESTAMP   ,
			ti_majdate TIMESTAMP   ,
			ti_majsrc VARCHAR(254)   ,
			ti_abddate DATE   ,
			ti_abdsrc VARCHAR(254)   ,
			--ti_imp_t date NOT NULL DEFAULT CURRENT_DATE,
		CONSTRAINT "t_tiroir_pk" PRIMARY KEY (ti_code));	
			
		CREATE TABLE t_equipement(	eq_code VARCHAR(254) NOT NULL  ,
			eq_codeext VARCHAR(254)   ,
			eq_etiquet VARCHAR(254)   ,
			eq_ba_code VARCHAR(254)   ,
			eq_prop VARCHAR(20)   ,
			eq_rf_code VARCHAR(254)   ,
			eq_dateins DATE   ,
			eq_datemes DATE   ,
			eq_comment VARCHAR(254)   ,
			eq_creadat TIMESTAMP   ,
			eq_majdate TIMESTAMP   ,
			eq_majsrc VARCHAR(254)   ,
			eq_abddate DATE   ,
			eq_abdsrc VARCHAR(254)   ,
			--eq_imp_t date NOT NULL DEFAULT CURRENT_DATE,
		CONSTRAINT "t_equipement_pk" PRIMARY KEY (eq_code));
			
		CREATE TABLE t_suf(	sf_code VARCHAR(254) NOT NULL  ,
			sf_nd_code VARCHAR(254)   ,
			sf_ad_code VARCHAR(254)   ,
			sf_zp_code VARCHAR(254)   ,
			sf_escal VARCHAR (20)   ,
			sf_etage VARCHAR (20)   ,
			sf_oper VARCHAR(20)   ,
			sf_type VARCHAR(1) ,
			sf_prop VARCHAR(254)   ,
			sf_resid VARCHAR(254)   ,
			sf_local VARCHAR (254)   ,
			sf_racco VARCHAR(2)   ,
			sf_comment VARCHAR(254)   ,
			sf_creadat TIMESTAMP    ,
			sf_majdate TIMESTAMP   ,
			sf_majsrc VARCHAR(254)   ,
			sf_abddate DATE   ,
			sf_abdsrc VARCHAR(254)   ,
			--sf_imp_t date NOT NULL DEFAULT CURRENT_DATE,
		CONSTRAINT "t_suf_pk" PRIMARY KEY (sf_code));	
			
			
			
		CREATE TABLE t_ptech(	pt_code VARCHAR(254) NOT NULL  ,
			pt_codeext Varchar(254)   ,
			pt_etiquet VARCHAR(254)   ,
			pt_nd_code VARCHAR(254)  ,
			pt_ad_code VARCHAR(254)   ,
			pt_gest_do VARCHAR(20)   ,
			pt_prop_do VARCHAR(20)   ,
			pt_prop VARCHAR(20)   ,
			pt_gest VARCHAR(20)   ,
			pt_user VARCHAR(20)   ,
			pt_proptyp VARCHAR(3)   ,
			pt_statut VARCHAR(3) ,
			pt_etat VARCHAR(3)   ,
			pt_dateins DATE   ,
			pt_datemes Date   ,
			pt_avct VARCHAR(1)   ,
			pt_typephy VARCHAR(1) ,
			pt_typelog VARCHAR(1) ,
			pt_rf_code VARCHAR(254)  ,
			pt_nature VARCHAR (20)   ,
			pt_secu BOOLEAN   ,
			pt_occp VARCHAR(10)   ,
			pt_a_dan NUMERIC   ,
			pt_a_dtetu DATE   ,
			pt_a_struc VARCHAR(100)   ,
			pt_a_haut NUMERIC(5,2)   ,
			pt_a_passa BOOLEAN   ,
			pt_a_strat BOOLEAN   ,
			pt_rotatio NUMERIC(5,2)   ,
			pt_detec BOOLEAN   ,
			pt_comment VARCHAR(254)   ,
			pt_creadat TIMESTAMP   ,
			pt_majdate TIMESTAMP   ,
			pt_majsrc VARCHAR(254)   ,
			pt_abddate DATE   ,
			pt_abdsrc VARCHAR(254)   ,
			--pt_imp_t date NOT NULL DEFAULT CURRENT_DATE,
		CONSTRAINT "t_ptech_pk" PRIMARY KEY (pt_code));	
			
		CREATE TABLE t_ebp(	bp_code VARCHAR(254) NOT NULL  ,
			bp_etiquet VARCHAR(254)   ,
			bp_codeext VARCHAR(254)   ,
			bp_pt_code VARCHAR(254)   ,
			bp_lt_code VARCHAR(254)   ,
			bp_sf_code VARCHAR(254)   ,
			bp_prop VARCHAR(20)   ,
			bp_gest VARCHAR(20)   ,
			bp_user VARCHAR(20)   ,
			bp_proptyp VARCHAR(3)   ,
			bp_statut VARCHAR(3) ,
			bp_etat VARCHAR(3)   ,
			bp_occp VARCHAR(10)   ,
			bp_datemes Date   ,
			bp_avct VARCHAR(1)   ,
			bp_typephy VARCHAR(5)   ,
			bp_typelog VARCHAR(3)  ,
			bp_rf_code VARCHAR(254)   ,
			bp_entrees INTEGER   ,
			bp_ref_kit VARCHAR(30)   ,
			bp_ca_nb INTEGER   ,
			bp_nb_pas INTEGER   ,
			bp_linecod VARCHAR(12)   ,
			bp_oc_code VARCHAR(50)   ,
			bp_racco VARCHAR(6)   ,
			bp_comment VARCHAR(254)   ,
			bp_creadat TIMESTAMP    ,
			bp_majdate TIMESTAMP   ,
			bp_majsrc VARCHAR(254)   ,
			bp_abddate DATE   ,
			bp_abdsrc VARCHAR(254)   ,
			--bp_imp_t date NOT NULL DEFAULT CURRENT_DATE,
		CONSTRAINT "t_ebp_pk" PRIMARY KEY (bp_code));	
			
		CREATE TABLE t_cassette(	cs_code VARCHAR(254) NOT NULL  ,
			cs_nb_pas INTEGER   ,
			cs_bp_code VARCHAR(254)   ,
			cs_num INTEGER    ,
			cs_type VARCHAR(1)   ,
			cs_face VARCHAR(20)   ,
			cs_rf_code VARCHAR(254)   ,
			cs_comment VARCHAR(254)   ,
			cs_creadat TIMESTAMP    ,
			cs_majdate TIMESTAMP   ,
			cs_majsrc VARCHAR(254)   ,
			cs_abddate DATE   ,
			cs_abdsrc VARCHAR(254)   ,
			--cs_imp_t date NOT NULL DEFAULT CURRENT_DATE,
		CONSTRAINT "t_cassette_pk" PRIMARY KEY (cs_code));	
			
		CREATE TABLE t_cheminement(	cm_code VARCHAR(254) NOT NULL  ,
			cm_codeext VARCHAR(254)   ,
			cm_ndcode1 VARCHAR(254)   ,
			cm_ndcode2 VARCHAR(254)   ,
			cm_cm1 VARCHAR(254)   ,
			cm_cm2 VARCHAR(254)   ,
			cm_r1_code VARCHAR(100)     ,
			cm_r2_code VARCHAR(100)   ,
			cm_r3_code VARCHAR(100)   ,
			cm_r4_code VARCHAR(100)   ,
			cm_voie VARCHAR(254)   ,
			cm_gest_do VARCHAR(20)   ,
			cm_prop_do VARCHAR(20)   ,
			cm_statut VARCHAR(3)   ,
			cm_etat VARCHAR(3)   ,
			cm_datcons DATE   ,
			cm_datemes DATE   ,
			cm_avct VARCHAR(1)   ,
			cm_typelog VARCHAR(2)   ,
			cm_typ_imp VARCHAR(2)   ,
			cm_nature VARCHAR(3)    ,
			cm_compo VARCHAR(254)   ,
			cm_cddispo INTEGER   ,
			cm_fo_util INTEGER    ,
			cm_mod_pos VARCHAR(20)   ,
			cm_passage VARCHAR(10)   ,
			cm_revet VARCHAR(254)   ,
			cm_remblai VARCHAR(254)   ,
			cm_charge NUMERIC(5,2)   ,
			cm_larg NUMERIC(4,2)   ,
			cm_fildtec BOOLEAN   ,
			cm_mut_org VARCHAR(20)   ,
			cm_long NUMERIC(8,2)    ,
			cm_lgreel NUMERIC(8,2)   ,
			cm_comment VARCHAR(254)   ,
			cm_dtclass VARCHAR(2)   ,
			cm_geolqlt NUMERIC(6,2)   ,
			cm_geolmod VARCHAR(4)   ,
			cm_geolsrc VARCHAR(254)   ,
			cm_creadat TIMESTAMP   ,
			cm_majdate TIMESTAMP   ,
			cm_majsrc VARCHAR(254)   ,
			cm_abddate DATE   ,
			cm_abdsrc VARCHAR(254)   ,
			cm_nom VARCHAR(254) ,
			--cm_imp_t date NOT NULL DEFAULT CURRENT_DATE,
			geom Geometry(Linestring,2154) NOT NULL  ,
		CONSTRAINT "t_cheminement_pk" PRIMARY KEY (cm_code));	
			
		CREATE TABLE t_conduite(	cd_code VARCHAR(254) NOT NULL  ,
			cd_codeext Varchar(254)   ,
			cd_etiquet VARCHAR(254)   ,
			cd_cd_code VARCHAR(254)   ,
			cd_r1_code VARCHAR(100)   ,
			cd_r2_code VARCHAR(100)   ,
			cd_r3_code VARCHAR(100)   ,
			cd_r4_code VARCHAR(100)   ,
			cd_prop VARCHAR(20)   ,
			cd_gest VARCHAR(20)   ,
			cd_user VARCHAR(20)   ,
			cd_proptyp VARCHAR(3)   ,
			cd_statut VARCHAR(3) ,
			cd_etat VARCHAR(3)   ,
			cd_dateaig DATE   ,
			cd_dateman DATE   ,
			cd_datemes Date   ,
			cd_avct VARCHAR(1)   ,
			cd_type VARCHAR(10)  ,
			cd_dia_int INTEGER   ,
			cd_dia_ext INTEGER   ,
			cd_color VARCHAR(254)   ,
			cd_long NUMERIC(8,2)   ,
			cd_nbcable INTEGER   ,
			cd_occup NUMERIC(3,0)   ,
			cd_comment VARCHAR(254)   ,
			cd_creadat TIMESTAMP     ,
			cd_majdate TIMESTAMP   ,
			cd_majsrc VARCHAR(254)   ,
			cd_abddate DATE   ,
			cd_abdsrc VARCHAR(254)   ,
			--cd_imp_t date NOT NULL DEFAULT CURRENT_DATE,
		CONSTRAINT "t_conduite_pk" PRIMARY KEY (cd_code));	
			
		CREATE TABLE t_cond_chem(	dm_cd_code VARCHAR(254) NOT NULL  REFERENCES t_conduite(cd_code),
			dm_cm_code VARCHAR(254) ,
			dm_creadat TIMESTAMP   ,
			dm_majdate TIMESTAMP   ,
			dm_majsrc VARCHAR(254)   ,
			dm_abddate DATE   ,
			dm_abdsrc VARCHAR(254)   ,
			--dm_imp_t date NOT NULL DEFAULT CURRENT_DATE,
		CONSTRAINT "t_cond_chem_pk" PRIMARY KEY (dm_cd_code, dm_cm_code));	
			
		CREATE TABLE t_masque(	mq_id BIGINT NOT NULL  ,
			mq_nd_code VARCHAR(254) ,
			mq_face VARCHAR(1) ,
			mq_col INTEGER ,
			mq_ligne INTEGER ,
			mq_cd_code VARCHAR(254)   ,
			mq_qualinf VARCHAR(3)   ,
			mq_comment VARCHAR(254)   ,
			mq_creadat TIMESTAMP   ,
			mq_majdate TIMESTAMP   ,
			mq_majsrc VARCHAR(254)   ,
			mq_abddate DATE   ,
			mq_abdsrc VARCHAR(254)   ,
			--mq_imp_t date NOT NULL DEFAULT CURRENT_DATE,
		CONSTRAINT "t_masque_pk" PRIMARY KEY (mq_id));	
			
		CREATE TABLE t_cable(	cb_code VARCHAR(254) NOT NULL  ,
			cb_codeext VARCHAR(254)   ,
			cb_etiquet VARCHAR(254)   ,
			cb_nd1 VARCHAR(254)    ,
			cb_nd2 VARCHAR(254)    ,
			cb_r1_code VARCHAR(100)   ,
			cb_r2_code VARCHAR(100)   ,
			cb_r3_code VARCHAR(100)   ,
			cb_r4_code VARCHAR(100)   ,
			cb_prop VARCHAR(20)    ,
			cb_gest VARCHAR(20)    ,
			cb_user VARCHAR(20)   ,
			cb_proptyp VARCHAR(3) ,
			cb_statut VARCHAR(3)  ,
			cb_etat VARCHAR(3)    ,
			cb_dateins DATE   ,
			cb_datemes DATE   ,
			cb_avct VARCHAR(1)   ,
			cb_tech VARCHAR(3)   ,
			cb_typephy VARCHAR(1) ,
			cb_typelog VARCHAR(2) ,
			cb_rf_code VARCHAR(254)  ,
			cb_capafo INTEGER   ,
			cb_fo_disp INTEGER   ,
			cb_fo_util INTEGER   ,
			cb_modulo INTEGER   ,
			cb_diam NUMERIC   ,
			cb_color VARCHAR(254)   ,
			cb_lgreel NUMERIC   ,
			cb_localis VARCHAR(254)   ,
			cb_comment VARCHAR(254)   ,
			cb_creadat TIMESTAMP   ,
			cb_majdate TIMESTAMP   ,
			cb_majsrc VARCHAR(254)   ,
			cb_abddate DATE   ,
			cb_abdsrc VARCHAR(254)   ,
			cb_bp1 VARCHAR(254)     ,
			cb_ba1 VARCHAR(254)     ,
			cb_bp2 VARCHAR(254)     ,
			cb_ba2 VARCHAR(254)     ,
			--cb_imp_t date NOT NULL DEFAULT CURRENT_DATE,
		CONSTRAINT "t_cable_pk" PRIMARY KEY (cb_code));	
			
		CREATE TABLE t_cableline(	cl_code VARCHAR(254) NOT NULL  ,
			cl_cb_code VARCHAR (254) UNIQUE REFERENCES t_cable(cb_code) ,
			cl_long NUMERIC   ,
			cl_comment VARCHAR(254)   ,
			cl_dtclass VARCHAR(2)   ,
			cl_geolqlt NUMERIC(6,2)   ,
			cl_geolmod VARCHAR(4)   ,
			cl_geolsrc VARCHAR(254)   ,
			cl_creadat TIMESTAMP   ,
			cl_majdate TIMESTAMP   ,
			cl_majsrc VARCHAR(254)   ,
			cl_abddate DATE   ,
			cl_abdsrc VARCHAR(254)   ,
			--cl_imp_t date NOT NULL DEFAULT CURRENT_DATE,
			geom Geometry(Linestring,2154) NOT NULL  ,
		CONSTRAINT "t_cableline_pk" PRIMARY KEY (cl_code));	
			
		CREATE TABLE t_cab_cond(	cc_cb_code VARCHAR(254) NOT NULL  REFERENCES t_cable(cb_code),
			cc_cd_code VARCHAR(254) ,
			cc_creadat TIMESTAMP   ,
			cc_majdate TIMESTAMP   ,
			cc_majsrc VARCHAR(254)   ,
			cc_abddate DATE   ,
			cc_abdsrc VARCHAR(254)   ,
			--cc_imp_t date NOT NULL DEFAULT CURRENT_DATE,
		CONSTRAINT "t_cab_cond_pk" PRIMARY KEY (cc_cb_code, cc_cd_code));	
			
		CREATE TABLE t_love(	lv_id BIGINT NOT NULL  ,
			lv_cb_code VARCHAR(254) ,
			lv_nd_code VARCHAR(254) ,
			lv_long INTEGER   ,
			lv_creadat TIMESTAMP   ,
			lv_majdate TIMESTAMP   ,
			lv_majsrc VARCHAR(254)   ,
			lv_abddate DATE   ,
			lv_abdsrc VARCHAR(254)   ,
			--lv_imp_t date NOT NULL DEFAULT CURRENT_DATE,
		CONSTRAINT "t_love_pk" PRIMARY KEY (lv_id));	
			
		CREATE TABLE t_fibre(	fo_code VARCHAR(254) NOT NULL  ,
			fo_code_ext VARCHAR(254)   ,
			fo_cb_code VARCHAR(254) ,
			fo_nincab INTEGER   ,
			fo_numtub INTEGER   ,
			fo_nintub INTEGER   ,
			fo_type VARCHAR(20)  ,
			fo_etat VARCHAR(3)   ,
			fo_color VARCHAR(10)   ,
			fo_reper VARCHAR(5)   ,
			fo_proptyp VARCHAR(3)   ,
			fo_comment VARCHAR(254)   ,
			fo_creadat TIMESTAMP   ,
			fo_majdate TIMESTAMP   ,
			fo_majsrc VARCHAR(254)   ,
			fo_abddate DATE   ,
			fo_abdsrc VARCHAR(254)   ,
			--fo_imp_t date NOT NULL DEFAULT CURRENT_DATE,
		CONSTRAINT "t_fibre_pk" PRIMARY KEY (fo_code));	
			
		CREATE TABLE t_position(	ps_code VARCHAR(254) NOT NULL  ,
			ps_numero INTEGER   ,
			ps_1 VARCHAR (254)    ,
			ps_2 VARCHAR (254)    ,
			ps_cs_code VARCHAR(254)   ,
			ps_ti_code VARCHAR(254)   ,
			ps_type VARCHAR(10)   ,
			ps_fonct VARCHAR(2)   ,
			ps_etat VARCHAR(3)    ,
			ps_preaff VARCHAR(50)    ,
			ps_comment VARCHAR(254)   ,
			ps_creadat TIMESTAMP    ,
			ps_majdate TIMESTAMP   ,
			ps_majsrc VARCHAR(254)   ,
			ps_abddate DATE   ,
			ps_abdsrc VARCHAR(254)   ,
			--ps_imp_t date NOT NULL DEFAULT CURRENT_DATE,
		CONSTRAINT "t_position_pk" PRIMARY KEY (ps_code));	
			
		CREATE TABLE t_ropt(	rt_id BIGINT NOT NULL  ,
			rt_code VARCHAR(254)  ,
			rt_code_ext VARCHAR(254)   ,
			rt_fo_code VARCHAR(254)  ,
			rt_fo_ordr INTEGER    ,
			rt_comment VARCHAR(254)   ,
			rt_creadat TIMESTAMP    ,
			rt_majdate TIMESTAMP   ,
			rt_majsrc VARCHAR(254)   ,
			rt_abddate DATE   ,
			rt_abdsrc VARCHAR(254)   ,
			--rt_imp_t date NOT NULL DEFAULT CURRENT_DATE,
		CONSTRAINT "t_ropt_pk" PRIMARY KEY (rt_id));	
			
		CREATE TABLE t_siteemission(	se_code VARCHAR(254) NOT NULL  ,
			se_nd_code VARCHAR(254)  ,
			se_anfr VARCHAR(50)   ,
			se_prop VARCHAR(20)   ,
			se_gest VARCHAR(20)   ,
			se_user VARCHAR(20)   ,
			se_proptyp VARCHAR(3)  ,
			se_statut VARCHAR(3)   ,
			se_etat VARCHAR(3)   ,
			se_occp VARCHAR(10)   ,
			se_dateins DATE   ,
			se_datemes DATE   ,
			se_type VARCHAR(10)  ,
			se_haut NUMERIC(5,2)   ,
			se_ad_code VARCHAR(254)  ,
			se_comment VARCHAR(254)   ,
			se_creadat TIMESTAMP   ,
			se_majdate TIMESTAMP   ,
			se_majsrc VARCHAR(254)   ,
			se_abddate DATE   ,
			se_abdsrc VARCHAR(254)   ,
			--se_imp_t date NOT NULL DEFAULT CURRENT_DATE,
		CONSTRAINT "t_siteemission_pk" PRIMARY KEY (se_code));	
			
		CREATE TABLE t_document(	do_code VARCHAR(254) NOT NULL  ,
			do_ref VARCHAR(254)   ,
			do_reftier VARCHAR(254)   ,
			do_r1_code VARCHAR(100)    ,
			do_r2_code VARCHAR(100)    ,
			do_r3_code VARCHAR(100)    ,
			do_r4_code VARCHAR(100)    ,
			do_type VARCHAR(3)   ,
			do_indice VARCHAR(3)   ,
			do_date DATE   ,
			do_classe VARCHAR(2)   ,
			do_url1 VARCHAR (254)   ,
			do_url2 VARCHAR (254)   ,
			do_comment VARCHAR(254)   ,
			do_creadat TIMESTAMP   ,
			do_majdate TIMESTAMP   ,
			do_majsrc VARCHAR(254)   ,
			do_abddate DATE   ,
			do_abdsrc VARCHAR(254)   ,
			--do_imp_t date NOT NULL DEFAULT CURRENT_DATE,
		CONSTRAINT "t_document_pk" PRIMARY KEY (do_code));	
			
		CREATE TABLE t_docobj(	od_id BIGINT NOT NULL  ,
			od_do_code VARCHAR(254)  ,
			od_tbltype VARCHAR(2)  ,
			od_codeobj VARCHAR(254)  ,
			od_creadat TIMESTAMP    ,
			od_majdate TIMESTAMP   ,
			od_majsrc VARCHAR(254)   ,
			od_abddate DATE   ,
			od_abdsrc VARCHAR(254)   ,
			--od_imp_t date NOT NULL DEFAULT CURRENT_DATE,
		CONSTRAINT "t_docobj_pk" PRIMARY KEY (od_id));	
			
		CREATE TABLE t_empreinte(	em_code VARCHAR(254) NOT NULL  ,
			em_do_code VARCHAR(254)   ,
			em_geolsrc VARCHAR(254)   ,
			em_creadat TIMESTAMP   ,
			em_majdate TIMESTAMP   ,
			em_majsrc VARCHAR(254)   ,
			em_abddate DATE   ,
			em_abdsrc VARCHAR(254)   ,
			--em_imp_t date NOT NULL DEFAULT CURRENT_DATE,
			geom geometry(MultiPolygon,2154)   ,
		CONSTRAINT "t_empreinte_pk" PRIMARY KEY (em_code));	*/
		
		
		CREATE TABLE t_refboite
		(
			rb_code text NOT NULL,
			rb_rf_code text ,
			rb_ca_nbmax text ,
			rb_volume text ,
			rb_pressu text ,
			rb_creadat text ,
			rb_majdate text ,
			rb_majsrc text ,
			rb_abddate text ,
			rb_abdsrc text   ,
			CONSTRAINT t_refboite_pkey PRIMARY KEY (rb_code)
		) ;


		CREATE TABLE t_refcable
		(
			rc_code text NOT NULL,
			rc_rf_code text ,
			rc_capafo text ,
			rc_modulo text ,
			rc_diam text ,
			rc_typpose text,
			rc_portee text ,
			rc_norm text ,
			rc_rfcomac text ,
			rc_ancref text ,
			CONSTRAINT t_refcable_pkey PRIMARY KEY (rc_code)
		) ;


		CREATE TABLE contre_releve
		(
			cr_id SERIAL PRIMARY KEY,
			pt_etiquet character varying(254) COLLATE pg_catalog."default",
			pt_nature character varying(254) COLLATE pg_catalog."default",
			commentaire_ethd character varying(254) COLLATE pg_catalog."default",
			validation_rd character varying(254) COLLATE pg_catalog."default",
			commentaire_rd character varying(254) COLLATE pg_catalog."default",
			geom geometry(Point,2154) NOT NULL)
			;

		CREATE TABLE t_adresse(ad_code text NOT NULL  ,
			ad_ban_id text   ,
			ad_nomvoie text   ,
			ad_fantoir text   ,
			ad_numero text   ,
			ad_rep text   ,
			ad_insee text   ,
			ad_postal text   ,
			ad_alias text   ,
			ad_nom_ld text   ,
			ad_x_ban text   ,
			ad_y_ban text   ,
			ad_commune text   ,
			ad_section text   ,
			ad_idpar text   ,
			ad_x_parc text   ,
			ad_y_parc text   ,
			ad_nat text   ,
			ad_nblhab text   ,
			ad_nblpro text   ,
			ad_nbprhab text   ,
			ad_nbprpro text   ,
			ad_rivoli text   ,
			ad_hexacle text   ,
			ad_hexaclv text   ,
			ad_distinf text   ,
			ad_isole text   ,
			ad_prio text   ,
			ad_racc text   ,
			ad_batcode text  ,
			ad_nombat text   ,
			ad_ietat text   ,
			ad_itypeim text   ,
			ad_imneuf text   ,
			ad_idatimn text   ,
			ad_prop text   ,
			ad_gest text   ,
			ad_idatsgn text   ,
			ad_iaccgst text   ,
			ad_idatcab text   ,
			ad_idatcom text   ,
			ad_typzone text   ,
			ad_comment text   ,
			ad_geolqlt text   ,
			ad_geolmod text   ,
			ad_geolsrc text   ,
			ad_creadat text   ,
			ad_majdate text   ,
			ad_majsrc text   ,
			ad_abddate text   ,
			ad_abdsrc text   ,
			--ad_imp_d date  DEFAULT CURRENT_text,/
			--ad_id SERIAL
			geom Geometry(Point,2154) NOT NULL  ,
			CONSTRAINT "t_adresse_pk" PRIMARY KEY (ad_code));
			
		CREATE TABLE t_organisme(or_code text NOT NULL  ,
			or_siren text    ,
			or_nom text   ,
			or_type text   ,
			or_activ text   ,
			or_l331 text   ,
			or_siret text   ,
			or_nometab text   ,
			or_ad_code text   ,
			or_nomvoie text   ,
			or_numero text   ,
			or_rep text   ,
			or_local text   ,
			or_postal text   ,
			or_commune text   ,
			or_telfixe text  ,
			or_mail text   ,
			or_comment text   ,
			or_creadat text   ,
			or_majdate text   ,
			or_majsrc text   ,
			or_abddate text   ,
			or_abdsrc text   ,
			--or_imp_t date NOT NULL DEFAULT CURRENT_text,
		CONSTRAINT "t_organisme_pk" PRIMARY KEY (or_code));	
			
		CREATE TABLE t_reference(	rf_code text NOT NULL  ,
			rf_type text   ,
			rf_fabric text   ,
			rf_design text   ,
			rf_etat text   ,
			rf_comment text   ,
			rf_creadat text   ,
			rf_majdate text   ,
			rf_majsrc text   ,
			rf_abddate text   ,
			rf_abdsrc text   ,
			--rf_imp_t date NOT NULL DEFAULT CURRENT_text,
		CONSTRAINT "t_reference_pk" PRIMARY KEY (rf_code));	
			
		CREATE TABLE t_noeud(	nd_code text NOT NULL  ,
			nd_codeext text   ,
			nd_nom text   ,
			nd_coderat text   ,
			nd_r1_code text   ,
			nd_r2_code text   ,
			nd_r3_code text   ,
			nd_r4_code text   ,
			nd_voie text   ,
			nd_type text   ,
			nd_type_ep text   ,
			nd_comment text   ,
			nd_dtclass text   ,
			nd_geolqlt text   ,
			nd_geolmod text   ,
			nd_geolsrc text   ,
			nd_creadat text   ,
			nd_majdate text   ,
			nd_majsrc text   ,
			nd_abddate text   ,
			nd_abdsrc text   ,
			--nd_imp_t date NOT NULL DEFAULT CURRENT_text,
			geom Geometry(Point,2154) NOT NULL  ,
		CONSTRAINT "t_noeud_pk" PRIMARY KEY (nd_code));	
			
		CREATE TABLE t_znro(	zn_code text NOT NULL  ,
			zn_nd_code text  ,
			zn_r1_code text   ,
			zn_r2_code text   ,
			zn_r3_code text   ,
			zn_r4_code text   ,
			zn_nroref text   ,
			zn_nrotype text   ,
			zn_etat text   ,
			zn_etatlpm text   ,
			zn_datelpm text   ,
			zn_comment text   ,
			zn_geolsrc text   ,
			zn_creadat text   ,
			zn_majdate text   ,
			zn_majsrc text   ,
			zn_abddate text   ,
			zn_abdsrc text   ,
			--zn_imp_t date NOT NULL DEFAULT CURRENT_text,
			geom geometry(MultiPolygon,2154)   NOT NULL,
		CONSTRAINT "t_znro_pk" PRIMARY KEY (zn_code));	
			
		CREATE TABLE t_zsro(	zs_code text NOT NULL  ,
			zs_nd_code text ,
			zs_zn_code text   ,
			zs_r1_code text   ,
			zs_r2_code text   ,
			zs_r3_code text   ,
			zs_r4_code text   ,
			zs_refpm text   ,
			zs_etatpm text   ,
			zs_dateins text   ,
			zs_typeemp text   ,
			zs_capamax text   ,
			zs_ad_code text   ,
			zs_typeing text   ,
			zs_nblogmt text   ,
			zs_nbcolmt text   ,
			zs_datcomr text   ,
			zs_actif text  ,
			zs_datemad text   ,
			zs_accgest text   ,
			zs_brassoi text   ,
			zs_comment text   ,
			zs_geolsrc text   ,
			zs_creadat text   ,
			zs_majdate text   ,
			zs_majsrc text   ,
			zs_abddate text   ,
			zs_abdsrc text   ,
			--zs_imp_t date NOT NULL DEFAULT CURRENT_text,
			geom geometry(MultiPolygon,2154)   ,
		CONSTRAINT "t_zsro_pk" PRIMARY KEY (zs_code));	
			
		CREATE TABLE t_zpbo(	zp_code text NOT NULL  ,
			zp_nd_code text  ,
			zp_zs_code text   ,
			zp_r1_code text   ,
			zp_r2_code text   ,
			zp_r3_code text   ,
			zp_r4_code text   ,
			zp_capamax text   ,
			zp_comment text   ,
			zp_geolsrc text   ,
			zp_creadat text   ,
			zp_majdate text   ,
			zp_majsrc text   ,
			zp_abddate text   ,
			zp_abdsrc text   ,
			--zp_imp_t date NOT NULL DEFAULT CURRENT_text,
			geom geometry(MultiPolygon,2154)   ,
		CONSTRAINT "t_zpbo_pk" PRIMARY KEY (zp_code));	
			
		CREATE TABLE t_zdep(	zd_code text NOT NULL  ,
			zd_nd_code text   ,
			zd_zs_code text   ,
			zd_r1_code text   ,
			zd_r2_code text   ,
			zd_r3_code text   ,
			zd_r4_code text   ,
			zd_r5_code text   ,
			zd_r6_code text   ,
			zd_prop text   ,
			zd_gest text   ,
			zd_statut text ,
			zd_comment text   ,
			zd_geolsrc text   ,
			zd_creadat text  ,
			zd_majdate text   ,
			zd_majsrc text   ,
			zd_abddate text   ,
			zd_abdsrc text   ,
			zd_datefin text   ,
			--zd_imp_t date NOT NULL DEFAULT CURRENT_text,
			geom geometry(MultiPolygon,2154)   ,
		CONSTRAINT "t_zdep_pk" PRIMARY KEY (zd_code));	
			
		CREATE TABLE t_zcoax(	zc_code text NOT NULL  ,
			zc_codeext text   ,
			zc_nd_code text   ,
			zc_r1_code text   ,
			zc_r2_code text   ,
			zc_r3_code text   ,
			zc_r4_code text   ,
			zc_prop text   ,
			zc_gest text   ,
			zc_statut text  ,
			zc_comment text   ,
			zc_geolsrc text   ,
			zc_creadat text   ,
			zc_majdate text   ,
			zc_majsrc text   ,
			zc_abddate text   ,
			zc_abdsrc text   ,
			--zc_imp_t date NOT NULL DEFAULT CURRENT_text,
			geom geometry(MultiPolygon,2154)   ,
		CONSTRAINT "t_zcoax_pk" PRIMARY KEY (zc_code));
			
		CREATE TABLE t_sitetech(	st_code text NOT NULL  ,
			st_nd_code text    ,
			st_codeext text   ,
			st_nom text   ,
			st_prop text   ,
			st_gest text   ,
			st_user text   ,
			st_proptyp text   ,
			st_statut text  ,
			st_etat text   ,
			st_dateins text   ,
			st_datemes text   ,
			st_avct text   ,
			st_typephy text   ,
			st_typelog text   ,
			st_nblines text   ,
			st_ad_code text   ,
			st_comment text   ,
			st_creadat text   ,
			st_majdate text   ,
			st_majsrc text   ,
			st_abddate text   ,
			st_abdsrc text   ,
			--st_imp_t date NOT NULL DEFAULT CURRENT_text,
		CONSTRAINT "t_sitetech_pk" PRIMARY KEY (st_code));	
			
		CREATE TABLE t_ltech(	lt_code text NOT NULL  ,
			lt_codeext text   ,
			lt_etiquet text   ,
			lt_st_code text ,
			lt_prop text   ,
			lt_gest text   ,
			lt_user text   ,
			lt_proptyp text   ,
			lt_statut text  ,
			lt_etat text  ,
			lt_dateins text   ,
			lt_datemes text   ,
			lt_local text   ,
			lt_elec text   ,
			lt_clim text   ,
			lt_occp text   ,
			lt_idmajic text   ,
			lt_comment text   ,
			lt_creadat text   ,
			lt_majdate text   ,
			lt_majsrc text   ,
			lt_abddate text   ,
			lt_abdsrc text   ,
			--lt_imp_t date NOT NULL DEFAULT CURRENT_text,
		CONSTRAINT "t_ltech_pk" PRIMARY KEY (lt_code));	
			
		CREATE TABLE t_baie(	ba_code text NOT NULL  ,
			ba_codeext text   ,
			ba_etiquet text   ,
			ba_lt_code text   ,
			ba_prop text   ,
			ba_gest text   ,
			ba_user text   ,
			ba_proptyp text   ,
			ba_statut text   ,
			ba_etat text   ,
			ba_rf_code text   ,
			ba_type text   ,
			ba_nb_u text   ,
			ba_haut text   ,
			ba_larg text   ,
			ba_prof text   ,
			ba_comment text   ,
			ba_creadat text   ,
			ba_majdate text   ,
			ba_majsrc text   ,
			ba_abddate text   ,
			ba_abdsrc text   ,
			--ba_imp_t date NOT NULL DEFAULT CURRENT_text,
		CONSTRAINT "t_baie_pk" PRIMARY KEY (ba_code));	
			
		CREATE TABLE t_tiroir(	ti_code text NOT NULL  ,
			ti_codeext text   ,
			ti_etiquet text   ,
			ti_ba_code text   ,
			ti_prop text   ,
			ti_etat text   ,
			ti_type text  ,
			ti_rf_code text   ,
			ti_taille text   ,
			ti_placemt text   ,
			ti_localis text   ,
			ti_comment text   ,
			ti_creadat text   ,
			ti_majdate text   ,
			ti_majsrc text   ,
			ti_abddate text   ,
			ti_abdsrc text   ,
			--ti_imp_t date NOT NULL DEFAULT CURRENT_text,
		CONSTRAINT "t_tiroir_pk" PRIMARY KEY (ti_code));	
			
		CREATE TABLE t_equipement(	eq_code text NOT NULL  ,
			eq_codeext text   ,
			eq_etiquet text   ,
			eq_ba_code text   ,
			eq_prop text   ,
			eq_rf_code text   ,
			eq_dateins text   ,
			eq_datemes text   ,
			eq_comment text   ,
			eq_creadat text   ,
			eq_majdate text   ,
			eq_majsrc text   ,
			eq_abddate text   ,
			eq_abdsrc text   ,
			--eq_imp_t date NOT NULL DEFAULT CURRENT_text,
		CONSTRAINT "t_equipement_pk" PRIMARY KEY (eq_code));
			
		CREATE TABLE t_suf(	sf_code text NOT NULL  ,
			sf_nd_code text   ,
			sf_ad_code text   ,
			sf_zp_code text   ,
			sf_escal text   ,
			sf_etage text   ,
			sf_oper text   ,
			sf_type text ,
			sf_prop text   ,
			sf_resid text   ,
			sf_local text   ,
			sf_racco text   ,
			sf_comment text   ,
			sf_creadat text    ,
			sf_majdate text   ,
			sf_majsrc text   ,
			sf_abddate text   ,
			sf_abdsrc text   ,
			--sf_imp_t date NOT NULL DEFAULT CURRENT_text,
		CONSTRAINT "t_suf_pk" PRIMARY KEY (sf_code));	
			
			
			
		CREATE TABLE t_ptech(	pt_code text NOT NULL  ,
			pt_codeext text   ,
			pt_etiquet text   ,
			pt_nd_code text  ,
			pt_ad_code text   ,
			pt_gest_do text   ,
			pt_prop_do text   ,
			pt_prop text   ,
			pt_gest text   ,
			pt_user text   ,
			pt_proptyp text   ,
			pt_statut text ,
			pt_etat text   ,
			pt_dateins text   ,
			pt_datemes text   ,
			pt_avct text   ,
			pt_typephy text ,
			pt_typelog text ,
			pt_rf_code text  ,
			pt_nature text   ,
			pt_secu text   ,
			pt_occp text   ,
			pt_a_dan text   ,
			pt_a_dtetu text   ,
			pt_a_struc text   ,
			pt_a_haut text   ,
			pt_a_passa text   ,
			pt_a_strat text   ,
			pt_rotatio text   ,
			pt_detec text   ,
			pt_comment text   ,
			pt_creadat text   ,
			pt_majdate text   ,
			pt_majsrc text   ,
			pt_abddate text   ,
			pt_abdsrc text   ,
			--pt_imp_t date NOT NULL DEFAULT CURRENT_text,
		CONSTRAINT "t_ptech_pk" PRIMARY KEY (pt_code));	
			
		CREATE TABLE t_ebp(	bp_code text NOT NULL  ,
			bp_etiquet text   ,
			bp_codeext text   ,
			bp_pt_code text   ,
			bp_lt_code text   ,
			bp_sf_code text   ,
			bp_prop text   ,
			bp_gest text   ,
			bp_user text   ,
			bp_proptyp text   ,
			bp_statut text ,
			bp_etat text   ,
			bp_occp text   ,
			bp_datemes text   ,
			bp_avct text   ,
			bp_typephy text   ,
			bp_typelog text  ,
			bp_rf_code text   ,
			bp_entrees text   ,
			bp_ref_kit text   ,
			bp_ca_nb text   ,
			bp_nb_pas text   ,
			bp_linecod text   ,
			bp_oc_code text   ,
			bp_racco text   ,
			bp_comment text   ,
			bp_creadat text    ,
			bp_majdate text   ,
			bp_majsrc text   ,
			bp_abddate text   ,
			bp_abdsrc text   ,
			--bp_imp_t date NOT NULL DEFAULT CURRENT_text,
		CONSTRAINT "t_ebp_pk" PRIMARY KEY (bp_code));	
			
		CREATE TABLE t_cassette(	cs_code text NOT NULL  ,
			cs_nb_pas text   ,
			cs_bp_code text   ,
			cs_num text    ,
			cs_type text   ,
			cs_face text   ,
			cs_rf_code text   ,
			cs_comment text   ,
			cs_creadat text    ,
			cs_majdate text   ,
			cs_majsrc text   ,
			cs_abddate text   ,
			cs_abdsrc text   ,
			--cs_imp_t date NOT NULL DEFAULT CURRENT_text,
		CONSTRAINT "t_cassette_pk" PRIMARY KEY (cs_code));	
			
		CREATE TABLE t_cheminement(	cm_code text NOT NULL  ,
			cm_codeext text   ,
			cm_ndcode1 text   ,
			cm_ndcode2 text   ,
			cm_cm1 text   ,
			cm_cm2 text   ,
			cm_r1_code text     ,
			cm_r2_code text   ,
			cm_r3_code text   ,
			cm_r4_code text   ,
			cm_voie text   ,
			cm_gest_do text   ,
			cm_prop_do text   ,
			cm_statut text   ,
			cm_etat text   ,
			cm_datcons text   ,
			cm_datemes text   ,
			cm_avct text   ,
			cm_typelog text   ,
			cm_typ_imp text   ,
			cm_nature text    ,
			cm_compo text   ,
			cm_cddispo text   ,
			cm_fo_util text    ,
			cm_mod_pos text   ,
			cm_passage text   ,
			cm_revet text   ,
			cm_remblai text   ,
			cm_charge text   ,
			cm_larg text   ,
			cm_fildtec text   ,
			cm_mut_org text   ,
			cm_long text    ,
			cm_lgreel text   ,
			cm_comment text   ,
			cm_dtclass text   ,
			cm_geolqlt text   ,
			cm_geolmod text   ,
			cm_geolsrc text   ,
			cm_creadat text   ,
			cm_majdate text   ,
			cm_majsrc text   ,
			cm_abddate text   ,
			cm_abdsrc text   ,
			cm_nom text ,
			--cm_imp_t date NOT NULL DEFAULT CURRENT_text,
			geom Geometry(Linestring,2154) NOT NULL  ,
		CONSTRAINT "t_cheminement_pk" PRIMARY KEY (cm_code));	
			
		CREATE TABLE t_conduite(	cd_code text NOT NULL  ,
			cd_codeext text   ,
			cd_etiquet text   ,
			cd_cd_code text   ,
			cd_r1_code text   ,
			cd_r2_code text   ,
			cd_r3_code text   ,
			cd_r4_code text   ,
			cd_prop text   ,
			cd_gest text   ,
			cd_user text   ,
			cd_proptyp text   ,
			cd_statut text ,
			cd_etat text   ,
			cd_dateaig text   ,
			cd_dateman text   ,
			cd_datemes text   ,
			cd_avct text   ,
			cd_type text  ,
			cd_dia_int text   ,
			cd_dia_ext text   ,
			cd_color text   ,
			cd_long text   ,
			cd_nbcable text   ,
			cd_occup text   ,
			cd_comment text   ,
			cd_creadat text     ,
			cd_majdate text   ,
			cd_majsrc text   ,
			cd_abddate text   ,
			cd_abdsrc text   ,
			--cd_imp_t date NOT NULL DEFAULT CURRENT_text,
		CONSTRAINT "t_conduite_pk" PRIMARY KEY (cd_code));	
			
		CREATE TABLE t_cond_chem(	dm_cd_code text NOT NULL  REFERENCES t_conduite(cd_code),
			dm_cm_code text ,
			dm_creadat text   ,
			dm_majdate text   ,
			dm_majsrc text   ,
			dm_abddate text   ,
			dm_abdsrc text   ,
			--dm_imp_t date NOT NULL DEFAULT CURRENT_text,
		CONSTRAINT "t_cond_chem_pk" PRIMARY KEY (dm_cd_code, dm_cm_code));	
			
		CREATE TABLE t_masque(	mq_id BIGINT NOT NULL  ,
			mq_nd_code text ,
			mq_face text ,
			mq_col text ,
			mq_ligne text ,
			mq_cd_code text   ,
			mq_qualinf text   ,
			mq_comment text   ,
			mq_creadat text   ,
			mq_majdate text   ,
			mq_majsrc text   ,
			mq_abddate text   ,
			mq_abdsrc text   ,
			--mq_imp_t date NOT NULL DEFAULT CURRENT_text,
		CONSTRAINT "t_masque_pk" PRIMARY KEY (mq_id));	
			
		CREATE TABLE t_cable(	cb_code text NOT NULL  ,
			cb_codeext text   ,
			cb_etiquet text   ,
			cb_nd1 text    ,
			cb_nd2 text    ,
			cb_r1_code text   ,
			cb_r2_code text   ,
			cb_r3_code text   ,
			cb_r4_code text   ,
			cb_prop text    ,
			cb_gest text    ,
			cb_user text   ,
			cb_proptyp text ,
			cb_statut text  ,
			cb_etat text    ,
			cb_dateins text   ,
			cb_datemes text   ,
			cb_avct text   ,
			cb_tech text   ,
			cb_typephy text ,
			cb_typelog text ,
			cb_rf_code text  ,
			cb_capafo text   ,
			cb_fo_disp text   ,
			cb_fo_util text   ,
			cb_modulo text   ,
			cb_diam text   ,
			cb_color text   ,
			cb_lgreel text   ,
			cb_localis text   ,
			cb_comment text   ,
			cb_creadat text   ,
			cb_majdate text   ,
			cb_majsrc text   ,
			cb_abddate text   ,
			cb_abdsrc text   ,
			cb_bp1 text     ,
			cb_ba1 text     ,
			cb_bp2 text     ,
			cb_ba2 text     ,
			--cb_imp_t date NOT NULL DEFAULT CURRENT_text,
		CONSTRAINT "t_cable_pk" PRIMARY KEY (cb_code));	
			
		CREATE TABLE t_cableline(	cl_code text NOT NULL  ,
			cl_cb_code text UNIQUE REFERENCES t_cable(cb_code) ,
			cl_long text   ,
			cl_comment text   ,
			cl_dtclass text   ,
			cl_geolqlt text   ,
			cl_geolmod text   ,
			cl_geolsrc text   ,
			cl_creadat text   ,
			cl_majdate text   ,
			cl_majsrc text   ,
			cl_abddate text   ,
			cl_abdsrc text   ,
			--cl_imp_t date NOT NULL DEFAULT CURRENT_text,
			geom Geometry(Linestring,2154) NOT NULL  ,
		CONSTRAINT "t_cableline_pk" PRIMARY KEY (cl_code));	
			
		CREATE TABLE t_cab_cond(	cc_cb_code text NOT NULL  REFERENCES t_cable(cb_code),
			cc_cd_code text ,
			cc_creadat text   ,
			cc_majdate text   ,
			cc_majsrc text   ,
			cc_abddate text   ,
			cc_abdsrc text   ,
			--cc_imp_t date NOT NULL DEFAULT CURRENT_text,
		CONSTRAINT "t_cab_cond_pk" PRIMARY KEY (cc_cb_code, cc_cd_code));	
			
		CREATE TABLE t_love(	lv_id BIGINT NOT NULL  ,
			lv_cb_code text ,
			lv_nd_code text ,
			lv_long text   ,
			lv_creadat text   ,
			lv_majdate text   ,
			lv_majsrc text   ,
			lv_abddate text   ,
			lv_abdsrc text   ,
			--lv_imp_t date NOT NULL DEFAULT CURRENT_text,
		CONSTRAINT "t_love_pk" PRIMARY KEY (lv_id));	
			
		CREATE TABLE t_fibre(	fo_code text NOT NULL  ,
			fo_code_ext text   ,
			fo_cb_code text ,
			fo_nincab text   ,
			fo_numtub text   ,
			fo_nintub text   ,
			fo_type text  ,
			fo_etat text   ,
			fo_color text   ,
			fo_reper text   ,
			fo_proptyp text   ,
			fo_comment text   ,
			fo_creadat text   ,
			fo_majdate text   ,
			fo_majsrc text   ,
			fo_abddate text   ,
			fo_abdsrc text   ,
			--fo_imp_t date NOT NULL DEFAULT CURRENT_text,
		CONSTRAINT "t_fibre_pk" PRIMARY KEY (fo_code));	
			
		CREATE TABLE t_position(	ps_code text NOT NULL  ,
			ps_numero text   ,
			ps_1 text    ,
			ps_2 text    ,
			ps_cs_code text   ,
			ps_ti_code text   ,
			ps_type text   ,
			ps_fonct text   ,
			ps_etat text    ,
			ps_preaff text    ,
			ps_comment text   ,
			ps_creadat text    ,
			ps_majdate text   ,
			ps_majsrc text   ,
			ps_abddate text   ,
			ps_abdsrc text   ,
			--ps_imp_t date NOT NULL DEFAULT CURRENT_text,
		CONSTRAINT "t_position_pk" PRIMARY KEY (ps_code));	
			
		CREATE TABLE t_ropt(	rt_id BIGINT NOT NULL  ,
			rt_code text  ,
			rt_code_ext text   ,
			rt_fo_code text  ,
			rt_fo_ordr text    ,
			rt_comment text   ,
			rt_creadat text    ,
			rt_majdate text   ,
			rt_majsrc text   ,
			rt_abddate text   ,
			rt_abdsrc text   ,
			--rt_imp_t date NOT NULL DEFAULT CURRENT_text,
		CONSTRAINT "t_ropt_pk" PRIMARY KEY (rt_id));	
			
		CREATE TABLE t_siteemission(	se_code text NOT NULL  ,
			se_nd_code text  ,
			se_anfr text   ,
			se_prop text   ,
			se_gest text   ,
			se_user text   ,
			se_proptyp text  ,
			se_statut text   ,
			se_etat text   ,
			se_occp text   ,
			se_dateins text   ,
			se_datemes text   ,
			se_type text  ,
			se_haut text   ,
			se_ad_code text  ,
			se_comment text   ,
			se_creadat text   ,
			se_majdate text   ,
			se_majsrc text   ,
			se_abddate text   ,
			se_abdsrc text   ,
			--se_imp_t date NOT NULL DEFAULT CURRENT_text,
		CONSTRAINT "t_siteemission_pk" PRIMARY KEY (se_code));	
			
		CREATE TABLE t_document(	do_code text NOT NULL  ,
			do_ref text   ,
			do_reftier text   ,
			do_r1_code text    ,
			do_r2_code text    ,
			do_r3_code text    ,
			do_r4_code text    ,
			do_type text   ,
			do_indice text   ,
			do_date text   ,
			do_classe text   ,
			do_url1 text   ,
			do_url2 text   ,
			do_comment text   ,
			do_creadat text   ,
			do_majdate text   ,
			do_majsrc text   ,
			do_abddate text   ,
			do_abdsrc text   ,
			--do_imp_t date NOT NULL DEFAULT CURRENT_text,
		CONSTRAINT "t_document_pk" PRIMARY KEY (do_code));	
			
		CREATE TABLE t_docobj(	od_id BIGINT NOT NULL  ,
			od_do_code text  ,
			od_tbltype text  ,
			od_codeobj text  ,
			od_creadat text    ,
			od_majdate text   ,
			od_majsrc text   ,
			od_abddate text   ,
			od_abdsrc text   ,
			--od_imp_t date NOT NULL DEFAULT CURRENT_text,
		CONSTRAINT "t_docobj_pk" PRIMARY KEY (od_id));	
			
		CREATE TABLE t_empreinte(	em_code text NOT NULL  ,
			em_do_code text   ,
			em_geolsrc text   ,
			em_creadat text   ,
			em_majdate text   ,
			em_majsrc text   ,
			em_abddate text   ,
			em_abdsrc text   ,
			--em_imp_t date NOT NULL DEFAULT CURRENT_text,
			geom geometry(MultiPolygon,2154)   ,
		CONSTRAINT "t_empreinte_pk" PRIMARY KEY (em_code));	



		CREATE INDEX t_adresse_geom_gist ON t_adresse USING GIST (geom); 
		CREATE INDEX t_noeud_geom_gist ON t_noeud USING GIST (geom); 
		CREATE INDEX t_cheminement_geom_gist ON t_cheminement USING GIST (geom); 
		CREATE INDEX t_cableline_geom_gist ON t_cableline USING GIST (geom); 
		CREATE INDEX t_znro_geom_gist ON t_znro USING GIST (geom); 
		CREATE INDEX t_zsro_geom_gist ON t_zsro USING GIST (geom); 
		CREATE INDEX t_zpbo_geom_gist ON t_zpbo USING GIST (geom); 
		CREATE INDEX t_zdep_geom_gist ON t_zdep USING GIST (geom); 
		CREATE INDEX t_zcoax_geom_gist ON t_zcoax USING GIST (geom); 
		CREATE INDEX t_empreinte_geom_gist ON t_empreinte USING GIST (geom); 




		DROP INDEX IF EXISTS ad_ban_id_idx; CREATE INDEX  ad_ban_id_idx ON t_adresse(ad_ban_id);








		DROP INDEX IF EXISTS ad_x_ban_idx; CREATE INDEX  ad_x_ban_idx ON t_adresse(ad_x_ban);
		DROP INDEX IF EXISTS ad_y_ban_idx; CREATE INDEX  ad_y_ban_idx ON t_adresse(ad_y_ban);


		DROP INDEX IF EXISTS ad_idpar_idx; CREATE INDEX  ad_idpar_idx ON t_adresse(ad_idpar);
		DROP INDEX IF EXISTS ad_x_parc_idx; CREATE INDEX  ad_x_parc_idx ON t_adresse(ad_x_parc);
		DROP INDEX IF EXISTS ad_y_parc_idx; CREATE INDEX  ad_y_parc_idx ON t_adresse(ad_y_parc);



		DROP INDEX IF EXISTS ad_nbprhab_idx; CREATE INDEX  ad_nbprhab_idx ON t_adresse(ad_nbprhab);
		DROP INDEX IF EXISTS ad_nbprpro_idx; CREATE INDEX  ad_nbprpro_idx ON t_adresse(ad_nbprpro);

		DROP INDEX IF EXISTS ad_hexacle_idx; CREATE INDEX  ad_hexacle_idx ON t_adresse(ad_hexacle);
		DROP INDEX IF EXISTS ad_hexaclv_idx; CREATE INDEX  ad_hexaclv_idx ON t_adresse(ad_hexaclv);



		DROP INDEX IF EXISTS ad_racc_idx; CREATE INDEX  ad_racc_idx ON t_adresse(ad_racc);


		DROP INDEX IF EXISTS ad_ietat_idx; CREATE INDEX  ad_ietat_idx ON t_adresse(ad_ietat);
		DROP INDEX IF EXISTS ad_itypeim_idx; CREATE INDEX  ad_itypeim_idx ON t_adresse(ad_itypeim);








		DROP INDEX IF EXISTS ad_typzone_idx; CREATE INDEX  ad_typzone_idx ON t_adresse(ad_typzone);














		DROP INDEX IF EXISTS or_nom_idx; CREATE INDEX  or_nom_idx ON t_organisme(or_nom);


		DROP INDEX IF EXISTS or_l331_idx; CREATE INDEX  or_l331_idx ON t_organisme(or_l331);
		DROP INDEX IF EXISTS or_siret_idx; CREATE INDEX  or_siret_idx ON t_organisme(or_siret);
		DROP INDEX IF EXISTS or_nometab_idx; CREATE INDEX  or_nometab_idx ON t_organisme(or_nometab);
		DROP INDEX IF EXISTS or_ad_code_idx; CREATE INDEX  or_ad_code_idx ON t_organisme(or_ad_code);

















		DROP INDEX IF EXISTS rf_type_idx; CREATE INDEX  rf_type_idx ON t_reference(rf_type);
		DROP INDEX IF EXISTS rf_fabric_idx; CREATE INDEX  rf_fabric_idx ON t_reference(rf_fabric);

		DROP INDEX IF EXISTS rf_etat_idx; CREATE INDEX  rf_etat_idx ON t_reference(rf_etat);











		DROP INDEX IF EXISTS nd_coderat_idx; CREATE INDEX  nd_coderat_idx ON t_noeud(nd_coderat);





		DROP INDEX IF EXISTS nd_type_idx; CREATE INDEX  nd_type_idx ON t_noeud(nd_type);


		DROP INDEX IF EXISTS nd_dtclass_idx; CREATE INDEX  nd_dtclass_idx ON t_noeud(nd_dtclass);












		DROP INDEX IF EXISTS zn_nd_code_idx; CREATE INDEX  zn_nd_code_idx ON t_znro(zn_nd_code);
		DROP INDEX IF EXISTS zn_r1_code_idx; CREATE INDEX  zn_r1_code_idx ON t_znro(zn_r1_code);
		DROP INDEX IF EXISTS zn_r2_code_idx; CREATE INDEX  zn_r2_code_idx ON t_znro(zn_r2_code);
		DROP INDEX IF EXISTS zn_r3_code_idx; CREATE INDEX  zn_r3_code_idx ON t_znro(zn_r3_code);
		DROP INDEX IF EXISTS zn_r4_code_idx; CREATE INDEX  zn_r4_code_idx ON t_znro(zn_r4_code);
















		DROP INDEX IF EXISTS zs_nd_code_idx; CREATE INDEX  zs_nd_code_idx ON t_zsro(zs_nd_code);
		DROP INDEX IF EXISTS zs_zn_code_idx; CREATE INDEX  zs_zn_code_idx ON t_zsro(zs_zn_code);
		DROP INDEX IF EXISTS zs_r1_code_idx; CREATE INDEX  zs_r1_code_idx ON t_zsro(zs_r1_code);
		DROP INDEX IF EXISTS zs_r2_code_idx; CREATE INDEX  zs_r2_code_idx ON t_zsro(zs_r2_code);
		DROP INDEX IF EXISTS zs_r3_code_idx; CREATE INDEX  zs_r3_code_idx ON t_zsro(zs_r3_code);
		DROP INDEX IF EXISTS zs_r4_code_idx; CREATE INDEX  zs_r4_code_idx ON t_zsro(zs_r4_code);

























		DROP INDEX IF EXISTS zp_nd_code_idx; CREATE INDEX  zp_nd_code_idx ON t_zpbo(zp_nd_code);
		DROP INDEX IF EXISTS zp_zs_code_idx; CREATE INDEX  zp_zs_code_idx ON t_zpbo(zp_zs_code);
		DROP INDEX IF EXISTS zp_r1_code_idx; CREATE INDEX  zp_r1_code_idx ON t_zpbo(zp_r1_code);
		DROP INDEX IF EXISTS zp_r2_code_idx; CREATE INDEX  zp_r2_code_idx ON t_zpbo(zp_r2_code);
		DROP INDEX IF EXISTS zp_r3_code_idx; CREATE INDEX  zp_r3_code_idx ON t_zpbo(zp_r3_code);
		DROP INDEX IF EXISTS zp_r4_code_idx; CREATE INDEX  zp_r4_code_idx ON t_zpbo(zp_r4_code);












		DROP INDEX IF EXISTS zd_nd_code_idx; CREATE INDEX  zd_nd_code_idx ON t_zdep(zd_nd_code);
		DROP INDEX IF EXISTS zd_zs_code_idx; CREATE INDEX  zd_zs_code_idx ON t_zdep(zd_zs_code);
		DROP INDEX IF EXISTS zd_r1_code_idx; CREATE INDEX  zd_r1_code_idx ON t_zdep(zd_r1_code);
		DROP INDEX IF EXISTS zd_r2_code_idx; CREATE INDEX  zd_r2_code_idx ON t_zdep(zd_r2_code);
		DROP INDEX IF EXISTS zd_r3_code_idx; CREATE INDEX  zd_r3_code_idx ON t_zdep(zd_r3_code);
		DROP INDEX IF EXISTS zd_r4_code_idx; CREATE INDEX  zd_r4_code_idx ON t_zdep(zd_r4_code);
		DROP INDEX IF EXISTS zd_prop_idx; CREATE INDEX  zd_prop_idx ON t_zdep(zd_prop);
		DROP INDEX IF EXISTS zd_gest_idx; CREATE INDEX  zd_gest_idx ON t_zdep(zd_gest);
		DROP INDEX IF EXISTS zd_statut_idx; CREATE INDEX  zd_statut_idx ON t_zdep(zd_statut);












		DROP INDEX IF EXISTS zc_nd_code_idx; CREATE INDEX  zc_nd_code_idx ON t_zcoax(zc_nd_code);
		DROP INDEX IF EXISTS zc_r1_code_idx; CREATE INDEX  zc_r1_code_idx ON t_zcoax(zc_r1_code);
		DROP INDEX IF EXISTS zc_r2_code_idx; CREATE INDEX  zc_r2_code_idx ON t_zcoax(zc_r2_code);
		DROP INDEX IF EXISTS zc_r3_code_idx; CREATE INDEX  zc_r3_code_idx ON t_zcoax(zc_r3_code);
		DROP INDEX IF EXISTS zc_r4_code_idx; CREATE INDEX  zc_r4_code_idx ON t_zcoax(zc_r4_code);
		DROP INDEX IF EXISTS zc_prop_idx; CREATE INDEX  zc_prop_idx ON t_zcoax(zc_prop);
		DROP INDEX IF EXISTS zc_gest_idx; CREATE INDEX  zc_gest_idx ON t_zcoax(zc_gest);
		DROP INDEX IF EXISTS zc_statut_idx; CREATE INDEX  zc_statut_idx ON t_zcoax(zc_statut);











		DROP INDEX IF EXISTS st_nd_code_idx; CREATE INDEX  st_nd_code_idx ON t_sitetech(st_nd_code);


		DROP INDEX IF EXISTS st_prop_idx; CREATE INDEX  st_prop_idx ON t_sitetech(st_prop);
		DROP INDEX IF EXISTS st_gest_idx; CREATE INDEX  st_gest_idx ON t_sitetech(st_gest);

		DROP INDEX IF EXISTS st_proptyp_idx; CREATE INDEX  st_proptyp_idx ON t_sitetech(st_proptyp);
		DROP INDEX IF EXISTS st_statut_idx; CREATE INDEX  st_statut_idx ON t_sitetech(st_statut);
		DROP INDEX IF EXISTS st_etat_idx; CREATE INDEX  st_etat_idx ON t_sitetech(st_etat);


		DROP INDEX IF EXISTS st_avct_idx; CREATE INDEX  st_avct_idx ON t_sitetech(st_avct);














		DROP INDEX IF EXISTS lt_etiquet_idx; CREATE INDEX  lt_etiquet_idx ON t_ltech(lt_etiquet);
		DROP INDEX IF EXISTS lt_st_code_idx; CREATE INDEX  lt_st_code_idx ON t_ltech(lt_st_code);
		DROP INDEX IF EXISTS lt_prop_idx; CREATE INDEX  lt_prop_idx ON t_ltech(lt_prop);
		DROP INDEX IF EXISTS lt_gest_idx; CREATE INDEX  lt_gest_idx ON t_ltech(lt_gest);

		DROP INDEX IF EXISTS lt_proptyp_idx; CREATE INDEX  lt_proptyp_idx ON t_ltech(lt_proptyp);
		DROP INDEX IF EXISTS lt_statut_idx; CREATE INDEX  lt_statut_idx ON t_ltech(lt_statut);
		DROP INDEX IF EXISTS lt_etat_idx; CREATE INDEX  lt_etat_idx ON t_ltech(lt_etat);




		DROP INDEX IF EXISTS lt_clim_idx; CREATE INDEX  lt_clim_idx ON t_ltech(lt_clim);












		DROP INDEX IF EXISTS ba_etiquet_idx; CREATE INDEX  ba_etiquet_idx ON t_baie(ba_etiquet);
		DROP INDEX IF EXISTS ba_lt_code_idx; CREATE INDEX  ba_lt_code_idx ON t_baie(ba_lt_code);
		DROP INDEX IF EXISTS ba_prop_idx; CREATE INDEX  ba_prop_idx ON t_baie(ba_prop);
		DROP INDEX IF EXISTS ba_gest_idx; CREATE INDEX  ba_gest_idx ON t_baie(ba_gest);

		DROP INDEX IF EXISTS ba_proptyp_idx; CREATE INDEX  ba_proptyp_idx ON t_baie(ba_proptyp);
		DROP INDEX IF EXISTS ba_statut_idx; CREATE INDEX  ba_statut_idx ON t_baie(ba_statut);
		DROP INDEX IF EXISTS ba_etat_idx; CREATE INDEX  ba_etat_idx ON t_baie(ba_etat);
		DROP INDEX IF EXISTS ba_rf_code_idx; CREATE INDEX  ba_rf_code_idx ON t_baie(ba_rf_code);
		DROP INDEX IF EXISTS ba_type_idx; CREATE INDEX  ba_type_idx ON t_baie(ba_type);















		DROP INDEX IF EXISTS ti_ba_code_idx; CREATE INDEX  ti_ba_code_idx ON t_tiroir(ti_ba_code);
		DROP INDEX IF EXISTS ti_prop_idx; CREATE INDEX  ti_prop_idx ON t_tiroir(ti_prop);
		DROP INDEX IF EXISTS ti_etat_idx; CREATE INDEX  ti_etat_idx ON t_tiroir(ti_etat);
		DROP INDEX IF EXISTS ti_type_idx; CREATE INDEX  ti_type_idx ON t_tiroir(ti_type);
		DROP INDEX IF EXISTS ti_rf_code_idx; CREATE INDEX  ti_rf_code_idx ON t_tiroir(ti_rf_code);














		DROP INDEX IF EXISTS eq_ba_code_idx; CREATE INDEX  eq_ba_code_idx ON t_equipement(eq_ba_code);
		DROP INDEX IF EXISTS eq_prop_idx; CREATE INDEX  eq_prop_idx ON t_equipement(eq_prop);












		DROP INDEX IF EXISTS sf_nd_code_idx; CREATE INDEX  sf_nd_code_idx ON t_suf(sf_nd_code);
		DROP INDEX IF EXISTS sf_ad_code_idx; CREATE INDEX  sf_ad_code_idx ON t_suf(sf_ad_code);




		DROP INDEX IF EXISTS sf_type_idx; CREATE INDEX  sf_type_idx ON t_suf(sf_type);

















		DROP INDEX IF EXISTS pt_nd_code_idx; CREATE INDEX  pt_nd_code_idx ON t_ptech(pt_nd_code);
		DROP INDEX IF EXISTS pt_ad_code_idx; CREATE INDEX  pt_ad_code_idx ON t_ptech(pt_ad_code);
		DROP INDEX IF EXISTS pt_gest_do_idx; CREATE INDEX  pt_gest_do_idx ON t_ptech(pt_gest_do);
		DROP INDEX IF EXISTS pt_prop_do_idx; CREATE INDEX  pt_prop_do_idx ON t_ptech(pt_prop_do);
		DROP INDEX IF EXISTS pt_prop_idx; CREATE INDEX  pt_prop_idx ON t_ptech(pt_prop);
		DROP INDEX IF EXISTS pt_gest_idx; CREATE INDEX  pt_gest_idx ON t_ptech(pt_gest);

		DROP INDEX IF EXISTS pt_proptyp_idx; CREATE INDEX  pt_proptyp_idx ON t_ptech(pt_proptyp);
		DROP INDEX IF EXISTS pt_statut_idx; CREATE INDEX  pt_statut_idx ON t_ptech(pt_statut);
		DROP INDEX IF EXISTS pt_etat_idx; CREATE INDEX  pt_etat_idx ON t_ptech(pt_etat);


		DROP INDEX IF EXISTS pt_avct_idx; CREATE INDEX  pt_avct_idx ON t_ptech(pt_avct);
		DROP INDEX IF EXISTS pt_typephy_idx; CREATE INDEX  pt_typephy_idx ON t_ptech(pt_typephy);
		DROP INDEX IF EXISTS pt_typelog_idx; CREATE INDEX  pt_typelog_idx ON t_ptech(pt_typelog);
		DROP INDEX IF EXISTS pt_rf_code_idx; CREATE INDEX  pt_rf_code_idx ON t_ptech(pt_rf_code);
		DROP INDEX IF EXISTS pt_nature_idx; CREATE INDEX  pt_nature_idx ON t_ptech(pt_nature);





















		DROP INDEX IF EXISTS bp_pt_code_idx; CREATE INDEX  bp_pt_code_idx ON t_ebp(bp_pt_code);
		DROP INDEX IF EXISTS bp_lt_code_idx; CREATE INDEX  bp_lt_code_idx ON t_ebp(bp_lt_code);
		DROP INDEX IF EXISTS bp_sf_code_idx; CREATE INDEX  bp_sf_code_idx ON t_ebp(bp_sf_code);
		DROP INDEX IF EXISTS bp_prop_idx; CREATE INDEX  bp_prop_idx ON t_ebp(bp_prop);
		DROP INDEX IF EXISTS bp_gest_idx; CREATE INDEX  bp_gest_idx ON t_ebp(bp_gest);

		DROP INDEX IF EXISTS bp_proptyp_idx; CREATE INDEX  bp_proptyp_idx ON t_ebp(bp_proptyp);
		DROP INDEX IF EXISTS bp_statut_idx; CREATE INDEX  bp_statut_idx ON t_ebp(bp_statut);
		DROP INDEX IF EXISTS bp_etat_idx; CREATE INDEX  bp_etat_idx ON t_ebp(bp_etat);


		DROP INDEX IF EXISTS bp_avct_idx; CREATE INDEX  bp_avct_idx ON t_ebp(bp_avct);


		DROP INDEX IF EXISTS bp_rf_code_idx; CREATE INDEX  bp_rf_code_idx ON t_ebp(bp_rf_code);

















		DROP INDEX IF EXISTS cs_bp_code_idx; CREATE INDEX  cs_bp_code_idx ON t_cassette(cs_bp_code);

		DROP INDEX IF EXISTS cs_type_idx; CREATE INDEX  cs_type_idx ON t_cassette(cs_type);

		DROP INDEX IF EXISTS cs_rf_code_idx; CREATE INDEX  cs_rf_code_idx ON t_cassette(cs_rf_code);










		DROP INDEX IF EXISTS cm_ndcode1_idx; CREATE INDEX  cm_ndcode1_idx ON t_cheminement(cm_ndcode1);
		DROP INDEX IF EXISTS cm_ndcode2_idx; CREATE INDEX  cm_ndcode2_idx ON t_cheminement(cm_ndcode2);
		DROP INDEX IF EXISTS cm_cm1_idx; CREATE INDEX  cm_cm1_idx ON t_cheminement(cm_cm1);
		DROP INDEX IF EXISTS cm_cm2_idx; CREATE INDEX  cm_cm2_idx ON t_cheminement(cm_cm2);





		DROP INDEX IF EXISTS cm_gest_do_idx; CREATE INDEX  cm_gest_do_idx ON t_cheminement(cm_gest_do);
		DROP INDEX IF EXISTS cm_prop_do_idx; CREATE INDEX  cm_prop_do_idx ON t_cheminement(cm_prop_do);
		DROP INDEX IF EXISTS cm_statut_idx; CREATE INDEX  cm_statut_idx ON t_cheminement(cm_statut);
		DROP INDEX IF EXISTS cm_etat_idx; CREATE INDEX  cm_etat_idx ON t_cheminement(cm_etat);


		DROP INDEX IF EXISTS cm_avct_idx; CREATE INDEX  cm_avct_idx ON t_cheminement(cm_avct);
		DROP INDEX IF EXISTS cm_typelog_idx; CREATE INDEX  cm_typelog_idx ON t_cheminement(cm_typelog);
		DROP INDEX IF EXISTS cm_typ_imp_idx; CREATE INDEX  cm_typ_imp_idx ON t_cheminement(cm_typ_imp);






























		DROP INDEX IF EXISTS cd_cd_code_idx; CREATE INDEX  cd_cd_code_idx ON t_conduite(cd_cd_code);




		DROP INDEX IF EXISTS cd_prop_idx; CREATE INDEX  cd_prop_idx ON t_conduite(cd_prop);
		DROP INDEX IF EXISTS cd_gest_idx; CREATE INDEX  cd_gest_idx ON t_conduite(cd_gest);

		DROP INDEX IF EXISTS cd_proptyp_idx; CREATE INDEX  cd_proptyp_idx ON t_conduite(cd_proptyp);
		DROP INDEX IF EXISTS cd_statut_idx; CREATE INDEX  cd_statut_idx ON t_conduite(cd_statut);
		DROP INDEX IF EXISTS cd_etat_idx; CREATE INDEX  cd_etat_idx ON t_conduite(cd_etat);



		DROP INDEX IF EXISTS cd_avct_idx; CREATE INDEX  cd_avct_idx ON t_conduite(cd_avct);

























		DROP INDEX IF EXISTS mq_alveole_idx; CREATE UNIQUE INDEX mq_alveole_idx ON t_masque (mq_nd_code, mq_face, mq_col, mq_ligne);
















		DROP INDEX IF EXISTS cb_nd1_idx; CREATE INDEX  cb_nd1_idx ON t_cable(cb_nd1);
		DROP INDEX IF EXISTS cb_nd2_idx; CREATE INDEX  cb_nd2_idx ON t_cable(cb_nd2);




		DROP INDEX IF EXISTS cb_prop_idx; CREATE INDEX  cb_prop_idx ON t_cable(cb_prop);
		DROP INDEX IF EXISTS cb_gest_idx; CREATE INDEX  cb_gest_idx ON t_cable(cb_gest);

		DROP INDEX IF EXISTS cb_proptyp_idx; CREATE INDEX  cb_proptyp_idx ON t_cable(cb_proptyp);
		DROP INDEX IF EXISTS cb_statut_idx; CREATE INDEX  cb_statut_idx ON t_cable(cb_statut);
		DROP INDEX IF EXISTS cb_etat_idx; CREATE INDEX  cb_etat_idx ON t_cable(cb_etat);


		DROP INDEX IF EXISTS cb_avct_idx; CREATE INDEX  cb_avct_idx ON t_cable(cb_avct);

		DROP INDEX IF EXISTS cb_typephy_idx; CREATE INDEX  cb_typephy_idx ON t_cable(cb_typephy);
		DROP INDEX IF EXISTS cb_typelog_idx; CREATE INDEX  cb_typelog_idx ON t_cable(cb_typelog);










































		DROP INDEX IF EXISTS lv_unique_idx; CREATE UNIQUE INDEX lv_unique_idx ON t_love (lv_cb_code, lv_nd_code);











		DROP INDEX IF EXISTS fo_cb_code_idx; CREATE INDEX  fo_cb_code_idx ON t_fibre(fo_cb_code);



		DROP INDEX IF EXISTS fo_type_idx; CREATE INDEX  fo_type_idx ON t_fibre(fo_type);
		DROP INDEX IF EXISTS fo_etat_idx; CREATE INDEX  fo_etat_idx ON t_fibre(fo_etat);


		DROP INDEX IF EXISTS fo_proptyp_idx; CREATE INDEX  fo_proptyp_idx ON t_fibre(fo_proptyp);









		DROP INDEX IF EXISTS ps_numero_idx; CREATE INDEX  ps_numero_idx ON t_position(ps_numero);
		DROP INDEX IF EXISTS ps_1_idx; CREATE INDEX  ps_1_idx ON t_position(ps_1);
		DROP INDEX IF EXISTS ps_2_idx; CREATE INDEX  ps_2_idx ON t_position(ps_2);
		DROP INDEX IF EXISTS ps_cs_code_idx; CREATE INDEX  ps_cs_code_idx ON t_position(ps_cs_code);
		DROP INDEX IF EXISTS ps_ti_code_idx; CREATE INDEX  ps_ti_code_idx ON t_position(ps_ti_code);
		DROP INDEX IF EXISTS ps_type_idx; CREATE INDEX  ps_type_idx ON t_position(ps_type);
		DROP INDEX IF EXISTS ps_fonct_idx; CREATE INDEX  ps_fonct_idx ON t_position(ps_fonct);
		DROP INDEX IF EXISTS ps_etat_idx; CREATE INDEX  ps_etat_idx ON t_position(ps_etat);










		DROP INDEX IF EXISTS rt_code_idx; CREATE INDEX  rt_code_idx ON t_ropt(rt_code);

		DROP INDEX IF EXISTS rt_fo_code_idx; CREATE INDEX  rt_fo_code_idx ON t_ropt(rt_fo_code);










		DROP INDEX IF EXISTS se_nd_code_idx; CREATE INDEX  se_nd_code_idx ON t_siteemission(se_nd_code);
		DROP INDEX IF EXISTS se_anfr_idx; CREATE INDEX  se_anfr_idx ON t_siteemission(se_anfr);
		DROP INDEX IF EXISTS se_prop_idx; CREATE INDEX  se_prop_idx ON t_siteemission(se_prop);
		DROP INDEX IF EXISTS se_gest_idx; CREATE INDEX  se_gest_idx ON t_siteemission(se_gest);

		DROP INDEX IF EXISTS se_proptyp_idx; CREATE INDEX  se_proptyp_idx ON t_siteemission(se_proptyp);
		DROP INDEX IF EXISTS se_statut_idx; CREATE INDEX  se_statut_idx ON t_siteemission(se_statut);
		DROP INDEX IF EXISTS se_etat_idx; CREATE INDEX  se_etat_idx ON t_siteemission(se_etat);



		DROP INDEX IF EXISTS se_type_idx; CREATE INDEX  se_type_idx ON t_siteemission(se_type);

		DROP INDEX IF EXISTS se_ad_code_idx; CREATE INDEX  se_ad_code_idx ON t_siteemission(se_ad_code);









		DROP INDEX IF EXISTS do_ref_idx; CREATE INDEX  do_ref_idx ON t_document(do_ref);

		DROP INDEX IF EXISTS do_r1_code_idx; CREATE INDEX  do_r1_code_idx ON t_document(do_r1_code);
		DROP INDEX IF EXISTS do_r2_code_idx; CREATE INDEX  do_r2_code_idx ON t_document(do_r2_code);
		DROP INDEX IF EXISTS do_r3_code_idx; CREATE INDEX  do_r3_code_idx ON t_document(do_r3_code);
		DROP INDEX IF EXISTS do_r4_code_idx; CREATE INDEX  do_r4_code_idx ON t_document(do_r4_code);
		DROP INDEX IF EXISTS do_type_idx; CREATE INDEX  do_type_idx ON t_document(do_type);

		DROP INDEX IF EXISTS do_date_idx; CREATE INDEX  do_date_idx ON t_document(do_date);

		DROP INDEX IF EXISTS do_url1_idx; CREATE INDEX  do_url1_idx ON t_document(do_url1);
		DROP INDEX IF EXISTS do_url2_idx; CREATE INDEX  do_url2_idx ON t_document(do_url2);









		DROP INDEX IF EXISTS od_do_code_idx; CREATE INDEX  od_do_code_idx ON t_docobj(od_do_code);










		DROP INDEX IF EXISTS em_do_code_idx; CREATE INDEX  em_do_code_idx ON t_empreinte(em_do_code);




		DROP VIEW IF EXISTS "vs_elem_cm_creer";
		CREATE VIEW "vs_elem_cm_creer" AS
		SELECT  * 
		FROM t_cheminement
		WHERE t_cheminement.cm_avct = 'C';

		/*vs_elem_sf_nd*/
		DROP VIEW IF EXISTS "vs_elem_sf_nd";
		CREATE VIEW "vs_elem_sf_nd" AS
		SELECT 
		  * 
		FROM 
		  t_suf,
		  t_noeud
		WHERE 
		  t_suf.sf_nd_code = t_noeud.nd_code;

		  
		/*vs_elem_bp_sf_nd*/
		DROP VIEW IF EXISTS "vs_elem_bp_sf_nd";
		CREATE VIEW "vs_elem_bp_sf_nd" AS
		SELECT 
		  * 
		FROM 
		  t_ebp,
		  t_suf,
		  t_noeud
		WHERE 
		  t_ebp.bp_sf_code = t_suf.sf_code AND
		  t_suf.sf_nd_code = t_noeud.nd_code;

		  
		/*vs_elem_st_nd*/
		DROP VIEW IF EXISTS "vs_elem_st_nd";
		CREATE VIEW "vs_elem_st_nd" AS
		SELECT 
		  * 
		FROM 
		  t_sitetech,
		  t_noeud
		WHERE 
		  t_sitetech.st_nd_code = t_noeud.nd_code;

		  
		/*vs_elem_lt_st_nd*/
		DROP VIEW IF EXISTS "vs_elem_lt_st_nd";
		CREATE VIEW "vs_elem_lt_st_nd" AS
		SELECT 
		  * 
		FROM 
		  t_ltech,
		  t_sitetech,
		  t_noeud
		WHERE 
		  t_sitetech.st_nd_code = t_noeud.nd_code AND
		  t_ltech.lt_st_code = t_sitetech.st_code;
		  

		/*vs_elem_bp_lt_st_nd*/ 
		DROP VIEW IF EXISTS "vs_elem_bp_lt_st_nd";
		CREATE VIEW "vs_elem_bp_lt_st_nd" AS
		SELECT 
		  * 
		FROM 
		  t_ebp,
		  t_ltech,
		  t_sitetech,
		  t_noeud
		WHERE 
		  t_sitetech.st_nd_code = t_noeud.nd_code AND
		  t_ltech.lt_st_code = t_sitetech.st_code AND
		  t_ebp.bp_lt_code = t_ltech.lt_code;  

		/*vs_elem_cs_bp_lt_st_nd*/ 
		DROP VIEW IF EXISTS "vs_elem_cs_bp_lt_st_nd";
		CREATE VIEW "vs_elem_cs_bp_lt_st_nd" AS
		SELECT 
		  * 
		FROM 
		  t_cassette,
		  t_ebp,
		  t_ltech,
		  t_sitetech,
		  t_noeud
		WHERE 
		  t_sitetech.st_nd_code = t_noeud.nd_code AND
		  t_ltech.lt_st_code = t_sitetech.st_code AND
		  t_ebp.bp_lt_code = t_ltech.lt_code AND
		  t_cassette.cs_bp_code = t_ebp.bp_code
		  ;  
		  
		/*vs_elem_ba_lt_st_nd*/
		DROP VIEW IF EXISTS "vs_elem_ba_lt_st_nd";
		CREATE VIEW "vs_elem_ba_lt_st_nd" AS
		SELECT 
		  * 
		FROM 
		  t_baie,
		  t_ltech,
		  t_sitetech,
		  t_noeud
		WHERE 
		  t_sitetech.st_nd_code = t_noeud.nd_code AND
		  t_ltech.lt_st_code = t_sitetech.st_code AND
		  t_baie.ba_lt_code = t_ltech.lt_code;

		/*vs_elem_ti_ba_lt_st_nd*/
		DROP VIEW IF EXISTS "vs_elem_ti_ba_lt_st_nd";
		CREATE VIEW "vs_elem_ti_ba_lt_st_nd" AS
		SELECT 
		  * 
		FROM 
		  t_tiroir,
		  t_baie,
		  t_ltech,
		  t_sitetech,
		  t_noeud
		WHERE 
		  t_sitetech.st_nd_code = t_noeud.nd_code AND
		  t_ltech.lt_st_code = t_sitetech.st_code AND
		  t_baie.ba_lt_code = t_ltech.lt_code AND
		  t_tiroir.ti_ba_code = t_baie.ba_code;

		  
		/*vs_elem_eq_ba_lt_st_nd*/
		DROP VIEW IF EXISTS "vs_elem_eq_ba_lt_st_nd";
		CREATE VIEW "vs_elem_eq_ba_lt_st_nd" AS
		SELECT 
		  * 
		FROM 
		  t_equipement,
		  t_baie,
		  t_ltech,
		  t_sitetech,
		  t_noeud
		WHERE 
		  t_sitetech.st_nd_code = t_noeud.nd_code AND
		  t_ltech.lt_st_code = t_sitetech.st_code AND
		  t_baie.ba_lt_code = t_ltech.lt_code AND
		  t_equipement.eq_ba_code = t_baie.ba_code;

		   
		/*vs_elem_pt_nd*/
		DROP VIEW IF EXISTS "vs_elem_pt_nd";
		CREATE VIEW "vs_elem_pt_nd" AS
		SELECT 
		  * 
		FROM 
		  t_ptech,
		  t_noeud
		WHERE 
		  t_ptech.pt_nd_code = t_noeud.nd_code;

		/*vs_elem_mq_nd*/
		DROP VIEW IF EXISTS "vs_elem_mq_nd";
		CREATE VIEW "vs_elem_mq_nd" AS
		SELECT 
		  * 
		FROM 
		  t_masque,
		  t_noeud
		WHERE 
		  t_masque.mq_nd_code = t_noeud.nd_code;

		  
		/*vs_elem_cl_cb*/ 
		DROP VIEW IF EXISTS "vs_elem_cl_cb";
		CREATE VIEW "vs_elem_cl_cb" AS
		SELECT 
		  * 
		FROM 
		  t_cable,
		  t_cableline
		WHERE 
		  t_cableline.cl_cb_code = t_cable.cb_code;


		/*vs_elem_cl_cb_lv*/ 
		DROP VIEW IF EXISTS "vs_elem_cl_cb_lv";
		CREATE VIEW "vs_elem_cl_cb_lv" AS
		SELECT 
			*
		FROM "t_cableline" AS "cl"
		JOIN "t_cable" AS "cb" ON ("cl"."cl_cb_code" = "cb"."cb_code")
		LEFT JOIN "t_love" AS "lv" ON ("cb"."cb_code" = "lv"."lv_cb_code")
		--ORDER BY "cb"."cb_code"
		;

		  
		/*vs_elem_fo_cb_cl*/ 
		DROP VIEW IF EXISTS "vs_elem_fo_cb_cl";
		CREATE VIEW "vs_elem_fo_cb_cl" AS
		SELECT 
		  * 
		FROM 
		  t_fibre,
		  t_cable,
		  t_cableline
		WHERE 
		  t_fibre.fo_cb_code = t_cable.cb_code AND
		  t_cableline.cl_cb_code = t_cable.cb_code;

		  
		/*vs_elem_rt_fo_cb_cl*/
		DROP VIEW IF EXISTS "vs_elem_rt_fo_cb_cl";
		CREATE VIEW "vs_elem_rt_fo_cb_cl" AS  
		SELECT 
		  * 
		FROM 
		  t_ropt,
		  t_fibre,
		  t_cable,
		  t_cableline
		WHERE 
		  t_cable.cb_code = t_fibre.fo_cb_code AND
		  t_cableline.cl_cb_code = t_cable.cb_code AND
		  t_fibre.fo_code = t_ropt.rt_fo_code;

		  
		/*vs_elem_lv_nd*/
		DROP VIEW IF EXISTS "vs_elem_lv_nd";
		CREATE VIEW "vs_elem_lv_nd" AS
		  SELECT 
		  * 
		FROM 
		  t_love,
		  t_noeud
		WHERE 
		  t_love.lv_nd_code = t_noeud.nd_code;

		  
		/*vs_elem_bp_pt_nd*/ 
		DROP VIEW IF EXISTS "vs_elem_bp_pt_nd";
		CREATE VIEW "vs_elem_bp_pt_nd" AS
		SELECT 
		  * 
		FROM 
		  t_ebp,
		  t_ptech,
		  t_noeud
		WHERE 
		  t_ptech.pt_nd_code = t_noeud.nd_code AND
		  t_ebp.bp_pt_code = t_ptech.pt_code;

		  
		/*vs_elem_cs_bp_pt_nd*/  
		DROP VIEW IF EXISTS "vs_elem_cs_bp_pt_nd";
		CREATE VIEW "vs_elem_cs_bp_pt_nd" AS
		SELECT 
		  * 
		FROM 
		  t_cassette,
		  t_ebp,
		  t_ptech,
		  t_noeud
		WHERE 
		  t_ptech.pt_nd_code = t_noeud.nd_code AND
		  t_ebp.bp_pt_code = t_ptech.pt_code AND
		  t_cassette.cs_bp_code = t_ebp.bp_code;

		  
		/*vs_elem_se_nd*/  
		DROP VIEW IF EXISTS "vs_elem_se_nd";
		CREATE VIEW "vs_elem_se_nd" AS
		SELECT 
		  * 
		FROM 
		  t_siteemission,
		  t_noeud
		WHERE 
		  t_siteemission.se_nd_code = t_noeud.nd_code;
		  

		/*vs_elem_do_em*/  
		DROP VIEW IF EXISTS "vs_elem_do_em";
		CREATE VIEW "vs_elem_do_em" AS
		SELECT 
		  * 
		FROM 
		  t_document,
		  t_empreinte
		WHERE 
		  t_empreinte.em_do_code = t_document.do_code;
		  
		  
		/*vs_elem_cd_dm_cm*/ 
		DROP VIEW IF EXISTS "vs_elem_cd_dm_cm";
		CREATE VIEW "vs_elem_cd_dm_cm" AS
		SELECT 
		  t_cond_chem.dm_cd_code || t_cond_chem.dm_cm_code AS dm_id,
		  * 
		FROM 
		  t_conduite,
		  t_cond_chem,
		  t_cheminement
		WHERE 
		  t_cheminement.cm_code = t_cond_chem.dm_cm_code AND
		  t_cond_chem.dm_cd_code = t_conduite.cd_code;

		  
		/*vs_elem_cb_nd*/
		DROP VIEW IF EXISTS vs_elem_cb_nd;
		CREATE VIEW vs_elem_cb_nd AS
		SELECT DISTINCT
		  'ND1-' || cb.cb_code || '_' || cb.cb_nd1 AS cb_nd,
		  * 
		FROM 
		  t_cable AS cb,
		  t_noeud AS nd
		WHERE 
		  cb.cb_nd1 = nd.nd_code
		UNION
		SELECT DISTINCT
		  'ND2-' || cb.cb_code || '_' || cb.cb_nd1 AS cb_nd,
		  * 
		FROM 
		  t_cable AS cb,
		  t_noeud AS nd
		WHERE 
		  cb.cb_nd2 = nd.nd_code;


		  

		/*######################################*/
		/*VUES ELEMENTAIRES NON SPATIALES*/

		/*v_elem_od_do*/  
		DROP VIEW IF EXISTS "v_elem_od_do";
		CREATE VIEW "v_elem_od_do" AS
		SELECT *
		FROM t_docobj AS "od"
		LEFT JOIN t_document AS "do" ON ("do"."do_code" = "od"."od_do_code");


		/*v_elem_cc_cd*/  
		DROP VIEW IF EXISTS "v_elem_cc_cd";
		CREATE VIEW "v_elem_cc_cd" AS
		SELECT 
		  t_cab_cond.cc_cd_code || '_' || t_cab_cond.cc_cb_code AS cc_cd,
		  * 
		FROM 
		  t_conduite,
		  t_cab_cond
		WHERE 
		  t_cab_cond.cc_cd_code = t_conduite.cd_code;



		/*vs_elem_sf_nd*/
		DROP VIEW IF EXISTS "vs_elem_sf_nd";
		CREATE VIEW "vs_elem_sf_nd" AS
		SELECT 
		  * 
		FROM 
		  t_suf,
		  t_noeud
		WHERE 
		  t_suf.sf_nd_code = t_noeud.nd_code;

		  
		/*vs_elem_bp_sf_nd*/
		DROP VIEW IF EXISTS "vs_elem_bp_sf_nd";
		CREATE VIEW "vs_elem_bp_sf_nd" AS
		SELECT 
		  * 
		FROM 
		  t_ebp,
		  t_suf,
		  t_noeud
		WHERE 
		  t_ebp.bp_sf_code = t_suf.sf_code AND
		  t_suf.sf_nd_code = t_noeud.nd_code;

		  
		/*vs_elem_st_nd*/
		DROP VIEW IF EXISTS "vs_elem_st_nd";
		CREATE VIEW "vs_elem_st_nd" AS
		SELECT 
		  * 
		FROM 
		  t_sitetech,
		  t_noeud
		WHERE 
		  t_sitetech.st_nd_code = t_noeud.nd_code;

		  
		/*vs_elem_lt_st_nd*/
		DROP VIEW IF EXISTS "vs_elem_lt_st_nd";
		CREATE VIEW "vs_elem_lt_st_nd" AS
		SELECT 
		  * 
		FROM 
		  t_ltech,
		  t_sitetech,
		  t_noeud
		WHERE 
		  t_sitetech.st_nd_code = t_noeud.nd_code AND
		  t_ltech.lt_st_code = t_sitetech.st_code;
		  

		/*vs_elem_bp_lt_st_nd*/ 
		DROP VIEW IF EXISTS "vs_elem_bp_lt_st_nd";
		CREATE VIEW "vs_elem_bp_lt_st_nd" AS
		SELECT 
		  * 
		FROM 
		  t_ebp,
		  t_ltech,
		  t_sitetech,
		  t_noeud
		WHERE 
		  t_sitetech.st_nd_code = t_noeud.nd_code AND
		  t_ltech.lt_st_code = t_sitetech.st_code AND
		  t_ebp.bp_lt_code = t_ltech.lt_code;  

		/*vs_elem_cs_bp_lt_st_nd*/ 
		DROP VIEW IF EXISTS "vs_elem_cs_bp_lt_st_nd";
		CREATE VIEW "vs_elem_cs_bp_lt_st_nd" AS
		SELECT 
		  * 
		FROM 
		  t_cassette,
		  t_ebp,
		  t_ltech,
		  t_sitetech,
		  t_noeud
		WHERE 
		  t_sitetech.st_nd_code = t_noeud.nd_code AND
		  t_ltech.lt_st_code = t_sitetech.st_code AND
		  t_ebp.bp_lt_code = t_ltech.lt_code AND
		  t_cassette.cs_bp_code = t_ebp.bp_code
		  ;  
		  
		/*vs_elem_ba_lt_st_nd*/
		DROP VIEW IF EXISTS "vs_elem_ba_lt_st_nd";
		CREATE VIEW "vs_elem_ba_lt_st_nd" AS
		SELECT 
		  * 
		FROM 
		  t_baie,
		  t_ltech,
		  t_sitetech,
		  t_noeud
		WHERE 
		  t_sitetech.st_nd_code = t_noeud.nd_code AND
		  t_ltech.lt_st_code = t_sitetech.st_code AND
		  t_baie.ba_lt_code = t_ltech.lt_code;

		/*vs_elem_ti_ba_lt_st_nd*/
		DROP VIEW IF EXISTS "vs_elem_ti_ba_lt_st_nd";
		CREATE VIEW "vs_elem_ti_ba_lt_st_nd" AS
		SELECT 
		  * 
		FROM 
		  t_tiroir,
		  t_baie,
		  t_ltech,
		  t_sitetech,
		  t_noeud
		WHERE 
		  t_sitetech.st_nd_code = t_noeud.nd_code AND
		  t_ltech.lt_st_code = t_sitetech.st_code AND
		  t_baie.ba_lt_code = t_ltech.lt_code AND
		  t_tiroir.ti_ba_code = t_baie.ba_code;

		  
		/*vs_elem_eq_ba_lt_st_nd*/
		DROP VIEW IF EXISTS "vs_elem_eq_ba_lt_st_nd";
		CREATE VIEW "vs_elem_eq_ba_lt_st_nd" AS
		SELECT 
		  * 
		FROM 
		  t_equipement,
		  t_baie,
		  t_ltech,
		  t_sitetech,
		  t_noeud
		WHERE 
		  t_sitetech.st_nd_code = t_noeud.nd_code AND
		  t_ltech.lt_st_code = t_sitetech.st_code AND
		  t_baie.ba_lt_code = t_ltech.lt_code AND
		  t_equipement.eq_ba_code = t_baie.ba_code;

		   
		/*vs_elem_pt_nd*/
		DROP VIEW IF EXISTS "vs_elem_pt_nd";
		CREATE VIEW "vs_elem_pt_nd" AS
		SELECT 
		  * 
		FROM 
		  t_ptech,
		  t_noeud
		WHERE 
		  t_ptech.pt_nd_code = t_noeud.nd_code;

		/*vs_elem_mq_nd*/
		DROP VIEW IF EXISTS "vs_elem_mq_nd";
		CREATE VIEW "vs_elem_mq_nd" AS
		SELECT 
		  * 
		FROM 
		  t_masque,
		  t_noeud
		WHERE 
		  t_masque.mq_nd_code = t_noeud.nd_code;

		  
		/*vs_elem_cl_cb*/ 
		DROP VIEW IF EXISTS "vs_elem_cl_cb";
		CREATE VIEW "vs_elem_cl_cb" AS
		SELECT 
		  * 
		FROM 
		  t_cable,
		  t_cableline
		WHERE 
		  t_cableline.cl_cb_code = t_cable.cb_code;


		/*vs_elem_cl_cb_lv*/ 
		DROP VIEW IF EXISTS "vs_elem_cl_cb_lv";
		CREATE VIEW "vs_elem_cl_cb_lv" AS
		SELECT 
			*
		FROM "t_cableline" AS "cl"
		JOIN "t_cable" AS "cb" ON ("cl"."cl_cb_code" = "cb"."cb_code")
		LEFT JOIN "t_love" AS "lv" ON ("cb"."cb_code" = "lv"."lv_cb_code")
		--ORDER BY "cb"."cb_code"
		;

		  
		/*vs_elem_fo_cb_cl*/ 
		DROP VIEW IF EXISTS "vs_elem_fo_cb_cl";
		CREATE VIEW "vs_elem_fo_cb_cl" AS
		SELECT 
		  * 
		FROM 
		  t_fibre,
		  t_cable,
		  t_cableline
		WHERE 
		  t_fibre.fo_cb_code = t_cable.cb_code AND
		  t_cableline.cl_cb_code = t_cable.cb_code;

		  
		/*vs_elem_rt_fo_cb_cl*/
		DROP VIEW IF EXISTS "vs_elem_rt_fo_cb_cl";
		CREATE VIEW "vs_elem_rt_fo_cb_cl" AS  
		SELECT 
		  * 
		FROM 
		  t_ropt,
		  t_fibre,
		  t_cable,
		  t_cableline
		WHERE 
		  t_cable.cb_code = t_fibre.fo_cb_code AND
		  t_cableline.cl_cb_code = t_cable.cb_code AND
		  t_fibre.fo_code = t_ropt.rt_fo_code;

		  
		/*vs_elem_lv_nd*/
		DROP VIEW IF EXISTS "vs_elem_lv_nd";
		CREATE VIEW "vs_elem_lv_nd" AS
		  SELECT 
		  * 
		FROM 
		  t_love,
		  t_noeud
		WHERE 
		  t_love.lv_nd_code = t_noeud.nd_code;

		  
		/*vs_elem_bp_pt_nd*/ 
		DROP VIEW IF EXISTS "vs_elem_bp_pt_nd";
		CREATE VIEW "vs_elem_bp_pt_nd" AS
		SELECT 
		  * 
		FROM 
		  t_ebp,
		  t_ptech,
		  t_noeud
		WHERE 
		  t_ptech.pt_nd_code = t_noeud.nd_code AND
		  t_ebp.bp_pt_code = t_ptech.pt_code;

		  
		/*vs_elem_cs_bp_pt_nd*/  
		DROP VIEW IF EXISTS "vs_elem_cs_bp_pt_nd";
		CREATE VIEW "vs_elem_cs_bp_pt_nd" AS
		SELECT 
		  * 
		FROM 
		  t_cassette,
		  t_ebp,
		  t_ptech,
		  t_noeud
		WHERE 
		  t_ptech.pt_nd_code = t_noeud.nd_code AND
		  t_ebp.bp_pt_code = t_ptech.pt_code AND
		  t_cassette.cs_bp_code = t_ebp.bp_code;

		  
		/*vs_elem_se_nd*/  
		DROP VIEW IF EXISTS "vs_elem_se_nd";
		CREATE VIEW "vs_elem_se_nd" AS
		SELECT 
		  * 
		FROM 
		  t_siteemission,
		  t_noeud
		WHERE 
		  t_siteemission.se_nd_code = t_noeud.nd_code;
		  

		/*vs_elem_do_em*/  
		DROP VIEW IF EXISTS "vs_elem_do_em";
		CREATE VIEW "vs_elem_do_em" AS
		SELECT 
		  * 
		FROM 
		  t_document,
		  t_empreinte
		WHERE 
		  t_empreinte.em_do_code = t_document.do_code;
		  
		  
		/*vs_elem_cd_dm_cm*/ 
		DROP VIEW IF EXISTS "vs_elem_cd_dm_cm";
		CREATE VIEW "vs_elem_cd_dm_cm" AS
		SELECT 
		  t_cond_chem.dm_cd_code || t_cond_chem.dm_cm_code AS dm_id,
		  * 
		FROM 
		  t_conduite,
		  t_cond_chem,
		  t_cheminement
		WHERE 
		  t_cheminement.cm_code = t_cond_chem.dm_cm_code AND
		  t_cond_chem.dm_cd_code = t_conduite.cd_code;

		  
		/*vs_elem_cb_nd*/
		DROP VIEW IF EXISTS vs_elem_cb_nd;
		CREATE VIEW vs_elem_cb_nd AS
		SELECT DISTINCT
		  'ND1-' || cb.cb_code || '_' || cb.cb_nd1 AS cb_nd,
		  * 
		FROM 
		  t_cable AS cb,
		  t_noeud AS nd
		WHERE 
		  cb.cb_nd1 = nd.nd_code
		UNION
		SELECT DISTINCT
		  'ND2-' || cb.cb_code || '_' || cb.cb_nd1 AS cb_nd,
		  * 
		FROM 
		  t_cable AS cb,
		  t_noeud AS nd
		WHERE 
		  cb.cb_nd2 = nd.nd_code;
		  
		  
		CREATE OR REPLACE VIEW vs_parcelles_znro AS
		 SELECT cadastre_domanialite.id_par,
			cadastre_domanialite.id_com,
			cadastre_domanialite.parcelle,
			cadastre_domanialite.dvoilib,
			cadastre_domanialite.nat_droit,
			cadastre_domanialite.pers_moral,
			cadastre_domanialite.geom
		   FROM parcelles.cadastre_domanialite,
			t_znro
		  WHERE st_Within(cadastre_domanialite.geom, t_znro.geom);

		ALTER TABLE vs_parcelles_znro
			OWNER TO postgres;


		  

		/*######################################*/
		/*VUES ELEMENTAIRES NON SPATIALES*/

		/*v_elem_od_do*/  
		DROP VIEW IF EXISTS "v_elem_od_do";
		CREATE VIEW "v_elem_od_do" AS
		SELECT *
		FROM t_docobj AS "od"
		LEFT JOIN t_document AS "do" ON ("do"."do_code" = "od"."od_do_code");


		/*v_elem_cc_cd*/  
		DROP VIEW IF EXISTS "v_elem_cc_cd";
		CREATE VIEW "v_elem_cc_cd" AS
		SELECT 
		  t_cab_cond.cc_cd_code || '_' || t_cab_cond.cc_cb_code AS cc_cd,
		  * 
		FROM 
		  t_conduite,
		  t_cab_cond
		WHERE 
		  t_cab_cond.cc_cd_code = t_conduite.cd_code;

		  
		  
		  DROP MATERIALIZED VIEW IF EXISTS "mvs_elem_sf_nd";
		CREATE MATERIALIZED VIEW "mvs_elem_sf_nd" AS
		SELECT 
		  * 
		FROM 
		  t_suf,
		  t_noeud
		WHERE 
		  t_suf.sf_nd_code = t_noeud.nd_code;
		  
		/*mvs_elem_bp_sf_nd*/
		DROP MATERIALIZED VIEW IF EXISTS "mvs_elem_bp_sf_nd";
		CREATE MATERIALIZED VIEW "mvs_elem_bp_sf_nd" AS
		SELECT 
		  * 
		FROM 
		  t_ebp,
		  t_suf,
		  t_noeud
		WHERE 
		  t_ebp.bp_sf_code = t_suf.sf_code AND
		  t_suf.sf_nd_code = t_noeud.nd_code;
		  
		/*mvs_elem_st_nd*/
		DROP MATERIALIZED VIEW IF EXISTS "mvs_elem_st_nd";
		CREATE MATERIALIZED VIEW "mvs_elem_st_nd" AS
		SELECT 
		  * 
		FROM 
		  t_sitetech,
		  t_noeud
		WHERE 
		  t_sitetech.st_nd_code = t_noeud.nd_code;
		  
		/*mvs_elem_lt_st_nd*/
		DROP MATERIALIZED VIEW IF EXISTS "mvs_elem_lt_st_nd";
		CREATE MATERIALIZED VIEW "mvs_elem_lt_st_nd" AS
		SELECT 
		  * 
		FROM 
		  t_ltech,
		  t_sitetech,
		  t_noeud
		WHERE 
		  t_sitetech.st_nd_code = t_noeud.nd_code AND
		  t_ltech.lt_st_code = t_sitetech.st_code;

		/*mvs_elem_bp_lt_st_nd*/ 
		DROP MATERIALIZED VIEW IF EXISTS "mvs_elem_bp_lt_st_nd";
		CREATE MATERIALIZED VIEW "mvs_elem_bp_lt_st_nd" AS
		SELECT 
		  * 
		FROM 
		  t_ebp,
		  t_ltech,
		  t_sitetech,
		  t_noeud
		WHERE 
		  t_sitetech.st_nd_code = t_noeud.nd_code AND
		  t_ltech.lt_st_code = t_sitetech.st_code AND
		  t_ebp.bp_lt_code = t_ltech.lt_code;  

		/*vs_elem_cs_bp_lt_st_nd*/ 
		DROP MATERIALIZED VIEW IF EXISTS "mvs_elem_cs_bp_lt_st_nd";
		CREATE MATERIALIZED VIEW "mvs_elem_cs_bp_lt_st_nd" AS
		SELECT 
		  * 
		FROM 
		  t_cassette,
		  t_ebp,
		  t_ltech,
		  t_sitetech,
		  t_noeud
		WHERE 
		  t_sitetech.st_nd_code = t_noeud.nd_code AND
		  t_ltech.lt_st_code = t_sitetech.st_code AND
		  t_ebp.bp_lt_code = t_ltech.lt_code AND
		  t_cassette.cs_bp_code = t_ebp.bp_code
		  ; 

		/*mvs_elem_ba_lt_st_nd*/
		DROP MATERIALIZED VIEW IF EXISTS "mvs_elem_ba_lt_st_nd";
		CREATE MATERIALIZED VIEW "mvs_elem_ba_lt_st_nd" AS
		SELECT 
		  * 
		FROM 
		  t_baie,
		  t_ltech,
		  t_sitetech,
		  t_noeud
		WHERE 
		  t_sitetech.st_nd_code = t_noeud.nd_code AND
		  t_ltech.lt_st_code = t_sitetech.st_code AND
		  t_baie.ba_lt_code = t_ltech.lt_code;

		/*mvs_elem_ti_ba_lt_st_nd*/
		DROP MATERIALIZED VIEW IF EXISTS "mvs_elem_ti_ba_lt_st_nd";
		CREATE MATERIALIZED VIEW "mvs_elem_ti_ba_lt_st_nd" AS
		SELECT 
		  * 
		FROM 
		  t_tiroir,
		  t_baie,
		  t_ltech,
		  t_sitetech,
		  t_noeud
		WHERE 
		  t_sitetech.st_nd_code = t_noeud.nd_code AND
		  t_ltech.lt_st_code = t_sitetech.st_code AND
		  t_baie.ba_lt_code = t_ltech.lt_code AND
		  t_tiroir.ti_ba_code = t_baie.ba_code;

		  
		/*mvs_elem_eq_ba_lt_st_nd*/
		DROP MATERIALIZED VIEW IF EXISTS "mvs_elem_eq_ba_lt_st_nd";
		CREATE MATERIALIZED VIEW "mvs_elem_eq_ba_lt_st_nd" AS
		SELECT 
		  * 
		FROM 
		  t_equipement,
		  t_baie,
		  t_ltech,
		  t_sitetech,
		  t_noeud
		WHERE 
		  t_sitetech.st_nd_code = t_noeud.nd_code AND
		  t_ltech.lt_st_code = t_sitetech.st_code AND
		  t_baie.ba_lt_code = t_ltech.lt_code AND
		  t_equipement.eq_ba_code = t_baie.ba_code;

		   
		/*mvs_elem_pt_nd*/
		DROP MATERIALIZED VIEW IF EXISTS "mvs_elem_pt_nd";
		CREATE MATERIALIZED VIEW "mvs_elem_pt_nd" AS
		SELECT 
		  * 
		FROM 
		  t_ptech,
		  t_noeud
		WHERE 
		  t_ptech.pt_nd_code = t_noeud.nd_code;

		/*mvs_elem_mq_nd*/
		DROP MATERIALIZED VIEW IF EXISTS "mvs_elem_mq_nd";
		CREATE MATERIALIZED VIEW "mvs_elem_mq_nd" AS
		SELECT 
		  * 
		FROM 
		  t_masque,
		  t_noeud
		WHERE 
		  t_masque.mq_nd_code = t_noeud.nd_code;

		  
		/*mvs_elem_cl_cb*/ 
		DROP MATERIALIZED VIEW IF EXISTS "mvs_elem_cl_cb";
		CREATE MATERIALIZED VIEW "mvs_elem_cl_cb" AS
		SELECT 
		  * 
		FROM 
		  t_cable,
		  t_cableline
		WHERE 
		  t_cableline.cl_cb_code = t_cable.cb_code;


		/*mvs_elem_cl_cb_lv*/ 
		DROP MATERIALIZED VIEW IF EXISTS "mvs_elem_cl_cb_lv";
		CREATE MATERIALIZED VIEW "mvs_elem_cl_cb_lv" AS
		SELECT 
			*
		FROM "t_cableline" AS "cl"
		JOIN "t_cable" AS "cb" ON ("cl"."cl_cb_code" = "cb"."cb_code")
		LEFT JOIN "t_love" AS "lv" ON ("cb"."cb_code" = "lv"."lv_cb_code")
		--ORDER BY "cb"."cb_code"
		;

		  
		/*mvs_elem_fo_cb_cl*/ 
		DROP MATERIALIZED VIEW IF EXISTS "mvs_elem_fo_cb_cl";
		CREATE MATERIALIZED VIEW "mvs_elem_fo_cb_cl" AS
		SELECT 
		  * 
		FROM 
		  t_fibre,
		  t_cable,
		  t_cableline
		WHERE 
		  t_fibre.fo_cb_code = t_cable.cb_code AND
		  t_cableline.cl_cb_code = t_cable.cb_code;

		  
		/*mvs_elem_rt_fo_cb_cl*/
		DROP MATERIALIZED VIEW IF EXISTS "mvs_elem_rt_fo_cb_cl";
		CREATE MATERIALIZED VIEW "mvs_elem_rt_fo_cb_cl" AS  
		SELECT 
		  * 
		FROM 
		  t_ropt,
		  t_fibre,
		  t_cable,
		  t_cableline
		WHERE 
		  t_cable.cb_code = t_fibre.fo_cb_code AND
		  t_cableline.cl_cb_code = t_cable.cb_code AND
		  t_fibre.fo_code = t_ropt.rt_fo_code;

		  
		/*mvs_elem_lv_nd*/
		DROP MATERIALIZED VIEW IF EXISTS "mvs_elem_lv_nd";
		CREATE MATERIALIZED VIEW "mvs_elem_lv_nd" AS
		  SELECT 
		  * 
		FROM 
		  t_love,
		  t_noeud
		WHERE 
		  t_love.lv_nd_code = t_noeud.nd_code;

		  
		/*mvs_elem_bp_pt_nd*/ 
		DROP MATERIALIZED VIEW IF EXISTS "mvs_elem_bp_pt_nd";
		CREATE MATERIALIZED VIEW "mvs_elem_bp_pt_nd" AS
		SELECT 
		  * 
		FROM 
		  t_ebp,
		  t_ptech,
		  t_noeud
		WHERE 
		  t_ptech.pt_nd_code = t_noeud.nd_code AND
		  t_ebp.bp_pt_code = t_ptech.pt_code;

		  
		/*mvs_elem_cs_bp_pt_nd*/  
		DROP MATERIALIZED VIEW IF EXISTS "mvs_elem_cs_bp_pt_nd";
		CREATE MATERIALIZED VIEW "mvs_elem_cs_bp_pt_nd" AS
		SELECT 
		  * 
		FROM 
		  t_cassette,
		  t_ebp,
		  t_ptech,
		  t_noeud
		WHERE 
		  t_ptech.pt_nd_code = t_noeud.nd_code AND
		  t_ebp.bp_pt_code = t_ptech.pt_code AND
		  t_cassette.cs_bp_code = t_ebp.bp_code;

		  
		/*mvs_elem_se_nd*/  
		DROP MATERIALIZED VIEW IF EXISTS "mvs_elem_se_nd";
		CREATE MATERIALIZED VIEW "mvs_elem_se_nd" AS
		SELECT 
		  * 
		FROM 
		  t_siteemission,
		  t_noeud
		WHERE 
		  t_siteemission.se_nd_code = t_noeud.nd_code;
		  

		/*mvs_elem_do_em*/  
		DROP MATERIALIZED VIEW IF EXISTS "mvs_elem_do_em";
		CREATE MATERIALIZED VIEW "mvs_elem_do_em" AS
		SELECT 
		  * 
		FROM 
		  t_document,
		  t_empreinte
		WHERE 
		  t_empreinte.em_do_code = t_document.do_code;
		  
		  
		/*mvs_elem_cd_dm_cm*/ 
		DROP MATERIALIZED VIEW IF EXISTS "mvs_elem_cd_dm_cm";
		CREATE MATERIALIZED VIEW "mvs_elem_cd_dm_cm" AS
		SELECT 
		  t_cond_chem.dm_cd_code || t_cond_chem.dm_cm_code AS dm_id,
		  * 
		FROM 
		  t_conduite,
		  t_cond_chem,
		  t_cheminement
		WHERE 
		  t_cheminement.cm_code = t_cond_chem.dm_cm_code AND
		  t_cond_chem.dm_cd_code = t_conduite.cd_code;

		  
		/*mvs_elem_cb_nd*/
		DROP MATERIALIZED VIEW IF EXISTS mvs_elem_cb_nd;
		CREATE MATERIALIZED VIEW mvs_elem_cb_nd AS
		SELECT DISTINCT
		  'ND1-' || cb.cb_code || '_' || cb.cb_nd1 AS cb_nd,
		  * 
		FROM 
		  t_cable AS cb,
		  t_noeud AS nd
		WHERE 
		  cb.cb_nd1 = nd.nd_code
		UNION
		SELECT DISTINCT
		  'ND2-' || cb.cb_code || '_' || cb.cb_nd1 AS cb_nd,
		  * 
		FROM 
		  t_cable AS cb,
		  t_noeud AS nd
		WHERE 
		  cb.cb_nd2 = nd.nd_code;


		/*######################################*/
		/*INDEXES SPATIAUX SUR LES VUES ELEMENTAIRES*/

		--v_elem_cc_cd
		--v_elem_od_do
		CREATE INDEX mvs_elem_ba_lt_st_nd_geom_gist ON mvs_elem_ba_lt_st_nd USING GIST (geom);
		CREATE INDEX mvs_elem_bp_pt_nd_geom_gist ON mvs_elem_bp_pt_nd USING GIST (geom);
		CREATE INDEX mvs_elem_bp_sf_nd_geom_gist ON mvs_elem_bp_sf_nd USING GIST (geom);
		CREATE INDEX mvs_elem_cb_nd_geom_gist ON mvs_elem_cb_nd USING GIST (geom);
		CREATE INDEX mvs_elem_cd_dm_cm_geom_gist ON mvs_elem_cd_dm_cm USING GIST (geom);
		CREATE INDEX mvs_elem_cl_cb_geom_gist ON mvs_elem_cl_cb USING GIST (geom);
		CREATE INDEX mvs_elem_cl_cb_lv_geom_gist ON mvs_elem_cl_cb_lv USING GIST (geom);
		CREATE INDEX mvs_elem_cs_bp_pt_nd_geom_gist ON mvs_elem_cs_bp_pt_nd USING GIST (geom);
		CREATE INDEX mvs_elem_do_em_geom_gist ON mvs_elem_do_em USING GIST (geom);
		CREATE INDEX mvs_elem_eq_ba_lt_st_nd_geom_gist ON mvs_elem_eq_ba_lt_st_nd USING GIST (geom);
		CREATE INDEX mvs_elem_fo_cb_cl_geom_gist ON mvs_elem_fo_cb_cl USING GIST (geom);
		CREATE INDEX mvs_elem_lt_st_nd_geom_gist ON mvs_elem_lt_st_nd USING GIST (geom);
		CREATE INDEX mvs_elem_bp_lt_st_nd_geom_gist ON mvs_elem_bp_lt_st_nd USING GIST (geom);
		CREATE INDEX mvs_elem_lv_nd_geom_gist ON mvs_elem_lv_nd USING GIST (geom);
		CREATE INDEX mvs_elem_mq_nd_geom_gist ON mvs_elem_mq_nd USING GIST (geom);
		CREATE INDEX mvs_elem_pt_nd_geom_gist ON mvs_elem_pt_nd USING GIST (geom);
		CREATE INDEX mvs_elem_rt_fo_cb_cl_geom_gist ON mvs_elem_rt_fo_cb_cl USING GIST (geom);
		CREATE INDEX mvs_elem_se_nd_geom_gist ON mvs_elem_se_nd USING GIST (geom);
		CREATE INDEX mvs_elem_sf_nd_geom_gist ON mvs_elem_sf_nd USING GIST (geom);
		CREATE INDEX mvs_elem_st_nd_geom_gist ON mvs_elem_st_nd USING GIST (geom);
		CREATE INDEX mvs_elem_ti_ba_lt_st_nd_geom_gist ON mvs_elem_ti_ba_lt_st_nd USING GIST (geom);
		  

		/*######################################*/
		/*VUES ELEMENTAIRES NON SPATIALES*/

		/*mv_elem_od_do*/  
		DROP MATERIALIZED VIEW IF EXISTS "mv_elem_od_do";
		CREATE MATERIALIZED VIEW "mv_elem_od_do" AS
		SELECT *
		FROM t_docobj AS "od"
		LEFT JOIN t_document AS "do" ON ("do"."do_code" = "od"."od_do_code");


		/*mv_elem_cc_cd*/  
		DROP MATERIALIZED VIEW IF EXISTS "mv_elem_cc_cd";
		CREATE MATERIALIZED VIEW "mv_elem_cc_cd" AS
		SELECT 
		  t_cab_cond.cc_cd_code || '_' || t_cab_cond.cc_cb_code AS cc_cd,
		  * 
		FROM 
		  t_conduite,
		  t_cab_cond
		WHERE 
		  t_cab_cond.cc_cd_code = t_conduite.cd_code;


		DROP TRIGGER IF EXISTS tg_edit_vs_elem_cl_cb ON vs_elem_cl_cb CASCADE;
		DROP FUNCTION IF EXISTS fn_edit_vs_elem_cl_cb() CASCADE;

		CREATE OR REPLACE FUNCTION fn_edit_vs_elem_cl_cb()
		RETURNS TRIGGER
		LANGUAGE plpgsql
		AS $function$
		   BEGIN
			  IF TG_OP = 'INSERT' THEN
				INSERT INTO  t_cable VALUES(
					NEW.cb_code,
					NEW.cb_codeext,
					NEW.cb_etiquet,
					NEW.cb_nd1,
					NEW.cb_nd2,
					NEW.cb_r1_code,
					NEW.cb_r2_code,
					NEW.cb_r3_code,
					NEW.cb_r4_code,
					NEW.cb_prop,
					NEW.cb_gest,
					NEW.cb_user,
					NEW.cb_proptyp,
					NEW.cb_statut,
					NEW.cb_etat,
					NEW.cb_dateins,
					NEW.cb_datemes,
					NEW.cb_avct,
					NEW.cb_tech,
					NEW.cb_typephy,
					NEW.cb_typelog,
					NEW.cb_rf_code,
					NEW.cb_capafo,
					NEW.cb_fo_disp,
					NEW.cb_fo_util,
					NEW.cb_modulo,
					NEW.cb_diam,
					NEW.cb_color,
					NEW.cb_lgreel,
					NEW.cb_localis,
					NEW.cb_comment,
					NEW.cb_creadat,
					NEW.cb_majdate,
					NEW.cb_majsrc,
					NEW.cb_abddate,
					NEW.cb_abdsrc
					);
				INSERT INTO  t_cableline VALUES(
					NEW.cl_code,
					NEW.cl_cb_code,
					NEW.cl_long,
					NEW.cl_comment,
					NEW.cl_dtclass,
					NEW.cl_geolqlt,
					NEW.cl_geolmod,
					NEW.cl_geolsrc,
					NEW.cl_creadat,
					NEW.cl_majdate,
					NEW.cl_majsrc,
					NEW.cl_abddate,
					NEW.cl_abdsrc,
					NEW.geom
					);
				RETURN NEW;
			  ELSIF TG_OP = 'UPDATE' THEN
				UPDATE t_cable SET 
					cb_code=NEW.cb_code,
					cb_codeext=NEW.cb_codeext,
					cb_etiquet=NEW.cb_etiquet,
					cb_nd1=NEW.cb_nd1,
					cb_nd2=NEW.cb_nd2,
					cb_r1_code=NEW.cb_r1_code,
					cb_r2_code=NEW.cb_r2_code,
					cb_r3_code=NEW.cb_r3_code,
					cb_r4_code=NEW.cb_r4_code,
					cb_prop=NEW.cb_prop,
					cb_gest=NEW.cb_gest,
					cb_user=NEW.cb_user,
					cb_proptyp=NEW.cb_proptyp,
					cb_statut=NEW.cb_statut,
					cb_etat=NEW.cb_etat,
					cb_dateins=NEW.cb_dateins,
					cb_datemes=NEW.cb_datemes,
					cb_avct=NEW.cb_avct,
					cb_tech=NEW.cb_tech,
					cb_typephy=NEW.cb_typephy,
					cb_typelog=NEW.cb_typelog,
					cb_rf_code=NEW.cb_rf_code,
					cb_capafo=NEW.cb_capafo,
					cb_fo_disp=NEW.cb_fo_disp,
					cb_fo_util=NEW.cb_fo_util,
					cb_modulo=NEW.cb_modulo,
					cb_diam=NEW.cb_diam,
					cb_color=NEW.cb_color,
					cb_lgreel=NEW.cb_lgreel,
					cb_localis=NEW.cb_localis,
					cb_comment=NEW.cb_comment,
					cb_creadat=NEW.cb_creadat,
					cb_majdate=NEW.cb_majdate,
					cb_majsrc=NEW.cb_majsrc,
					cb_abddate=NEW.cb_abddate,
					cb_abdsrc=NEW.cb_abdsrc
				WHERE cb_code=OLD.cb_code
				;
				UPDATE t_cableline SET 
					cl_code=NEW.cl_code, 
					cl_cb_code=NEW.cl_cb_code, 
					--cl_cb_code=NEW.cb_code,
					cl_long=NEW.cl_long,
					cl_comment=NEW.cl_comment,
					cl_dtclass=NEW.cl_dtclass,
					cl_geolqlt=NEW.cl_geolqlt,
					cl_geolmod=NEW.cl_geolmod,
					cl_geolsrc=NEW.cl_geolsrc,
					cl_creadat=NEW.cl_creadat,
					cl_majdate=NEW.cl_majdate,
					cl_majsrc=NEW.cl_majsrc,
					cl_abddate=NEW.cl_abddate,
					cl_abdsrc=NEW.cl_abdsrc,
					geom=NEW.geom
				WHERE cl_code=OLD.cl_code	
				;
				RETURN NEW;
			  ELSIF TG_OP = 'DELETE' THEN
				/*INVERSER ?*/
				DELETE FROM t_cableline WHERE cl_code=OLD.cl_code;
				DELETE FROM t_cable WHERE cb_code=OLD.cb_code;
			   RETURN NULL;
			  END IF;
			  RETURN NEW;
			END;
		$function$;

		CREATE TRIGGER tg_edit_vs_elem_cl_cb
			INSTEAD OF INSERT OR UPDATE OR DELETE ON
			  vs_elem_cl_cb FOR EACH ROW EXECUTE PROCEDURE fn_edit_vs_elem_cl_cb();

		/*vs_elem_cl_cb_lv*/
		DROP TRIGGER IF EXISTS tg_edit_vs_elem_cl_cb_lv ON vs_elem_cl_cb_lv CASCADE;
		DROP FUNCTION IF EXISTS fn_edit_vs_elem_cl_cb_lv() CASCADE;

		CREATE OR REPLACE FUNCTION fn_edit_vs_elem_cl_cb_lv()
		RETURNS TRIGGER
		LANGUAGE plpgsql
		AS $function$
		   BEGIN
			  IF TG_OP = 'INSERT' THEN
				INSERT INTO  t_cable VALUES(
					NEW.cb_code,
					NEW.cb_codeext,
					NEW.cb_etiquet,
					NEW.cb_nd1,
					NEW.cb_nd2,
					NEW.cb_r1_code,
					NEW.cb_r2_code,
					NEW.cb_r3_code,
					NEW.cb_r4_code,
					NEW.cb_prop,
					NEW.cb_gest,
					NEW.cb_user,
					NEW.cb_proptyp,
					NEW.cb_statut,
					NEW.cb_etat,
					NEW.cb_dateins,
					NEW.cb_datemes,
					NEW.cb_avct,
					NEW.cb_tech,
					NEW.cb_typephy,
					NEW.cb_typelog,
					NEW.cb_rf_code,
					NEW.cb_capafo,
					NEW.cb_fo_disp,
					NEW.cb_fo_util,
					NEW.cb_modulo,
					NEW.cb_diam,
					NEW.cb_color,
					NEW.cb_lgreel,
					NEW.cb_localis,
					NEW.cb_comment,
					NEW.cb_creadat,
					NEW.cb_majdate,
					NEW.cb_majsrc,
					NEW.cb_abddate,
					NEW.cb_abdsrc
					);
				INSERT INTO  t_cableline VALUES(
					NEW.cl_code,
					NEW.cl_cb_code,
					NEW.cl_long,
					NEW.cl_comment,
					NEW.cl_dtclass,
					NEW.cl_geolqlt,
					NEW.cl_geolmod,
					NEW.cl_geolsrc,
					NEW.cl_creadat,
					NEW.cl_majdate,
					NEW.cl_majsrc,
					NEW.cl_abddate,
					NEW.cl_abdsrc,
					NEW.geom
					);
				INSERT INTO t_love VALUES(
					NEW.lv_id,
					NEW.lv_cb_code,
					NEW.lv_nd_code,
					NEW.lv_long,
					NEW.lv_creadat,
					NEW.lv_majdate,
					NEW.lv_majsrc,
					NEW.lv_abddate,
					NEW.lv_abdsrc
					);
				RETURN NEW;
			  ELSIF TG_OP = 'UPDATE' THEN
				UPDATE t_cable SET 
					cb_code=NEW.cb_code,
					cb_codeext=NEW.cb_codeext,
					cb_etiquet=NEW.cb_etiquet,
					cb_nd1=NEW.cb_nd1,
					cb_nd2=NEW.cb_nd2,
					cb_r1_code=NEW.cb_r1_code,
					cb_r2_code=NEW.cb_r2_code,
					cb_r3_code=NEW.cb_r3_code,
					cb_r4_code=NEW.cb_r4_code,
					cb_prop=NEW.cb_prop,
					cb_gest=NEW.cb_gest,
					cb_user=NEW.cb_user,
					cb_proptyp=NEW.cb_proptyp,
					cb_statut=NEW.cb_statut,
					cb_etat=NEW.cb_etat,
					cb_dateins=NEW.cb_dateins,
					cb_datemes=NEW.cb_datemes,
					cb_avct=NEW.cb_avct,
					cb_tech=NEW.cb_tech,
					cb_typephy=NEW.cb_typephy,
					cb_typelog=NEW.cb_typelog,
					cb_rf_code=NEW.cb_rf_code,
					cb_capafo=NEW.cb_capafo,
					cb_fo_disp=NEW.cb_fo_disp,
					cb_fo_util=NEW.cb_fo_util,
					cb_modulo=NEW.cb_modulo,
					cb_diam=NEW.cb_diam,
					cb_color=NEW.cb_color,
					cb_lgreel=NEW.cb_lgreel,
					cb_localis=NEW.cb_localis,
					cb_comment=NEW.cb_comment,
					cb_creadat=NEW.cb_creadat,
					cb_majdate=NEW.cb_majdate,
					cb_majsrc=NEW.cb_majsrc,
					cb_abddate=NEW.cb_abddate,
					cb_abdsrc=NEW.cb_abdsrc
				WHERE cb_code=OLD.cb_code
				;
				UPDATE t_cableline SET 
					cl_code=NEW.cl_code, 
					cl_cb_code=NEW.cl_cb_code, 
					--cl_cb_code=NEW.cb_code,
					cl_long=NEW.cl_long,
					cl_comment=NEW.cl_comment,
					cl_dtclass=NEW.cl_dtclass,
					cl_geolqlt=NEW.cl_geolqlt,
					cl_geolmod=NEW.cl_geolmod,
					cl_geolsrc=NEW.cl_geolsrc,
					cl_creadat=NEW.cl_creadat,
					cl_majdate=NEW.cl_majdate,
					cl_majsrc=NEW.cl_majsrc,
					cl_abddate=NEW.cl_abddate,
					cl_abdsrc=NEW.cl_abdsrc,
					geom=NEW.geom
				WHERE cl_code=OLD.cl_code	
				;
				UPDATE t_love SET 
					lv_id=NEW.lv_id,
					lv_cb_code=NEW.lv_cb_code,
					lv_nd_code=NEW.lv_nd_code,
					lv_long=NEW.lv_long,
					lv_creadat=NEW.lv_creadat,
					lv_majdate=NEW.lv_majdate,
					lv_majsrc=NEW.lv_majsrc,
					lv_abddate=NEW.lv_abddate,
					lv_abdsrc=NEW.lv_abdsrc
				WHERE lv_id=OLD.lv_id	
				;
				RETURN NEW;
			  ELSIF TG_OP = 'DELETE' THEN
				DELETE FROM t_love WHERE lv_id=OLD.lv_id;
				DELETE FROM t_cableline WHERE cl_code=OLD.cl_code;
				DELETE FROM t_cable WHERE cb_code=OLD.cb_code;
			   RETURN NULL;
			  END IF;
			  RETURN NEW;
			END;
		$function$;

		CREATE TRIGGER tg_edit_vs_elem_cl_cb_lv
			INSTEAD OF INSERT OR UPDATE OR DELETE ON
			  vs_elem_cl_cb_lv FOR EACH ROW EXECUTE PROCEDURE fn_edit_vs_elem_cl_cb_lv();

		/*vs_elem_fo_cb_cl*/
		DROP TRIGGER IF EXISTS tg_edit_vs_elem_fo_cb_cl ON vs_elem_fo_cb_cl CASCADE;
		DROP FUNCTION IF EXISTS fn_edit_vs_elem_fo_cb_cl() CASCADE;

		CREATE OR REPLACE FUNCTION fn_edit_vs_elem_fo_cb_cl()
		RETURNS TRIGGER
		LANGUAGE plpgsql
		AS $function$
		   BEGIN
			  IF TG_OP = 'INSERT' THEN
				INSERT INTO  t_cable VALUES(
					NEW.cb_code,
					NEW.cb_codeext,
					NEW.cb_etiquet,
					NEW.cb_nd1,
					NEW.cb_nd2,
					NEW.cb_r1_code,
					NEW.cb_r2_code,
					NEW.cb_r3_code,
					NEW.cb_r4_code,
					NEW.cb_prop,
					NEW.cb_gest,
					NEW.cb_user,
					NEW.cb_proptyp,
					NEW.cb_statut,
					NEW.cb_etat,
					NEW.cb_dateins,
					NEW.cb_datemes,
					NEW.cb_avct,
					NEW.cb_tech,
					NEW.cb_typephy,
					NEW.cb_typelog,
					NEW.cb_rf_code,
					NEW.cb_capafo,
					NEW.cb_fo_disp,
					NEW.cb_fo_util,
					NEW.cb_modulo,
					NEW.cb_diam,
					NEW.cb_color,
					NEW.cb_lgreel,
					NEW.cb_localis,
					NEW.cb_comment,
					NEW.cb_creadat,
					NEW.cb_majdate,
					NEW.cb_majsrc,
					NEW.cb_abddate,
					NEW.cb_abdsrc
					);
				INSERT INTO  t_cableline VALUES(
					NEW.cl_code,
					NEW.cl_cb_code,
					NEW.cl_long,
					NEW.cl_comment,
					NEW.cl_dtclass,
					NEW.cl_geolqlt,
					NEW.cl_geolmod,
					NEW.cl_geolsrc,
					NEW.cl_creadat,
					NEW.cl_majdate,
					NEW.cl_majsrc,
					NEW.cl_abddate,
					NEW.cl_abdsrc,
					NEW.geom
					);
				INSERT INTO t_fibre VALUES(
					NEW.fo_code,
					NEW.fo_code_ext,
					NEW.fo_cb_code,
					NEW.fo_nincab,
					NEW.fo_numtub,
					NEW.fo_nintub,
					NEW.fo_type,
					NEW.fo_etat,
					NEW.fo_color,
					NEW.fo_reper,
					NEW.fo_proptyp,
					NEW.fo_comment,
					NEW.fo_creadat,
					NEW.fo_majdate,
					NEW.fo_majsrc,
					NEW.fo_abddate,
					NEW.fo_abdsrc
					);
				RETURN NEW;
			  ELSIF TG_OP = 'UPDATE' THEN
				UPDATE t_cable SET 
					cb_code=NEW.cb_code,
					cb_codeext=NEW.cb_codeext,
					cb_etiquet=NEW.cb_etiquet,
					cb_nd1=NEW.cb_nd1,
					cb_nd2=NEW.cb_nd2,
					cb_r1_code=NEW.cb_r1_code,
					cb_r2_code=NEW.cb_r2_code,
					cb_r3_code=NEW.cb_r3_code,
					cb_r4_code=NEW.cb_r4_code,
					cb_prop=NEW.cb_prop,
					cb_gest=NEW.cb_gest,
					cb_user=NEW.cb_user,
					cb_proptyp=NEW.cb_proptyp,
					cb_statut=NEW.cb_statut,
					cb_etat=NEW.cb_etat,
					cb_dateins=NEW.cb_dateins,
					cb_datemes=NEW.cb_datemes,
					cb_avct=NEW.cb_avct,
					cb_tech=NEW.cb_tech,
					cb_typephy=NEW.cb_typephy,
					cb_typelog=NEW.cb_typelog,
					cb_rf_code=NEW.cb_rf_code,
					cb_capafo=NEW.cb_capafo,
					cb_fo_disp=NEW.cb_fo_disp,
					cb_fo_util=NEW.cb_fo_util,
					cb_modulo=NEW.cb_modulo,
					cb_diam=NEW.cb_diam,
					cb_color=NEW.cb_color,
					cb_lgreel=NEW.cb_lgreel,
					cb_localis=NEW.cb_localis,
					cb_comment=NEW.cb_comment,
					cb_creadat=NEW.cb_creadat,
					cb_majdate=NEW.cb_majdate,
					cb_majsrc=NEW.cb_majsrc,
					cb_abddate=NEW.cb_abddate,
					cb_abdsrc=NEW.cb_abdsrc
				WHERE cb_code=OLD.cb_code
				;
				UPDATE t_cableline SET 
					cl_code=NEW.cl_code, 
					cl_cb_code=NEW.cl_cb_code, 
					--cl_cb_code=NEW.cb_code,
					cl_long=NEW.cl_long,
					cl_comment=NEW.cl_comment,
					cl_dtclass=NEW.cl_dtclass,
					cl_geolqlt=NEW.cl_geolqlt,
					cl_geolmod=NEW.cl_geolmod,
					cl_geolsrc=NEW.cl_geolsrc,
					cl_creadat=NEW.cl_creadat,
					cl_majdate=NEW.cl_majdate,
					cl_majsrc=NEW.cl_majsrc,
					cl_abddate=NEW.cl_abddate,
					cl_abdsrc=NEW.cl_abdsrc,
					geom=NEW.geom
				WHERE cl_code=OLD.cl_code	
				;
				UPDATE t_fibre SET 
					fo_code=NEW.fo_code,
					fo_code_ext=NEW.fo_code_ext,
					fo_cb_code=NEW.fo_cb_code,
					fo_nincab=NEW.fo_nincab,
					fo_numtub=NEW.fo_numtub,
					fo_nintub=NEW.fo_nintub,
					fo_type=NEW.fo_type,
					fo_etat=NEW.fo_etat,
					fo_color=NEW.fo_color,
					fo_reper=NEW.fo_reper,
					fo_proptyp=NEW.fo_proptyp,
					fo_comment=NEW.fo_comment,
					fo_creadat=NEW.fo_creadat,
					fo_majdate=NEW.fo_majdate,
					fo_majsrc=NEW.fo_majsrc,
					fo_abddate=NEW.fo_abddate,
					fo_abdsrc=NEW.fo_abdsrc
				WHERE fo_code=OLD.fo_code	
				;
				RETURN NEW;
			  ELSIF TG_OP = 'DELETE' THEN
				DELETE FROM t_fibre WHERE fo_code=OLD.fo_code;
				DELETE FROM t_cableline WHERE cl_code=OLD.cl_code;
				DELETE FROM t_cable WHERE cb_code=OLD.cb_code;
			   RETURN NULL;
			  END IF;
			  RETURN NEW;
			END;
		$function$;

		CREATE TRIGGER tg_edit_vs_elem_fo_cb_cl
			INSTEAD OF INSERT OR UPDATE OR DELETE ON
			  vs_elem_fo_cb_cl FOR EACH ROW EXECUTE PROCEDURE fn_edit_vs_elem_fo_cb_cl();

		/*vs_elem_rt_fo_cb_cl*/
		DROP TRIGGER IF EXISTS tg_edit_vs_elem_rt_fo_cb_cl ON vs_elem_rt_fo_cb_cl CASCADE;
		DROP FUNCTION IF EXISTS fn_edit_vs_elem_rt_fo_cb_cl() CASCADE;

		CREATE OR REPLACE FUNCTION fn_edit_vs_elem_rt_fo_cb_cl()
		RETURNS TRIGGER
		LANGUAGE plpgsql
		AS $function$
		   BEGIN
			  IF TG_OP = 'INSERT' THEN
				INSERT INTO  t_cable VALUES(
					NEW.cb_code,
					NEW.cb_codeext,
					NEW.cb_etiquet,
					NEW.cb_nd1,
					NEW.cb_nd2,
					NEW.cb_r1_code,
					NEW.cb_r2_code,
					NEW.cb_r3_code,
					NEW.cb_r4_code,
					NEW.cb_prop,
					NEW.cb_gest,
					NEW.cb_user,
					NEW.cb_proptyp,
					NEW.cb_statut,
					NEW.cb_etat,
					NEW.cb_dateins,
					NEW.cb_datemes,
					NEW.cb_avct,
					NEW.cb_tech,
					NEW.cb_typephy,
					NEW.cb_typelog,
					NEW.cb_rf_code,
					NEW.cb_capafo,
					NEW.cb_fo_disp,
					NEW.cb_fo_util,
					NEW.cb_modulo,
					NEW.cb_diam,
					NEW.cb_color,
					NEW.cb_lgreel,
					NEW.cb_localis,
					NEW.cb_comment,
					NEW.cb_creadat,
					NEW.cb_majdate,
					NEW.cb_majsrc,
					NEW.cb_abddate,
					NEW.cb_abdsrc
					);
				INSERT INTO  t_cableline VALUES(
					NEW.cl_code,
					NEW.cl_cb_code,
					NEW.cl_long,
					NEW.cl_comment,
					NEW.cl_dtclass,
					NEW.cl_geolqlt,
					NEW.cl_geolmod,
					NEW.cl_geolsrc,
					NEW.cl_creadat,
					NEW.cl_majdate,
					NEW.cl_majsrc,
					NEW.cl_abddate,
					NEW.cl_abdsrc,
					NEW.geom
					);
				INSERT INTO t_fibre VALUES(
					NEW.fo_code,
					NEW.fo_code_ext,
					NEW.fo_cb_code,
					NEW.fo_nincab,
					NEW.fo_numtub,
					NEW.fo_nintub,
					NEW.fo_type,
					NEW.fo_etat,
					NEW.fo_color,
					NEW.fo_reper,
					NEW.fo_proptyp,
					NEW.fo_comment,
					NEW.fo_creadat,
					NEW.fo_majdate,
					NEW.fo_majsrc,
					NEW.fo_abddate,
					NEW.fo_abdsrc
					);
				INSERT INTO t_ropt VALUES(
					NEW.rt_id,
					NEW.rt_code,
					NEW.rt_code_ext,
					NEW.rt_fo_code,
					NEW.rt_fo_ordr,
					NEW.rt_comment,
					NEW.rt_creadat,
					NEW.rt_majdate,
					NEW.rt_majsrc,
					NEW.rt_abddate,
					NEW.rt_abdsrc			);
				RETURN NEW;
			  ELSIF TG_OP = 'UPDATE' THEN
				UPDATE t_cable SET 
					cb_code=NEW.cb_code,
					cb_codeext=NEW.cb_codeext,
					cb_etiquet=NEW.cb_etiquet,
					cb_nd1=NEW.cb_nd1,
					cb_nd2=NEW.cb_nd2,
					cb_r1_code=NEW.cb_r1_code,
					cb_r2_code=NEW.cb_r2_code,
					cb_r3_code=NEW.cb_r3_code,
					cb_r4_code=NEW.cb_r4_code,
					cb_prop=NEW.cb_prop,
					cb_gest=NEW.cb_gest,
					cb_user=NEW.cb_user,
					cb_proptyp=NEW.cb_proptyp,
					cb_statut=NEW.cb_statut,
					cb_etat=NEW.cb_etat,
					cb_dateins=NEW.cb_dateins,
					cb_datemes=NEW.cb_datemes,
					cb_avct=NEW.cb_avct,
					cb_tech=NEW.cb_tech,
					cb_typephy=NEW.cb_typephy,
					cb_typelog=NEW.cb_typelog,
					cb_rf_code=NEW.cb_rf_code,
					cb_capafo=NEW.cb_capafo,
					cb_fo_disp=NEW.cb_fo_disp,
					cb_fo_util=NEW.cb_fo_util,
					cb_modulo=NEW.cb_modulo,
					cb_diam=NEW.cb_diam,
					cb_color=NEW.cb_color,
					cb_lgreel=NEW.cb_lgreel,
					cb_localis=NEW.cb_localis,
					cb_comment=NEW.cb_comment,
					cb_creadat=NEW.cb_creadat,
					cb_majdate=NEW.cb_majdate,
					cb_majsrc=NEW.cb_majsrc,
					cb_abddate=NEW.cb_abddate,
					cb_abdsrc=NEW.cb_abdsrc
				WHERE cb_code=OLD.cb_code
				;
				UPDATE t_cableline SET 
					cl_code=NEW.cl_code, 
					cl_cb_code=NEW.cl_cb_code, 
					--cl_cb_code=NEW.cb_code,
					cl_long=NEW.cl_long,
					cl_comment=NEW.cl_comment,
					cl_dtclass=NEW.cl_dtclass,
					cl_geolqlt=NEW.cl_geolqlt,
					cl_geolmod=NEW.cl_geolmod,
					cl_geolsrc=NEW.cl_geolsrc,
					cl_creadat=NEW.cl_creadat,
					cl_majdate=NEW.cl_majdate,
					cl_majsrc=NEW.cl_majsrc,
					cl_abddate=NEW.cl_abddate,
					cl_abdsrc=NEW.cl_abdsrc,
					geom=NEW.geom
				WHERE cl_code=OLD.cl_code	
				;
				UPDATE t_fibre SET 
					fo_code=NEW.fo_code,
					fo_code_ext=NEW.fo_code_ext,
					fo_cb_code=NEW.fo_cb_code,
					fo_nincab=NEW.fo_nincab,
					fo_numtub=NEW.fo_numtub,
					fo_nintub=NEW.fo_nintub,
					fo_type=NEW.fo_type,
					fo_etat=NEW.fo_etat,
					fo_color=NEW.fo_color,
					fo_reper=NEW.fo_reper,
					fo_proptyp=NEW.fo_proptyp,
					fo_comment=NEW.fo_comment,
					fo_creadat=NEW.fo_creadat,
					fo_majdate=NEW.fo_majdate,
					fo_majsrc=NEW.fo_majsrc,
					fo_abddate=NEW.fo_abddate,
					fo_abdsrc=NEW.fo_abdsrc
				WHERE fo_code=OLD.fo_code	
				;
				UPDATE t_ropt SET 
					rt_id=NEW.rt_id,
					rt_code=NEW.rt_code,
					rt_code_ext=NEW.rt_code_ext,
					rt_fo_code=NEW.rt_fo_code,
					rt_fo_ordr=NEW.rt_fo_ordr,
					rt_comment=NEW.rt_comment,
					rt_creadat=NEW.rt_creadat,
					rt_majdate=NEW.rt_majdate,
					rt_majsrc=NEW.rt_majsrc,
					rt_abddate=NEW.rt_abddate,
					rt_abdsrc=NEW.rt_abdsrc
				WHERE rt_id=OLD.rt_id	
				;		
				RETURN NEW;
			  ELSIF TG_OP = 'DELETE' THEN
				DELETE FROM t_ropt WHERE rt_id=OLD.rt_id;
				DELETE FROM t_fibre WHERE fo_code=OLD.fo_code;
				DELETE FROM t_cableline WHERE cl_code=OLD.cl_code;
				DELETE FROM t_cable WHERE cb_code=OLD.cb_code;
			   RETURN NULL;
			  END IF;
			  RETURN NEW;
			END;
		$function$;

		CREATE TRIGGER tg_edit_vs_elem_rt_fo_cb_cl
			INSTEAD OF INSERT OR UPDATE OR DELETE ON
			  vs_elem_rt_fo_cb_cl FOR EACH ROW EXECUTE PROCEDURE fn_edit_vs_elem_rt_fo_cb_cl();
			  
			  
		/*vs_elem_st_nd*/
		DROP TRIGGER IF EXISTS tg_edit_vs_elem_st_nd ON vs_elem_st_nd CASCADE;
		DROP FUNCTION IF EXISTS fn_edit_vs_elem_st_nd() CASCADE;

		CREATE OR REPLACE FUNCTION fn_edit_vs_elem_st_nd()
		RETURNS TRIGGER
		LANGUAGE plpgsql
		AS $function$
		   BEGIN
			  IF TG_OP = 'INSERT' THEN
				INSERT INTO  t_noeud VALUES(
					NEW.nd_code,
					NEW.nd_codeext,
					NEW.nd_nom,
					NEW.nd_coderat,
					NEW.nd_r1_code,
					NEW.nd_r2_code,
					NEW.nd_r3_code,
					NEW.nd_r4_code,
					NEW.nd_voie,
					NEW.nd_type,
					NEW.nd_type_ep,
					NEW.nd_comment,
					NEW.nd_dtclass,
					NEW.nd_geolqlt,
					NEW.nd_geolmod,
					NEW.nd_geolsrc,
					NEW.nd_creadat,
					NEW.nd_majdate,
					NEW.nd_majsrc,
					NEW.nd_abddate,
					NEW.nd_abdsrc,
					NEW.geom
					);
				INSERT INTO  t_sitetech VALUES(
					NEW.st_code,
					NEW.st_nd_code,
					NEW.st_codeext,
					NEW.st_nom,
					NEW.st_prop,
					NEW.st_gest,
					NEW.st_user,
					NEW.st_proptyp,
					NEW.st_statut,
					NEW.st_etat,
					NEW.st_dateins,
					NEW.st_datemes,
					NEW.st_avct,
					NEW.st_typephy,
					NEW.st_typelog,
					NEW.st_nblines,
					NEW.st_ad_code,
					NEW.st_comment,
					NEW.st_creadat,
					NEW.st_majdate,
					NEW.st_majsrc,
					NEW.st_abddate,
					NEW.st_abdsrc
					);
				RETURN NEW;
			  ELSIF TG_OP = 'UPDATE' THEN
				UPDATE t_noeud SET 
					nd_code=NEW.nd_code,
					nd_codeext=NEW.nd_codeext,
					nd_nom=NEW.nd_nom,
					nd_coderat=NEW.nd_coderat,
					nd_r1_code=NEW.nd_r1_code,
					nd_r2_code=NEW.nd_r2_code,
					nd_r3_code=NEW.nd_r3_code,
					nd_r4_code=NEW.nd_r4_code,
					nd_voie=NEW.nd_voie,
					nd_type=NEW.nd_type,
					nd_type_ep=NEW.nd_type_ep,
					nd_comment=NEW.nd_comment,
					nd_dtclass=NEW.nd_dtclass,
					nd_geolqlt=NEW.nd_geolqlt,
					nd_geolmod=NEW.nd_geolmod,
					nd_geolsrc=NEW.nd_geolsrc,
					nd_creadat=NEW.nd_creadat,
					nd_majdate=NEW.nd_majdate,
					nd_majsrc=NEW.nd_majsrc,
					nd_abddate=NEW.nd_abddate,
					nd_abdsrc=NEW.nd_abdsrc,
					geom=NEW.geom			
				WHERE nd_code=OLD.nd_code
				;
				UPDATE t_sitetech SET 
					st_code=NEW.st_code,
					st_nd_code=NEW.st_nd_code,
					st_codeext=NEW.st_codeext,
					st_nom=NEW.st_nom,
					st_prop=NEW.st_prop,
					st_gest=NEW.st_gest,
					st_user=NEW.st_user,
					st_proptyp=NEW.st_proptyp,
					st_statut=NEW.st_statut,
					st_etat=NEW.st_etat,
					st_dateins=NEW.st_dateins,
					st_datemes=NEW.st_datemes,
					st_avct=NEW.st_avct,
					st_typephy=NEW.st_typephy,
					st_typelog=NEW.st_typelog,
					st_nblines=NEW.st_nblines,
					st_ad_code=NEW.st_ad_code,
					st_comment=NEW.st_comment,
					st_creadat=NEW.st_creadat,
					st_majdate=NEW.st_majdate,
					st_majsrc=NEW.st_majsrc,
					st_abddate=NEW.st_abddate,
					st_abdsrc=NEW.st_abdsrc
				WHERE st_code=OLD.st_code
				;
				RETURN NEW;
			  ELSIF TG_OP = 'DELETE' THEN
				/*INVERSER ?*/
				DELETE FROM t_sitetech WHERE st_code=OLD.st_code;
				DELETE FROM t_noeud WHERE nd_code=OLD.nd_code;
			   RETURN NULL;
			  END IF;
			  RETURN NEW;
			END;
		$function$;

		CREATE TRIGGER tg_edit_vs_elem_st_nd
			INSTEAD OF INSERT OR UPDATE OR DELETE ON
			  vs_elem_st_nd FOR EACH ROW EXECUTE PROCEDURE fn_edit_vs_elem_st_nd();

			  
		/*vs_elem_lt_st_nd*/
		DROP TRIGGER IF EXISTS tg_edit_vs_elem_lt_st_nd ON vs_elem_lt_st_nd CASCADE;
		DROP FUNCTION IF EXISTS fn_edit_vs_elem_lt_st_nd() CASCADE;

		CREATE OR REPLACE FUNCTION fn_edit_vs_elem_lt_st_nd()
		RETURNS TRIGGER
		LANGUAGE plpgsql
		AS $function$
		   BEGIN
			  IF TG_OP = 'INSERT' THEN
				INSERT INTO  t_noeud VALUES(
					NEW.nd_code,
					NEW.nd_codeext,
					NEW.nd_nom,
					NEW.nd_coderat,
					NEW.nd_r1_code,
					NEW.nd_r2_code,
					NEW.nd_r3_code,
					NEW.nd_r4_code,
					NEW.nd_voie,
					NEW.nd_type,
					NEW.nd_type_ep,
					NEW.nd_comment,
					NEW.nd_dtclass,
					NEW.nd_geolqlt,
					NEW.nd_geolmod,
					NEW.nd_geolsrc,
					NEW.nd_creadat,
					NEW.nd_majdate,
					NEW.nd_majsrc,
					NEW.nd_abddate,
					NEW.nd_abdsrc,
					NEW.geom
					);
				INSERT INTO  t_sitetech VALUES(
					NEW.st_code,
					NEW.st_nd_code,
					NEW.st_codeext,
					NEW.st_nom,
					NEW.st_prop,
					NEW.st_gest,
					NEW.st_user,
					NEW.st_proptyp,
					NEW.st_statut,
					NEW.st_etat,
					NEW.st_dateins,
					NEW.st_datemes,
					NEW.st_avct,
					NEW.st_typephy,
					NEW.st_typelog,
					NEW.st_nblines,
					NEW.st_ad_code,
					NEW.st_comment,
					NEW.st_creadat,
					NEW.st_majdate,
					NEW.st_majsrc,
					NEW.st_abddate,
					NEW.st_abdsrc
					);
				INSERT INTO  t_ltech VALUES(
					NEW.lt_code,
					NEW.lt_codeext,
					NEW.lt_etiquet,
					NEW.lt_st_code,
					NEW.lt_prop,
					NEW.lt_gest,
					NEW.lt_user,
					NEW.lt_proptyp,
					NEW.lt_statut,
					NEW.lt_etat,
					NEW.lt_dateins,
					NEW.lt_datemes,
					NEW.lt_local,
					NEW.lt_elec,
					NEW.lt_clim,
					NEW.lt_occp,
					NEW.lt_idmajic,
					NEW.lt_comment,
					NEW.lt_creadat,
					NEW.lt_majdate,
					NEW.lt_majsrc,
					NEW.lt_abddate,
					NEW.lt_abdsrc
					);
				RETURN NEW;
			  ELSIF TG_OP = 'UPDATE' THEN
				UPDATE t_noeud SET 
					nd_code=NEW.nd_code,
					nd_codeext=NEW.nd_codeext,
					nd_nom=NEW.nd_nom,
					nd_coderat=NEW.nd_coderat,
					nd_r1_code=NEW.nd_r1_code,
					nd_r2_code=NEW.nd_r2_code,
					nd_r3_code=NEW.nd_r3_code,
					nd_r4_code=NEW.nd_r4_code,
					nd_voie=NEW.nd_voie,
					nd_type=NEW.nd_type,
					nd_type_ep=NEW.nd_type_ep,
					nd_comment=NEW.nd_comment,
					nd_dtclass=NEW.nd_dtclass,
					nd_geolqlt=NEW.nd_geolqlt,
					nd_geolmod=NEW.nd_geolmod,
					nd_geolsrc=NEW.nd_geolsrc,
					nd_creadat=NEW.nd_creadat,
					nd_majdate=NEW.nd_majdate,
					nd_majsrc=NEW.nd_majsrc,
					nd_abddate=NEW.nd_abddate,
					nd_abdsrc=NEW.nd_abdsrc,
					geom=NEW.geom			
				WHERE nd_code=OLD.nd_code
				;
				UPDATE t_sitetech SET 
					st_code=NEW.st_code,
					st_nd_code=NEW.st_nd_code,
					st_codeext=NEW.st_codeext,
					st_nom=NEW.st_nom,
					st_prop=NEW.st_prop,
					st_gest=NEW.st_gest,
					st_user=NEW.st_user,
					st_proptyp=NEW.st_proptyp,
					st_statut=NEW.st_statut,
					st_etat=NEW.st_etat,
					st_dateins=NEW.st_dateins,
					st_datemes=NEW.st_datemes,
					st_avct=NEW.st_avct,
					st_typephy=NEW.st_typephy,
					st_typelog=NEW.st_typelog,
					st_nblines=NEW.st_nblines,
					st_ad_code=NEW.st_ad_code,
					st_comment=NEW.st_comment,
					st_creadat=NEW.st_creadat,
					st_majdate=NEW.st_majdate,
					st_majsrc=NEW.st_majsrc,
					st_abddate=NEW.st_abddate,
					st_abdsrc=NEW.st_abdsrc
				WHERE st_code=OLD.st_code
				;
				UPDATE t_ltech SET 
					lt_code=NEW.lt_code,
					lt_codeext=NEW.lt_codeext,
					lt_etiquet=NEW.lt_etiquet,
					lt_st_code=NEW.lt_st_code,
					lt_prop=NEW.lt_prop,
					lt_gest=NEW.lt_gest,
					lt_user=NEW.lt_user,
					lt_proptyp=NEW.lt_proptyp,
					lt_statut=NEW.lt_statut,
					lt_etat=NEW.lt_etat,
					lt_dateins=NEW.lt_dateins,
					lt_datemes=NEW.lt_datemes,
					lt_local=NEW.lt_local,
					lt_elec=NEW.lt_elec,
					lt_clim=NEW.lt_clim,
					lt_occp=NEW.lt_occp,
					lt_idmajic=NEW.lt_idmajic,
					lt_comment=NEW.lt_comment,
					lt_creadat=NEW.lt_creadat,
					lt_majdate=NEW.lt_majdate,
					lt_majsrc=NEW.lt_majsrc,
					lt_abddate=NEW.lt_abddate,
					lt_abdsrc=NEW.lt_abdsrc
				WHERE lt_code=OLD.lt_code
				;
				RETURN NEW;
			  ELSIF TG_OP = 'DELETE' THEN
				/*INVERSER ?*/
				DELETE FROM t_ltech WHERE lt_code=OLD.lt_code;
				DELETE FROM t_sitetech WHERE st_code=OLD.st_code;
				DELETE FROM t_noeud WHERE nd_code=OLD.nd_code;
			   RETURN NULL;
			  END IF;
			  RETURN NEW;
			END;
		$function$;

		CREATE TRIGGER tg_edit_vs_elem_lt_st_nd
			INSTEAD OF INSERT OR UPDATE OR DELETE ON
			  vs_elem_lt_st_nd FOR EACH ROW EXECUTE PROCEDURE fn_edit_vs_elem_lt_st_nd();

		/*vs_elem_bp_lt_st_nd*/
		DROP TRIGGER IF EXISTS tg_edit_vs_elem_bp_lt_st_nd ON vs_elem_bp_lt_st_nd CASCADE;
		DROP FUNCTION IF EXISTS fn_edit_vs_elem_bp_lt_st_nd() CASCADE;

		CREATE OR REPLACE FUNCTION fn_edit_vs_elem_bp_lt_st_nd()
		RETURNS TRIGGER
		LANGUAGE plpgsql
		AS $function$
		   BEGIN
			  IF TG_OP = 'INSERT' THEN
				INSERT INTO  t_noeud VALUES(
					NEW.nd_code,
					NEW.nd_codeext,
					NEW.nd_nom,
					NEW.nd_coderat,
					NEW.nd_r1_code,
					NEW.nd_r2_code,
					NEW.nd_r3_code,
					NEW.nd_r4_code,
					NEW.nd_voie,
					NEW.nd_type,
					NEW.nd_type_ep,
					NEW.nd_comment,
					NEW.nd_dtclass,
					NEW.nd_geolqlt,
					NEW.nd_geolmod,
					NEW.nd_geolsrc,
					NEW.nd_creadat,
					NEW.nd_majdate,
					NEW.nd_majsrc,
					NEW.nd_abddate,
					NEW.nd_abdsrc,
					NEW.geom
					);
				INSERT INTO  t_sitetech VALUES(
					NEW.st_code,
					NEW.st_nd_code,
					NEW.st_codeext,
					NEW.st_nom,
					NEW.st_prop,
					NEW.st_gest,
					NEW.st_user,
					NEW.st_proptyp,
					NEW.st_statut,
					NEW.st_etat,
					NEW.st_dateins,
					NEW.st_datemes,
					NEW.st_avct,
					NEW.st_typephy,
					NEW.st_typelog,
					NEW.st_nblines,
					NEW.st_ad_code,
					NEW.st_comment,
					NEW.st_creadat,
					NEW.st_majdate,
					NEW.st_majsrc,
					NEW.st_abddate,
					NEW.st_abdsrc
					);
				INSERT INTO  t_ltech VALUES(
					NEW.lt_code,
					NEW.lt_codeext,
					NEW.lt_etiquet,
					NEW.lt_st_code,
					NEW.lt_prop,
					NEW.lt_gest,
					NEW.lt_user,
					NEW.lt_proptyp,
					NEW.lt_statut,
					NEW.lt_etat,
					NEW.lt_dateins,
					NEW.lt_datemes,
					NEW.lt_local,
					NEW.lt_elec,
					NEW.lt_clim,
					NEW.lt_occp,
					NEW.lt_idmajic,
					NEW.lt_comment,
					NEW.lt_creadat,
					NEW.lt_majdate,
					NEW.lt_majsrc,
					NEW.lt_abddate,
					NEW.lt_abdsrc
					);
				INSERT INTO  t_ebp VALUES(			
					NEW.bp_code,
					NEW.bp_etiquet,
					NEW.bp_codeext,
					NEW.bp_pt_code,
					NEW.bp_lt_code,
					NEW.bp_sf_code,
					NEW.bp_prop,
					NEW.bp_gest,
					NEW.bp_user,
					NEW.bp_proptyp,
					NEW.bp_statut,
					NEW.bp_etat,
					NEW.bp_occp,
					NEW.bp_datemes,
					NEW.bp_avct,
					NEW.bp_typephy,
					NEW.bp_typelog,
					NEW.bp_rf_code,
					NEW.bp_entrees,
					NEW.bp_ref_kit,
					NEW.bp_ca_nb,
					NEW.bp_nb_pas,
					NEW.bp_linecod,
					NEW.bp_oc_code,
					NEW.bp_racco,
					NEW.bp_comment,
					NEW.bp_creadat,
					NEW.bp_majdate,
					NEW.bp_majsrc,
					NEW.bp_abddate,
					NEW.bp_abdsrc
					);
				RETURN NEW;
			  ELSIF TG_OP = 'UPDATE' THEN
				UPDATE t_noeud SET 
					nd_code=NEW.nd_code,
					nd_codeext=NEW.nd_codeext,
					nd_nom=NEW.nd_nom,
					nd_coderat=NEW.nd_coderat,
					nd_r1_code=NEW.nd_r1_code,
					nd_r2_code=NEW.nd_r2_code,
					nd_r3_code=NEW.nd_r3_code,
					nd_r4_code=NEW.nd_r4_code,
					nd_voie=NEW.nd_voie,
					nd_type=NEW.nd_type,
					nd_type_ep=NEW.nd_type_ep,
					nd_comment=NEW.nd_comment,
					nd_dtclass=NEW.nd_dtclass,
					nd_geolqlt=NEW.nd_geolqlt,
					nd_geolmod=NEW.nd_geolmod,
					nd_geolsrc=NEW.nd_geolsrc,
					nd_creadat=NEW.nd_creadat,
					nd_majdate=NEW.nd_majdate,
					nd_majsrc=NEW.nd_majsrc,
					nd_abddate=NEW.nd_abddate,
					nd_abdsrc=NEW.nd_abdsrc,
					geom=NEW.geom			
				WHERE nd_code=OLD.nd_code
				;
				UPDATE t_sitetech SET 
					st_code=NEW.st_code,
					st_nd_code=NEW.st_nd_code,
					st_codeext=NEW.st_codeext,
					st_nom=NEW.st_nom,
					st_prop=NEW.st_prop,
					st_gest=NEW.st_gest,
					st_user=NEW.st_user,
					st_proptyp=NEW.st_proptyp,
					st_statut=NEW.st_statut,
					st_etat=NEW.st_etat,
					st_dateins=NEW.st_dateins,
					st_datemes=NEW.st_datemes,
					st_avct=NEW.st_avct,
					st_typephy=NEW.st_typephy,
					st_typelog=NEW.st_typelog,
					st_nblines=NEW.st_nblines,
					st_ad_code=NEW.st_ad_code,
					st_comment=NEW.st_comment,
					st_creadat=NEW.st_creadat,
					st_majdate=NEW.st_majdate,
					st_majsrc=NEW.st_majsrc,
					st_abddate=NEW.st_abddate,
					st_abdsrc=NEW.st_abdsrc
				WHERE st_code=OLD.st_code
				;
				UPDATE t_ltech SET 
					lt_code=NEW.lt_code,
					lt_codeext=NEW.lt_codeext,
					lt_etiquet=NEW.lt_etiquet,
					lt_st_code=NEW.lt_st_code,
					lt_prop=NEW.lt_prop,
					lt_gest=NEW.lt_gest,
					lt_user=NEW.lt_user,
					lt_proptyp=NEW.lt_proptyp,
					lt_statut=NEW.lt_statut,
					lt_etat=NEW.lt_etat,
					lt_dateins=NEW.lt_dateins,
					lt_datemes=NEW.lt_datemes,
					lt_local=NEW.lt_local,
					lt_elec=NEW.lt_elec,
					lt_clim=NEW.lt_clim,
					lt_occp=NEW.lt_occp,
					lt_idmajic=NEW.lt_idmajic,
					lt_comment=NEW.lt_comment,
					lt_creadat=NEW.lt_creadat,
					lt_majdate=NEW.lt_majdate,
					lt_majsrc=NEW.lt_majsrc,
					lt_abddate=NEW.lt_abddate,
					lt_abdsrc=NEW.lt_abdsrc
				WHERE lt_code=OLD.lt_code
				;
				UPDATE t_ebp SET 
					bp_code=NEW.bp_code,
					bp_etiquet=NEW.bp_etiquet,
					bp_codeext=NEW.bp_codeext,
					bp_pt_code=NEW.bp_pt_code,
					bp_lt_code=NEW.bp_lt_code,
					bp_sf_code=NEW.bp_sf_code,
					bp_prop=NEW.bp_prop,
					bp_gest=NEW.bp_gest,
					bp_user=NEW.bp_user,
					bp_proptyp=NEW.bp_proptyp,
					bp_statut=NEW.bp_statut,
					bp_etat=NEW.bp_etat,
					bp_occp=NEW.bp_occp,
					bp_datemes=NEW.bp_datemes,
					bp_avct=NEW.bp_avct,
					bp_typephy=NEW.bp_typephy,
					bp_typelog=NEW.bp_typelog,
					bp_rf_code=NEW.bp_rf_code,
					bp_entrees=NEW.bp_entrees,
					bp_ref_kit=NEW.bp_ref_kit,
					bp_ca_nb=NEW.bp_ca_nb,
					bp_nb_pas=NEW.bp_nb_pas,
					bp_linecod=NEW.bp_linecod,
					bp_oc_code=NEW.bp_oc_code,
					bp_racco=NEW.bp_racco,
					bp_comment=NEW.bp_comment,
					bp_creadat=NEW.bp_creadat,
					bp_majdate=NEW.bp_majdate,
					bp_majsrc=NEW.bp_majsrc,
					bp_abddate=NEW.bp_abddate,
					bp_abdsrc=NEW.bp_abdsrc
				WHERE bp_code=OLD.bp_code
				;
				RETURN NEW;
			  ELSIF TG_OP = 'DELETE' THEN
				/*INVERSER ?*/
				DELETE FROM t_ebp WHERE bp_code=OLD.bp_code;		
				DELETE FROM t_ltech WHERE lt_code=OLD.lt_code;
				DELETE FROM t_sitetech WHERE st_code=OLD.st_code;
				DELETE FROM t_noeud WHERE nd_code=OLD.nd_code;
			   RETURN NULL;
			  END IF;
			  RETURN NEW;
			END;
		$function$;

		CREATE TRIGGER tg_edit_vs_elem_bp_lt_st_nd
			INSTEAD OF INSERT OR UPDATE OR DELETE ON
			  vs_elem_bp_lt_st_nd FOR EACH ROW EXECUTE PROCEDURE fn_edit_vs_elem_bp_lt_st_nd();

			  
		/*vs_elem_ba_lt_st_nd*/
		DROP TRIGGER IF EXISTS tg_edit_vs_elem_ba_lt_st_nd ON vs_elem_ba_lt_st_nd CASCADE;
		DROP FUNCTION IF EXISTS fn_edit_vs_elem_ba_lt_st_nd() CASCADE;

		CREATE OR REPLACE FUNCTION fn_edit_vs_elem_ba_lt_st_nd()
		RETURNS TRIGGER
		LANGUAGE plpgsql
		AS $function$
		   BEGIN
			  IF TG_OP = 'INSERT' THEN
				INSERT INTO  t_noeud VALUES(
					NEW.nd_code,
					NEW.nd_codeext,
					NEW.nd_nom,
					NEW.nd_coderat,
					NEW.nd_r1_code,
					NEW.nd_r2_code,
					NEW.nd_r3_code,
					NEW.nd_r4_code,
					NEW.nd_voie,
					NEW.nd_type,
					NEW.nd_type_ep,
					NEW.nd_comment,
					NEW.nd_dtclass,
					NEW.nd_geolqlt,
					NEW.nd_geolmod,
					NEW.nd_geolsrc,
					NEW.nd_creadat,
					NEW.nd_majdate,
					NEW.nd_majsrc,
					NEW.nd_abddate,
					NEW.nd_abdsrc,
					NEW.geom
					);
				INSERT INTO  t_sitetech VALUES(
					NEW.st_code,
					NEW.st_nd_code,
					NEW.st_codeext,
					NEW.st_nom,
					NEW.st_prop,
					NEW.st_gest,
					NEW.st_user,
					NEW.st_proptyp,
					NEW.st_statut,
					NEW.st_etat,
					NEW.st_dateins,
					NEW.st_datemes,
					NEW.st_avct,
					NEW.st_typephy,
					NEW.st_typelog,
					NEW.st_nblines,
					NEW.st_ad_code,
					NEW.st_comment,
					NEW.st_creadat,
					NEW.st_majdate,
					NEW.st_majsrc,
					NEW.st_abddate,
					NEW.st_abdsrc
					);
				INSERT INTO  t_ltech VALUES(
					NEW.lt_code,
					NEW.lt_codeext,
					NEW.lt_etiquet,
					NEW.lt_st_code,
					NEW.lt_prop,
					NEW.lt_gest,
					NEW.lt_user,
					NEW.lt_proptyp,
					NEW.lt_statut,
					NEW.lt_etat,
					NEW.lt_dateins,
					NEW.lt_datemes,
					NEW.lt_local,
					NEW.lt_elec,
					NEW.lt_clim,
					NEW.lt_occp,
					NEW.lt_idmajic,
					NEW.lt_comment,
					NEW.lt_creadat,
					NEW.lt_majdate,
					NEW.lt_majsrc,
					NEW.lt_abddate,
					NEW.lt_abdsrc
					);
				INSERT INTO t_baie VALUES(
					NEW.ba_code,
					NEW.ba_codeext,
					NEW.ba_etiquet,
					NEW.ba_lt_code,
					NEW.ba_prop,
					NEW.ba_gest,
					NEW.ba_user,
					NEW.ba_proptyp,
					NEW.ba_statut,
					NEW.ba_etat,
					NEW.ba_rf_code,
					NEW.ba_type,
					NEW.ba_nb_u,
					NEW.ba_haut,
					NEW.ba_larg,
					NEW.ba_prof,
					NEW.ba_comment,
					NEW.ba_creadat,
					NEW.ba_majdate,
					NEW.ba_majsrc,
					NEW.ba_abddate,
					NEW.ba_abdsrc
					);
				RETURN NEW;
			  ELSIF TG_OP = 'UPDATE' THEN
				UPDATE t_noeud SET 
					nd_code=NEW.nd_code,
					nd_codeext=NEW.nd_codeext,
					nd_nom=NEW.nd_nom,
					nd_coderat=NEW.nd_coderat,
					nd_r1_code=NEW.nd_r1_code,
					nd_r2_code=NEW.nd_r2_code,
					nd_r3_code=NEW.nd_r3_code,
					nd_r4_code=NEW.nd_r4_code,
					nd_voie=NEW.nd_voie,
					nd_type=NEW.nd_type,
					nd_type_ep=NEW.nd_type_ep,
					nd_comment=NEW.nd_comment,
					nd_dtclass=NEW.nd_dtclass,
					nd_geolqlt=NEW.nd_geolqlt,
					nd_geolmod=NEW.nd_geolmod,
					nd_geolsrc=NEW.nd_geolsrc,
					nd_creadat=NEW.nd_creadat,
					nd_majdate=NEW.nd_majdate,
					nd_majsrc=NEW.nd_majsrc,
					nd_abddate=NEW.nd_abddate,
					nd_abdsrc=NEW.nd_abdsrc,
					geom=NEW.geom			
				WHERE nd_code=OLD.nd_code
				;
				UPDATE t_sitetech SET 
					st_code=NEW.st_code,
					st_nd_code=NEW.st_nd_code,
					st_codeext=NEW.st_codeext,
					st_nom=NEW.st_nom,
					st_prop=NEW.st_prop,
					st_gest=NEW.st_gest,
					st_user=NEW.st_user,
					st_proptyp=NEW.st_proptyp,
					st_statut=NEW.st_statut,
					st_etat=NEW.st_etat,
					st_dateins=NEW.st_dateins,
					st_datemes=NEW.st_datemes,
					st_avct=NEW.st_avct,
					st_typephy=NEW.st_typephy,
					st_typelog=NEW.st_typelog,
					st_nblines=NEW.st_nblines,
					st_ad_code=NEW.st_ad_code,
					st_comment=NEW.st_comment,
					st_creadat=NEW.st_creadat,
					st_majdate=NEW.st_majdate,
					st_majsrc=NEW.st_majsrc,
					st_abddate=NEW.st_abddate,
					st_abdsrc=NEW.st_abdsrc
				WHERE st_code=OLD.st_code
				;
				UPDATE t_ltech SET 
					lt_code=NEW.lt_code,
					lt_codeext=NEW.lt_codeext,
					lt_etiquet=NEW.lt_etiquet,
					lt_st_code=NEW.lt_st_code,
					lt_prop=NEW.lt_prop,
					lt_gest=NEW.lt_gest,
					lt_user=NEW.lt_user,
					lt_proptyp=NEW.lt_proptyp,
					lt_statut=NEW.lt_statut,
					lt_etat=NEW.lt_etat,
					lt_dateins=NEW.lt_dateins,
					lt_datemes=NEW.lt_datemes,
					lt_local=NEW.lt_local,
					lt_elec=NEW.lt_elec,
					lt_clim=NEW.lt_clim,
					lt_occp=NEW.lt_occp,
					lt_idmajic=NEW.lt_idmajic,
					lt_comment=NEW.lt_comment,
					lt_creadat=NEW.lt_creadat,
					lt_majdate=NEW.lt_majdate,
					lt_majsrc=NEW.lt_majsrc,
					lt_abddate=NEW.lt_abddate,
					lt_abdsrc=NEW.lt_abdsrc
				WHERE lt_code=OLD.lt_code
				;
				UPDATE t_baie SET 
					ba_code=NEW.ba_code,
					ba_codeext=NEW.ba_codeext,
					ba_etiquet=NEW.ba_etiquet,
					ba_lt_code=NEW.ba_lt_code,
					ba_prop=NEW.ba_prop,
					ba_gest=NEW.ba_gest,
					ba_user=NEW.ba_user,
					ba_proptyp=NEW.ba_proptyp,
					ba_statut=NEW.ba_statut,
					ba_etat=NEW.ba_etat,
					ba_rf_code=NEW.ba_rf_code,
					ba_type=NEW.ba_type,
					ba_nb_u=NEW.ba_nb_u,
					ba_haut=NEW.ba_haut,
					ba_larg=NEW.ba_larg,
					ba_prof=NEW.ba_prof,
					ba_comment=NEW.ba_comment,
					ba_creadat=NEW.ba_creadat,
					ba_majdate=NEW.ba_majdate,
					ba_majsrc=NEW.ba_majsrc,
					ba_abddate=NEW.ba_abddate,
					ba_abdsrc=NEW.ba_abdsrc
				WHERE ba_code=OLD.ba_code
				;
				RETURN NEW;
			  ELSIF TG_OP = 'DELETE' THEN
				DELETE FROM t_baie WHERE ba_code=OLD.ba_code;
				DELETE FROM t_ltech WHERE lt_code=OLD.lt_code;
				DELETE FROM t_sitetech WHERE st_code=OLD.st_code;
				DELETE FROM t_noeud WHERE nd_code=OLD.nd_code;
			   RETURN NULL;
			  END IF;
			  RETURN NEW;
			END;
		$function$;

		CREATE TRIGGER tg_edit_vs_elem_ba_lt_st_nd
			INSTEAD OF INSERT OR UPDATE OR DELETE ON
			  vs_elem_ba_lt_st_nd FOR EACH ROW EXECUTE PROCEDURE fn_edit_vs_elem_ba_lt_st_nd();


		/*vs_elem_ti_ba_lt_st_nd*/
		DROP TRIGGER IF EXISTS tg_edit_vs_elem_ti_ba_lt_st_nd ON vs_elem_ti_ba_lt_st_nd CASCADE;
		DROP FUNCTION IF EXISTS fn_edit_vs_elem_ti_ba_lt_st_nd() CASCADE;

		CREATE OR REPLACE FUNCTION fn_edit_vs_elem_ti_ba_lt_st_nd()
		RETURNS TRIGGER
		LANGUAGE plpgsql
		AS $function$
		   BEGIN
			  IF TG_OP = 'INSERT' THEN
				INSERT INTO  t_noeud VALUES(
					NEW.nd_code,
					NEW.nd_codeext,
					NEW.nd_nom,
					NEW.nd_coderat,
					NEW.nd_r1_code,
					NEW.nd_r2_code,
					NEW.nd_r3_code,
					NEW.nd_r4_code,
					NEW.nd_voie,
					NEW.nd_type,
					NEW.nd_type_ep,
					NEW.nd_comment,
					NEW.nd_dtclass,
					NEW.nd_geolqlt,
					NEW.nd_geolmod,
					NEW.nd_geolsrc,
					NEW.nd_creadat,
					NEW.nd_majdate,
					NEW.nd_majsrc,
					NEW.nd_abddate,
					NEW.nd_abdsrc,
					NEW.geom
					);
				INSERT INTO  t_sitetech VALUES(
					NEW.st_code,
					NEW.st_nd_code,
					NEW.st_codeext,
					NEW.st_nom,
					NEW.st_prop,
					NEW.st_gest,
					NEW.st_user,
					NEW.st_proptyp,
					NEW.st_statut,
					NEW.st_etat,
					NEW.st_dateins,
					NEW.st_datemes,
					NEW.st_avct,
					NEW.st_typephy,
					NEW.st_typelog,
					NEW.st_nblines,
					NEW.st_ad_code,
					NEW.st_comment,
					NEW.st_creadat,
					NEW.st_majdate,
					NEW.st_majsrc,
					NEW.st_abddate,
					NEW.st_abdsrc
					);
				INSERT INTO  t_ltech VALUES(
					NEW.lt_code,
					NEW.lt_codeext,
					NEW.lt_etiquet,
					NEW.lt_st_code,
					NEW.lt_prop,
					NEW.lt_gest,
					NEW.lt_user,
					NEW.lt_proptyp,
					NEW.lt_statut,
					NEW.lt_etat,
					NEW.lt_dateins,
					NEW.lt_datemes,
					NEW.lt_local,
					NEW.lt_elec,
					NEW.lt_clim,
					NEW.lt_occp,
					NEW.lt_idmajic,
					NEW.lt_comment,
					NEW.lt_creadat,
					NEW.lt_majdate,
					NEW.lt_majsrc,
					NEW.lt_abddate,
					NEW.lt_abdsrc
					);
				INSERT INTO t_baie VALUES(
					NEW.ba_code,
					NEW.ba_codeext,
					NEW.ba_etiquet,
					NEW.ba_lt_code,
					NEW.ba_prop,
					NEW.ba_gest,
					NEW.ba_user,
					NEW.ba_proptyp,
					NEW.ba_statut,
					NEW.ba_etat,
					NEW.ba_rf_code,
					NEW.ba_type,
					NEW.ba_nb_u,
					NEW.ba_haut,
					NEW.ba_larg,
					NEW.ba_prof,
					NEW.ba_comment,
					NEW.ba_creadat,
					NEW.ba_majdate,
					NEW.ba_majsrc,
					NEW.ba_abddate,
					NEW.ba_abdsrc
					);
				INSERT INTO t_tiroir VALUES(
					NEW.ti_code,
					NEW.ti_codeext,
					NEW.ti_etiquet,
					NEW.ti_ba_code,
					NEW.ti_prop,
					NEW.ti_etat,
					NEW.ti_type,
					NEW.ti_rf_code,
					NEW.ti_taille,
					NEW.ti_placemt,
					NEW.ti_localis,
					NEW.ti_comment,
					NEW.ti_creadat,
					NEW.ti_majdate,
					NEW.ti_majsrc,
					NEW.ti_abddate,
					NEW.ti_abdsrc
					);			
				RETURN NEW;
			  ELSIF TG_OP = 'UPDATE' THEN
				UPDATE t_noeud SET 
					nd_code=NEW.nd_code,
					nd_codeext=NEW.nd_codeext,
					nd_nom=NEW.nd_nom,
					nd_coderat=NEW.nd_coderat,
					nd_r1_code=NEW.nd_r1_code,
					nd_r2_code=NEW.nd_r2_code,
					nd_r3_code=NEW.nd_r3_code,
					nd_r4_code=NEW.nd_r4_code,
					nd_voie=NEW.nd_voie,
					nd_type=NEW.nd_type,
					nd_type_ep=NEW.nd_type_ep,
					nd_comment=NEW.nd_comment,
					nd_dtclass=NEW.nd_dtclass,
					nd_geolqlt=NEW.nd_geolqlt,
					nd_geolmod=NEW.nd_geolmod,
					nd_geolsrc=NEW.nd_geolsrc,
					nd_creadat=NEW.nd_creadat,
					nd_majdate=NEW.nd_majdate,
					nd_majsrc=NEW.nd_majsrc,
					nd_abddate=NEW.nd_abddate,
					nd_abdsrc=NEW.nd_abdsrc,
					geom=NEW.geom			
				WHERE nd_code=OLD.nd_code
				;
				UPDATE t_sitetech SET 
					st_code=NEW.st_code,
					st_nd_code=NEW.st_nd_code,
					st_codeext=NEW.st_codeext,
					st_nom=NEW.st_nom,
					st_prop=NEW.st_prop,
					st_gest=NEW.st_gest,
					st_user=NEW.st_user,
					st_proptyp=NEW.st_proptyp,
					st_statut=NEW.st_statut,
					st_etat=NEW.st_etat,
					st_dateins=NEW.st_dateins,
					st_datemes=NEW.st_datemes,
					st_avct=NEW.st_avct,
					st_typephy=NEW.st_typephy,
					st_typelog=NEW.st_typelog,
					st_nblines=NEW.st_nblines,
					st_ad_code=NEW.st_ad_code,
					st_comment=NEW.st_comment,
					st_creadat=NEW.st_creadat,
					st_majdate=NEW.st_majdate,
					st_majsrc=NEW.st_majsrc,
					st_abddate=NEW.st_abddate,
					st_abdsrc=NEW.st_abdsrc
				WHERE st_code=OLD.st_code
				;
				UPDATE t_ltech SET 
					lt_code=NEW.lt_code,
					lt_codeext=NEW.lt_codeext,
					lt_etiquet=NEW.lt_etiquet,
					lt_st_code=NEW.lt_st_code,
					lt_prop=NEW.lt_prop,
					lt_gest=NEW.lt_gest,
					lt_user=NEW.lt_user,
					lt_proptyp=NEW.lt_proptyp,
					lt_statut=NEW.lt_statut,
					lt_etat=NEW.lt_etat,
					lt_dateins=NEW.lt_dateins,
					lt_datemes=NEW.lt_datemes,
					lt_local=NEW.lt_local,
					lt_elec=NEW.lt_elec,
					lt_clim=NEW.lt_clim,
					lt_occp=NEW.lt_occp,
					lt_idmajic=NEW.lt_idmajic,
					lt_comment=NEW.lt_comment,
					lt_creadat=NEW.lt_creadat,
					lt_majdate=NEW.lt_majdate,
					lt_majsrc=NEW.lt_majsrc,
					lt_abddate=NEW.lt_abddate,
					lt_abdsrc=NEW.lt_abdsrc
				WHERE lt_code=OLD.lt_code
				;
				UPDATE t_baie SET 
					ba_code=NEW.ba_code,
					ba_codeext=NEW.ba_codeext,
					ba_etiquet=NEW.ba_etiquet,
					ba_lt_code=NEW.ba_lt_code,
					ba_prop=NEW.ba_prop,
					ba_gest=NEW.ba_gest,
					ba_user=NEW.ba_user,
					ba_proptyp=NEW.ba_proptyp,
					ba_statut=NEW.ba_statut,
					ba_etat=NEW.ba_etat,
					ba_rf_code=NEW.ba_rf_code,
					ba_type=NEW.ba_type,
					ba_nb_u=NEW.ba_nb_u,
					ba_haut=NEW.ba_haut,
					ba_larg=NEW.ba_larg,
					ba_prof=NEW.ba_prof,
					ba_comment=NEW.ba_comment,
					ba_creadat=NEW.ba_creadat,
					ba_majdate=NEW.ba_majdate,
					ba_majsrc=NEW.ba_majsrc,
					ba_abddate=NEW.ba_abddate,
					ba_abdsrc=NEW.ba_abdsrc
				WHERE ba_code=OLD.ba_code
				;
				UPDATE t_tiroir SET 
					ti_code=NEW.ti_code,
					ti_codeext=NEW.ti_codeext,
					ti_etiquet=NEW.ti_etiquet,
					ti_ba_code=NEW.ti_ba_code,
					ti_prop=NEW.ti_prop,
					ti_etat=NEW.ti_etat,
					ti_type=NEW.ti_type,
					ti_rf_code=NEW.ti_rf_code,
					ti_taille=NEW.ti_taille,
					ti_placemt=NEW.ti_placemt,
					ti_localis=NEW.ti_localis,
					ti_comment=NEW.ti_comment,
					ti_creadat=NEW.ti_creadat,
					ti_majdate=NEW.ti_majdate,
					ti_majsrc=NEW.ti_majsrc,
					ti_abddate=NEW.ti_abddate,
					ti_abdsrc=NEW.ti_abdsrc
				WHERE ti_code=OLD.ti_code
				;
				RETURN NEW;
			  ELSIF TG_OP = 'DELETE' THEN
				DELETE FROM t_tiroir WHERE ti_code=OLD.ti_code;
				DELETE FROM t_baie WHERE ba_code=OLD.ba_code;
				DELETE FROM t_ltech WHERE lt_code=OLD.lt_code;
				DELETE FROM t_sitetech WHERE st_code=OLD.st_code;
				DELETE FROM t_noeud WHERE nd_code=OLD.nd_code;
			   RETURN NULL;
			  END IF;
			  RETURN NEW;
			END;
		$function$;

		CREATE TRIGGER tg_edit_vs_elem_ti_ba_lt_st_nd
			INSTEAD OF INSERT OR UPDATE OR DELETE ON
			  vs_elem_ti_ba_lt_st_nd FOR EACH ROW EXECUTE PROCEDURE fn_edit_vs_elem_ti_ba_lt_st_nd();


		/*vs_elem_eq_ba_lt_st_nd*/
		DROP TRIGGER IF EXISTS tg_edit_vs_elem_eq_ba_lt_st_nd ON vs_elem_eq_ba_lt_st_nd CASCADE;
		DROP FUNCTION IF EXISTS fn_edit_vs_elem_eq_ba_lt_st_nd() CASCADE;

		CREATE OR REPLACE FUNCTION fn_edit_vs_elem_eq_ba_lt_st_nd()
		RETURNS TRIGGER
		LANGUAGE plpgsql
		AS $function$
		   BEGIN
			  IF TG_OP = 'INSERT' THEN
				INSERT INTO  t_noeud VALUES(
					NEW.nd_code,
					NEW.nd_codeext,
					NEW.nd_nom,
					NEW.nd_coderat,
					NEW.nd_r1_code,
					NEW.nd_r2_code,
					NEW.nd_r3_code,
					NEW.nd_r4_code,
					NEW.nd_voie,
					NEW.nd_type,
					NEW.nd_type_ep,
					NEW.nd_comment,
					NEW.nd_dtclass,
					NEW.nd_geolqlt,
					NEW.nd_geolmod,
					NEW.nd_geolsrc,
					NEW.nd_creadat,
					NEW.nd_majdate,
					NEW.nd_majsrc,
					NEW.nd_abddate,
					NEW.nd_abdsrc,
					NEW.geom
					);
				INSERT INTO  t_sitetech VALUES(
					NEW.st_code,
					NEW.st_nd_code,
					NEW.st_codeext,
					NEW.st_nom,
					NEW.st_prop,
					NEW.st_gest,
					NEW.st_user,
					NEW.st_proptyp,
					NEW.st_statut,
					NEW.st_etat,
					NEW.st_dateins,
					NEW.st_datemes,
					NEW.st_avct,
					NEW.st_typephy,
					NEW.st_typelog,
					NEW.st_nblines,
					NEW.st_ad_code,
					NEW.st_comment,
					NEW.st_creadat,
					NEW.st_majdate,
					NEW.st_majsrc,
					NEW.st_abddate,
					NEW.st_abdsrc
					);
				INSERT INTO  t_ltech VALUES(
					NEW.lt_code,
					NEW.lt_codeext,
					NEW.lt_etiquet,
					NEW.lt_st_code,
					NEW.lt_prop,
					NEW.lt_gest,
					NEW.lt_user,
					NEW.lt_proptyp,
					NEW.lt_statut,
					NEW.lt_etat,
					NEW.lt_dateins,
					NEW.lt_datemes,
					NEW.lt_local,
					NEW.lt_elec,
					NEW.lt_clim,
					NEW.lt_occp,
					NEW.lt_idmajic,
					NEW.lt_comment,
					NEW.lt_creadat,
					NEW.lt_majdate,
					NEW.lt_majsrc,
					NEW.lt_abddate,
					NEW.lt_abdsrc
					);
				INSERT INTO t_baie VALUES(
					NEW.ba_code,
					NEW.ba_codeext,
					NEW.ba_etiquet,
					NEW.ba_lt_code,
					NEW.ba_prop,
					NEW.ba_gest,
					NEW.ba_user,
					NEW.ba_proptyp,
					NEW.ba_statut,
					NEW.ba_etat,
					NEW.ba_rf_code,
					NEW.ba_type,
					NEW.ba_nb_u,
					NEW.ba_haut,
					NEW.ba_larg,
					NEW.ba_prof,
					NEW.ba_comment,
					NEW.ba_creadat,
					NEW.ba_majdate,
					NEW.ba_majsrc,
					NEW.ba_abddate,
					NEW.ba_abdsrc
					);
				INSERT INTO t_equipement VALUES(
					NEW.eq_code,
					NEW.eq_codeext,
					NEW.eq_etiquet,
					NEW.eq_ba_code,
					NEW.eq_prop,
					NEW.eq_rf_code,
					NEW.eq_dateins,
					NEW.eq_datemes,
					NEW.eq_comment,
					NEW.eq_creadat,
					NEW.eq_majdate,
					NEW.eq_majsrc,
					NEW.eq_abddate,
					NEW.eq_abdsrc
					);			
				RETURN NEW;
			  ELSIF TG_OP = 'UPDATE' THEN
				UPDATE t_noeud SET 
					nd_code=NEW.nd_code,
					nd_codeext=NEW.nd_codeext,
					nd_nom=NEW.nd_nom,
					nd_coderat=NEW.nd_coderat,
					nd_r1_code=NEW.nd_r1_code,
					nd_r2_code=NEW.nd_r2_code,
					nd_r3_code=NEW.nd_r3_code,
					nd_r4_code=NEW.nd_r4_code,
					nd_voie=NEW.nd_voie,
					nd_type=NEW.nd_type,
					nd_type_ep=NEW.nd_type_ep,
					nd_comment=NEW.nd_comment,
					nd_dtclass=NEW.nd_dtclass,
					nd_geolqlt=NEW.nd_geolqlt,
					nd_geolmod=NEW.nd_geolmod,
					nd_geolsrc=NEW.nd_geolsrc,
					nd_creadat=NEW.nd_creadat,
					nd_majdate=NEW.nd_majdate,
					nd_majsrc=NEW.nd_majsrc,
					nd_abddate=NEW.nd_abddate,
					nd_abdsrc=NEW.nd_abdsrc,
					geom=NEW.geom			
				WHERE nd_code=OLD.nd_code
				;
				UPDATE t_sitetech SET 
					st_code=NEW.st_code,
					st_nd_code=NEW.st_nd_code,
					st_codeext=NEW.st_codeext,
					st_nom=NEW.st_nom,
					st_prop=NEW.st_prop,
					st_gest=NEW.st_gest,
					st_user=NEW.st_user,
					st_proptyp=NEW.st_proptyp,
					st_statut=NEW.st_statut,
					st_etat=NEW.st_etat,
					st_dateins=NEW.st_dateins,
					st_datemes=NEW.st_datemes,
					st_avct=NEW.st_avct,
					st_typephy=NEW.st_typephy,
					st_typelog=NEW.st_typelog,
					st_nblines=NEW.st_nblines,
					st_ad_code=NEW.st_ad_code,
					st_comment=NEW.st_comment,
					st_creadat=NEW.st_creadat,
					st_majdate=NEW.st_majdate,
					st_majsrc=NEW.st_majsrc,
					st_abddate=NEW.st_abddate,
					st_abdsrc=NEW.st_abdsrc
				WHERE st_code=OLD.st_code
				;
				UPDATE t_ltech SET 
					lt_code=NEW.lt_code,
					lt_codeext=NEW.lt_codeext,
					lt_etiquet=NEW.lt_etiquet,
					lt_st_code=NEW.lt_st_code,
					lt_prop=NEW.lt_prop,
					lt_gest=NEW.lt_gest,
					lt_user=NEW.lt_user,
					lt_proptyp=NEW.lt_proptyp,
					lt_statut=NEW.lt_statut,
					lt_etat=NEW.lt_etat,
					lt_dateins=NEW.lt_dateins,
					lt_datemes=NEW.lt_datemes,
					lt_local=NEW.lt_local,
					lt_elec=NEW.lt_elec,
					lt_clim=NEW.lt_clim,
					lt_occp=NEW.lt_occp,
					lt_idmajic=NEW.lt_idmajic,
					lt_comment=NEW.lt_comment,
					lt_creadat=NEW.lt_creadat,
					lt_majdate=NEW.lt_majdate,
					lt_majsrc=NEW.lt_majsrc,
					lt_abddate=NEW.lt_abddate,
					lt_abdsrc=NEW.lt_abdsrc
				WHERE lt_code=OLD.lt_code
				;
				UPDATE t_baie SET 
					ba_code=NEW.ba_code,
					ba_codeext=NEW.ba_codeext,
					ba_etiquet=NEW.ba_etiquet,
					ba_lt_code=NEW.ba_lt_code,
					ba_prop=NEW.ba_prop,
					ba_gest=NEW.ba_gest,
					ba_user=NEW.ba_user,
					ba_proptyp=NEW.ba_proptyp,
					ba_statut=NEW.ba_statut,
					ba_etat=NEW.ba_etat,
					ba_rf_code=NEW.ba_rf_code,
					ba_type=NEW.ba_type,
					ba_nb_u=NEW.ba_nb_u,
					ba_haut=NEW.ba_haut,
					ba_larg=NEW.ba_larg,
					ba_prof=NEW.ba_prof,
					ba_comment=NEW.ba_comment,
					ba_creadat=NEW.ba_creadat,
					ba_majdate=NEW.ba_majdate,
					ba_majsrc=NEW.ba_majsrc,
					ba_abddate=NEW.ba_abddate,
					ba_abdsrc=NEW.ba_abdsrc
				WHERE ba_code=OLD.ba_code
				;
				UPDATE t_equipement SET 
					eq_code=NEW.eq_code,
					eq_codeext=NEW.eq_codeext,
					eq_etiquet=NEW.eq_etiquet,
					eq_ba_code=NEW.eq_ba_code,
					eq_prop=NEW.eq_prop,
					eq_rf_code=NEW.eq_rf_code,
					eq_dateins=NEW.eq_dateins,
					eq_datemes=NEW.eq_datemes,
					eq_comment=NEW.eq_comment,
					eq_creadat=NEW.eq_creadat,
					eq_majdate=NEW.eq_majdate,
					eq_majsrc=NEW.eq_majsrc,
					eq_abddate=NEW.eq_abddate,
					eq_abdsrc=NEW.eq_abdsrc
				WHERE eq_code=OLD.eq_code
				;
				RETURN NEW;
			  ELSIF TG_OP = 'DELETE' THEN
				DELETE FROM t_equipement WHERE eq_code=OLD.eq_code;
				DELETE FROM t_baie WHERE ba_code=OLD.ba_code;
				DELETE FROM t_ltech WHERE lt_code=OLD.lt_code;
				DELETE FROM t_sitetech WHERE st_code=OLD.st_code;
				DELETE FROM t_noeud WHERE nd_code=OLD.nd_code;
			   RETURN NULL;
			  END IF;
			  RETURN NEW;
			END;
		$function$;

		CREATE TRIGGER tg_edit_vs_elem_eq_ba_lt_st_nd
			INSTEAD OF INSERT OR UPDATE OR DELETE ON
			  vs_elem_eq_ba_lt_st_nd FOR EACH ROW EXECUTE PROCEDURE fn_edit_vs_elem_eq_ba_lt_st_nd();

			  
		/*vs_elem_pt_nd*/
		DROP TRIGGER IF EXISTS tg_edit_vs_elem_pt_nd ON vs_elem_pt_nd CASCADE;
		DROP FUNCTION IF EXISTS fn_edit_vs_elem_pt_nd() CASCADE;

		CREATE OR REPLACE FUNCTION fn_edit_vs_elem_pt_nd()
		RETURNS TRIGGER
		LANGUAGE plpgsql
		AS $function$
		   BEGIN
			  IF TG_OP = 'INSERT' THEN
				INSERT INTO  t_noeud VALUES(
					NEW.nd_code,
					NEW.nd_codeext,
					NEW.nd_nom,
					NEW.nd_coderat,
					NEW.nd_r1_code,
					NEW.nd_r2_code,
					NEW.nd_r3_code,
					NEW.nd_r4_code,
					NEW.nd_voie,
					NEW.nd_type,
					NEW.nd_type_ep,
					NEW.nd_comment,
					NEW.nd_dtclass,
					NEW.nd_geolqlt,
					NEW.nd_geolmod,
					NEW.nd_geolsrc,
					NEW.nd_creadat,
					NEW.nd_majdate,
					NEW.nd_majsrc,
					NEW.nd_abddate,
					NEW.nd_abdsrc,
					NEW.geom
					);
				INSERT INTO  t_ptech VALUES(
					NEW.pt_code,
					NEW.pt_codeext,
					NEW.pt_etiquet,
					NEW.pt_nd_code,
					NEW.pt_ad_code,
					NEW.pt_gest_do,
					NEW.pt_prop_do,
					NEW.pt_prop,
					NEW.pt_gest,
					NEW.pt_user,
					NEW.pt_proptyp,
					NEW.pt_statut,
					NEW.pt_etat,
					NEW.pt_dateins,
					NEW.pt_datemes,
					NEW.pt_avct,
					NEW.pt_typephy,
					NEW.pt_typelog,
					NEW.pt_rf_code,
					NEW.pt_nature,
					NEW.pt_secu,
					NEW.pt_occp,
					NEW.pt_a_dan,
					NEW.pt_a_dtetu,
					NEW.pt_a_struc,
					NEW.pt_a_haut,
					NEW.pt_a_passa,
					NEW.pt_a_strat,
					NEW.pt_rotatio,
					NEW.pt_detec,
					NEW.pt_comment,
					NEW.pt_creadat,
					NEW.pt_majdate,
					NEW.pt_majsrc,
					NEW.pt_abddate,
					NEW.pt_abdsrc
					);
				RETURN NEW;
			  ELSIF TG_OP = 'UPDATE' THEN
				UPDATE t_noeud SET 
					nd_code=NEW.nd_code,
					nd_codeext=NEW.nd_codeext,
					nd_nom=NEW.nd_nom,
					nd_coderat=NEW.nd_coderat,
					nd_r1_code=NEW.nd_r1_code,
					nd_r2_code=NEW.nd_r2_code,
					nd_r3_code=NEW.nd_r3_code,
					nd_r4_code=NEW.nd_r4_code,
					nd_voie=NEW.nd_voie,
					nd_type=NEW.nd_type,
					nd_type_ep=NEW.nd_type_ep,
					nd_comment=NEW.nd_comment,
					nd_dtclass=NEW.nd_dtclass,
					nd_geolqlt=NEW.nd_geolqlt,
					nd_geolmod=NEW.nd_geolmod,
					nd_geolsrc=NEW.nd_geolsrc,
					nd_creadat=NEW.nd_creadat,
					nd_majdate=NEW.nd_majdate,
					nd_majsrc=NEW.nd_majsrc,
					nd_abddate=NEW.nd_abddate,
					nd_abdsrc=NEW.nd_abdsrc,
					geom=NEW.geom			
				WHERE nd_code=OLD.nd_code
				;
				UPDATE t_ptech SET 
					pt_code=NEW.pt_code,
					pt_codeext=NEW.pt_codeext,
					pt_etiquet=NEW.pt_etiquet,
					pt_nd_code=NEW.pt_nd_code,
					pt_ad_code=NEW.pt_ad_code,
					pt_gest_do=NEW.pt_gest_do,
					pt_prop_do=NEW.pt_prop_do,
					pt_prop=NEW.pt_prop,
					pt_gest=NEW.pt_gest,
					pt_user=NEW.pt_user,
					pt_proptyp=NEW.pt_proptyp,
					pt_statut=NEW.pt_statut,
					pt_etat=NEW.pt_etat,
					pt_dateins=NEW.pt_dateins,
					pt_datemes=NEW.pt_datemes,
					pt_avct=NEW.pt_avct,
					pt_typephy=NEW.pt_typephy,
					pt_typelog=NEW.pt_typelog,
					pt_rf_code=NEW.pt_rf_code,
					pt_nature=NEW.pt_nature,
					pt_secu=NEW.pt_secu,
					pt_occp=NEW.pt_occp,
					pt_a_dan=NEW.pt_a_dan,
					pt_a_dtetu=NEW.pt_a_dtetu,
					pt_a_struc=NEW.pt_a_struc,
					pt_a_haut=NEW.pt_a_haut,
					pt_a_passa=NEW.pt_a_passa,
					pt_a_strat=NEW.pt_a_strat,
					pt_rotatio=NEW.pt_rotatio,
					pt_detec=NEW.pt_detec,
					pt_comment=NEW.pt_comment,
					pt_creadat=NEW.pt_creadat,
					pt_majdate=NEW.pt_majdate,
					pt_majsrc=NEW.pt_majsrc,
					pt_abddate=NEW.pt_abddate,
					pt_abdsrc=NEW.pt_abdsrc
				WHERE pt_code=OLD.pt_code
				;
				RETURN NEW;
			  ELSIF TG_OP = 'DELETE' THEN
				/*INVERSER ?*/
				DELETE FROM t_ptech WHERE pt_code=OLD.pt_code;
				DELETE FROM t_noeud WHERE nd_code=OLD.nd_code;
			   RETURN NULL;
			  END IF;
			  RETURN NEW;
			END;
		$function$;

		CREATE TRIGGER tg_edit_vs_elem_pt_nd
			INSTEAD OF INSERT OR UPDATE OR DELETE ON
			  vs_elem_pt_nd FOR EACH ROW EXECUTE PROCEDURE fn_edit_vs_elem_pt_nd();
			  

		/*vs_elem_bp_pt_nd*/
		DROP TRIGGER IF EXISTS tg_edit_vs_elem_bp_pt_nd ON vs_elem_bp_pt_nd CASCADE;
		DROP FUNCTION IF EXISTS fn_edit_vs_elem_bp_pt_nd() CASCADE;

		CREATE OR REPLACE FUNCTION fn_edit_vs_elem_bp_pt_nd()
		RETURNS TRIGGER
		LANGUAGE plpgsql
		AS $function$
		   BEGIN
			  IF TG_OP = 'INSERT' THEN
				INSERT INTO  t_noeud VALUES(
					NEW.nd_code,
					NEW.nd_codeext,
					NEW.nd_nom,
					NEW.nd_coderat,
					NEW.nd_r1_code,
					NEW.nd_r2_code,
					NEW.nd_r3_code,
					NEW.nd_r4_code,
					NEW.nd_voie,
					NEW.nd_type,
					NEW.nd_type_ep,
					NEW.nd_comment,
					NEW.nd_dtclass,
					NEW.nd_geolqlt,
					NEW.nd_geolmod,
					NEW.nd_geolsrc,
					NEW.nd_creadat,
					NEW.nd_majdate,
					NEW.nd_majsrc,
					NEW.nd_abddate,
					NEW.nd_abdsrc,
					NEW.geom
					);
				INSERT INTO  t_ptech VALUES(
					NEW.pt_code,
					NEW.pt_codeext,
					NEW.pt_etiquet,
					NEW.pt_nd_code,
					NEW.pt_ad_code,
					NEW.pt_gest_do,
					NEW.pt_prop_do,
					NEW.pt_prop,
					NEW.pt_gest,
					NEW.pt_user,
					NEW.pt_proptyp,
					NEW.pt_statut,
					NEW.pt_etat,
					NEW.pt_dateins,
					NEW.pt_datemes,
					NEW.pt_avct,
					NEW.pt_typephy,
					NEW.pt_typelog,
					NEW.pt_rf_code,
					NEW.pt_nature,
					NEW.pt_secu,
					NEW.pt_occp,
					NEW.pt_a_dan,
					NEW.pt_a_dtetu,
					NEW.pt_a_struc,
					NEW.pt_a_haut,
					NEW.pt_a_passa,
					NEW.pt_a_strat,
					NEW.pt_rotatio,
					NEW.pt_detec,
					NEW.pt_comment,
					NEW.pt_creadat,
					NEW.pt_majdate,
					NEW.pt_majsrc,
					NEW.pt_abddate,
					NEW.pt_abdsrc
					);
				INSERT INTO  t_ebp VALUES(			
					NEW.bp_code,
					NEW.bp_etiquet,
					NEW.bp_codeext,
					NEW.bp_pt_code,
					NEW.bp_lt_code,
					NEW.bp_sf_code,
					NEW.bp_prop,
					NEW.bp_gest,
					NEW.bp_user,
					NEW.bp_proptyp,
					NEW.bp_statut,
					NEW.bp_etat,
					NEW.bp_occp,
					NEW.bp_datemes,
					NEW.bp_avct,
					NEW.bp_typephy,
					NEW.bp_typelog,
					NEW.bp_rf_code,
					NEW.bp_entrees,
					NEW.bp_ref_kit,
					NEW.bp_ca_nb,
					NEW.bp_nb_pas,
					NEW.bp_linecod,
					NEW.bp_oc_code,
					NEW.bp_racco,
					NEW.bp_comment,
					NEW.bp_creadat,
					NEW.bp_majdate,
					NEW.bp_majsrc,
					NEW.bp_abddate,
					NEW.bp_abdsrc
					);
				RETURN NEW;
			  ELSIF TG_OP = 'UPDATE' THEN
				UPDATE t_noeud SET 
					nd_code=NEW.nd_code,
					nd_codeext=NEW.nd_codeext,
					nd_nom=NEW.nd_nom,
					nd_coderat=NEW.nd_coderat,
					nd_r1_code=NEW.nd_r1_code,
					nd_r2_code=NEW.nd_r2_code,
					nd_r3_code=NEW.nd_r3_code,
					nd_r4_code=NEW.nd_r4_code,
					nd_voie=NEW.nd_voie,
					nd_type=NEW.nd_type,
					nd_type_ep=NEW.nd_type_ep,
					nd_comment=NEW.nd_comment,
					nd_dtclass=NEW.nd_dtclass,
					nd_geolqlt=NEW.nd_geolqlt,
					nd_geolmod=NEW.nd_geolmod,
					nd_geolsrc=NEW.nd_geolsrc,
					nd_creadat=NEW.nd_creadat,
					nd_majdate=NEW.nd_majdate,
					nd_majsrc=NEW.nd_majsrc,
					nd_abddate=NEW.nd_abddate,
					nd_abdsrc=NEW.nd_abdsrc,
					geom=NEW.geom			
				WHERE nd_code=OLD.nd_code
				;
				UPDATE t_ptech SET 
					pt_code=NEW.pt_code,
					pt_codeext=NEW.pt_codeext,
					pt_etiquet=NEW.pt_etiquet,
					pt_nd_code=NEW.pt_nd_code,
					pt_ad_code=NEW.pt_ad_code,
					pt_gest_do=NEW.pt_gest_do,
					pt_prop_do=NEW.pt_prop_do,
					pt_prop=NEW.pt_prop,
					pt_gest=NEW.pt_gest,
					pt_user=NEW.pt_user,
					pt_proptyp=NEW.pt_proptyp,
					pt_statut=NEW.pt_statut,
					pt_etat=NEW.pt_etat,
					pt_dateins=NEW.pt_dateins,
					pt_datemes=NEW.pt_datemes,
					pt_avct=NEW.pt_avct,
					pt_typephy=NEW.pt_typephy,
					pt_typelog=NEW.pt_typelog,
					pt_rf_code=NEW.pt_rf_code,
					pt_nature=NEW.pt_nature,
					pt_secu=NEW.pt_secu,
					pt_occp=NEW.pt_occp,
					pt_a_dan=NEW.pt_a_dan,
					pt_a_dtetu=NEW.pt_a_dtetu,
					pt_a_struc=NEW.pt_a_struc,
					pt_a_haut=NEW.pt_a_haut,
					pt_a_passa=NEW.pt_a_passa,
					pt_a_strat=NEW.pt_a_strat,
					pt_rotatio=NEW.pt_rotatio,
					pt_detec=NEW.pt_detec,
					pt_comment=NEW.pt_comment,
					pt_creadat=NEW.pt_creadat,
					pt_majdate=NEW.pt_majdate,
					pt_majsrc=NEW.pt_majsrc,
					pt_abddate=NEW.pt_abddate,
					pt_abdsrc=NEW.pt_abdsrc
				WHERE pt_code=OLD.pt_code
				;
				UPDATE t_ebp SET 
					bp_code=NEW.bp_code,
					bp_etiquet=NEW.bp_etiquet,
					bp_codeext=NEW.bp_codeext,
					bp_pt_code=NEW.bp_pt_code,
					bp_lt_code=NEW.bp_lt_code,
					bp_sf_code=NEW.bp_sf_code,
					bp_prop=NEW.bp_prop,
					bp_gest=NEW.bp_gest,
					bp_user=NEW.bp_user,
					bp_proptyp=NEW.bp_proptyp,
					bp_statut=NEW.bp_statut,
					bp_etat=NEW.bp_etat,
					bp_occp=NEW.bp_occp,
					bp_datemes=NEW.bp_datemes,
					bp_avct=NEW.bp_avct,
					bp_typephy=NEW.bp_typephy,
					bp_typelog=NEW.bp_typelog,
					bp_rf_code=NEW.bp_rf_code,
					bp_entrees=NEW.bp_entrees,
					bp_ref_kit=NEW.bp_ref_kit,
					bp_ca_nb=NEW.bp_ca_nb,
					bp_nb_pas=NEW.bp_nb_pas,
					bp_linecod=NEW.bp_linecod,
					bp_oc_code=NEW.bp_oc_code,
					bp_racco=NEW.bp_racco,
					bp_comment=NEW.bp_comment,
					bp_creadat=NEW.bp_creadat,
					bp_majdate=NEW.bp_majdate,
					bp_majsrc=NEW.bp_majsrc,
					bp_abddate=NEW.bp_abddate,
					bp_abdsrc=NEW.bp_abdsrc
				WHERE bp_code=OLD.bp_code
				;

				RETURN NEW;
			  ELSIF TG_OP = 'DELETE' THEN
				/*INVERSER ?*/
				DELETE FROM t_ebp WHERE bp_code=OLD.bp_code;
				DELETE FROM t_ptech WHERE pt_code=OLD.pt_code;
				DELETE FROM t_noeud WHERE nd_code=OLD.nd_code;
			   RETURN NULL;
			  END IF;
			  RETURN NEW;
			END;
		$function$;

		CREATE TRIGGER tg_edit_vs_elem_bp_pt_nd
			INSTEAD OF INSERT OR UPDATE OR DELETE ON
			  vs_elem_bp_pt_nd FOR EACH ROW EXECUTE PROCEDURE fn_edit_vs_elem_bp_pt_nd();

		/*vs_elem_cs_bp_pt_nd*/
		DROP TRIGGER IF EXISTS tg_edit_vs_elem_cs_bp_pt_nd ON vs_elem_cs_bp_pt_nd CASCADE;
		DROP FUNCTION IF EXISTS fn_edit_vs_elem_cs_bp_pt_nd() CASCADE;

		CREATE OR REPLACE FUNCTION fn_edit_vs_elem_cs_bp_pt_nd()
		RETURNS TRIGGER
		LANGUAGE plpgsql
		AS $function$
		   BEGIN
			  IF TG_OP = 'INSERT' THEN
				INSERT INTO  t_noeud VALUES(
					NEW.nd_code,
					NEW.nd_codeext,
					NEW.nd_nom,
					NEW.nd_coderat,
					NEW.nd_r1_code,
					NEW.nd_r2_code,
					NEW.nd_r3_code,
					NEW.nd_r4_code,
					NEW.nd_voie,
					NEW.nd_type,
					NEW.nd_type_ep,
					NEW.nd_comment,
					NEW.nd_dtclass,
					NEW.nd_geolqlt,
					NEW.nd_geolmod,
					NEW.nd_geolsrc,
					NEW.nd_creadat,
					NEW.nd_majdate,
					NEW.nd_majsrc,
					NEW.nd_abddate,
					NEW.nd_abdsrc,
					NEW.geom
					);
				INSERT INTO  t_ptech VALUES(
					NEW.pt_code,
					NEW.pt_codeext,
					NEW.pt_etiquet,
					NEW.pt_nd_code,
					NEW.pt_ad_code,
					NEW.pt_gest_do,
					NEW.pt_prop_do,
					NEW.pt_prop,
					NEW.pt_gest,
					NEW.pt_user,
					NEW.pt_proptyp,
					NEW.pt_statut,
					NEW.pt_etat,
					NEW.pt_dateins,
					NEW.pt_datemes,
					NEW.pt_avct,
					NEW.pt_typephy,
					NEW.pt_typelog,
					NEW.pt_rf_code,
					NEW.pt_nature,
					NEW.pt_secu,
					NEW.pt_occp,
					NEW.pt_a_dan,
					NEW.pt_a_dtetu,
					NEW.pt_a_struc,
					NEW.pt_a_haut,
					NEW.pt_a_passa,
					NEW.pt_a_strat,
					NEW.pt_rotatio,
					NEW.pt_detec,
					NEW.pt_comment,
					NEW.pt_creadat,
					NEW.pt_majdate,
					NEW.pt_majsrc,
					NEW.pt_abddate,
					NEW.pt_abdsrc
					);
				INSERT INTO  t_ebp VALUES(			
					NEW.bp_code,
					NEW.bp_etiquet,
					NEW.bp_codeext,
					NEW.bp_pt_code,
					NEW.bp_lt_code,
					NEW.bp_sf_code,
					NEW.bp_prop,
					NEW.bp_gest,
					NEW.bp_user,
					NEW.bp_proptyp,
					NEW.bp_statut,
					NEW.bp_etat,
					NEW.bp_occp,
					NEW.bp_datemes,
					NEW.bp_avct,
					NEW.bp_typephy,
					NEW.bp_typelog,
					NEW.bp_rf_code,
					NEW.bp_entrees,
					NEW.bp_ref_kit,
					NEW.bp_ca_nb,
					NEW.bp_nb_pas,
					NEW.bp_linecod,
					NEW.bp_oc_code,
					NEW.bp_racco,
					NEW.bp_comment,
					NEW.bp_creadat,
					NEW.bp_majdate,
					NEW.bp_majsrc,
					NEW.bp_abddate,
					NEW.bp_abdsrc
					);
				INSERT INTO t_cassette VALUES(			
					NEW.cs_code,
					NEW.cs_nb_pas,
					NEW.cs_bp_code,
					NEW.cs_num,
					NEW.cs_type,
					NEW.cs_face,
					NEW.cs_rf_code,
					NEW.cs_comment,
					NEW.cs_creadat,
					NEW.cs_majdate,
					NEW.cs_majsrc,
					NEW.cs_abddate,
					NEW.cs_abdsrc
					);
				RETURN NEW;
			  ELSIF TG_OP = 'UPDATE' THEN
				UPDATE t_noeud SET 
					nd_code=NEW.nd_code,
					nd_codeext=NEW.nd_codeext,
					nd_nom=NEW.nd_nom,
					nd_coderat=NEW.nd_coderat,
					nd_r1_code=NEW.nd_r1_code,
					nd_r2_code=NEW.nd_r2_code,
					nd_r3_code=NEW.nd_r3_code,
					nd_r4_code=NEW.nd_r4_code,
					nd_voie=NEW.nd_voie,
					nd_type=NEW.nd_type,
					nd_type_ep=NEW.nd_type_ep,
					nd_comment=NEW.nd_comment,
					nd_dtclass=NEW.nd_dtclass,
					nd_geolqlt=NEW.nd_geolqlt,
					nd_geolmod=NEW.nd_geolmod,
					nd_geolsrc=NEW.nd_geolsrc,
					nd_creadat=NEW.nd_creadat,
					nd_majdate=NEW.nd_majdate,
					nd_majsrc=NEW.nd_majsrc,
					nd_abddate=NEW.nd_abddate,
					nd_abdsrc=NEW.nd_abdsrc,
					geom=NEW.geom			
				WHERE nd_code=OLD.nd_code
				;
				UPDATE t_ptech SET 
					pt_code=NEW.pt_code,
					pt_codeext=NEW.pt_codeext,
					pt_etiquet=NEW.pt_etiquet,
					pt_nd_code=NEW.pt_nd_code,
					pt_ad_code=NEW.pt_ad_code,
					pt_gest_do=NEW.pt_gest_do,
					pt_prop_do=NEW.pt_prop_do,
					pt_prop=NEW.pt_prop,
					pt_gest=NEW.pt_gest,
					pt_user=NEW.pt_user,
					pt_proptyp=NEW.pt_proptyp,
					pt_statut=NEW.pt_statut,
					pt_etat=NEW.pt_etat,
					pt_dateins=NEW.pt_dateins,
					pt_datemes=NEW.pt_datemes,
					pt_avct=NEW.pt_avct,
					pt_typephy=NEW.pt_typephy,
					pt_typelog=NEW.pt_typelog,
					pt_rf_code=NEW.pt_rf_code,
					pt_nature=NEW.pt_nature,
					pt_secu=NEW.pt_secu,
					pt_occp=NEW.pt_occp,
					pt_a_dan=NEW.pt_a_dan,
					pt_a_dtetu=NEW.pt_a_dtetu,
					pt_a_struc=NEW.pt_a_struc,
					pt_a_haut=NEW.pt_a_haut,
					pt_a_passa=NEW.pt_a_passa,
					pt_a_strat=NEW.pt_a_strat,
					pt_rotatio=NEW.pt_rotatio,
					pt_detec=NEW.pt_detec,
					pt_comment=NEW.pt_comment,
					pt_creadat=NEW.pt_creadat,
					pt_majdate=NEW.pt_majdate,
					pt_majsrc=NEW.pt_majsrc,
					pt_abddate=NEW.pt_abddate,
					pt_abdsrc=NEW.pt_abdsrc
				WHERE pt_code=OLD.pt_code
				;
				UPDATE t_ebp SET 
					bp_code=NEW.bp_code,
					bp_etiquet=NEW.bp_etiquet,
					bp_codeext=NEW.bp_codeext,
					bp_pt_code=NEW.bp_pt_code,
					bp_lt_code=NEW.bp_lt_code,
					bp_sf_code=NEW.bp_sf_code,
					bp_prop=NEW.bp_prop,
					bp_gest=NEW.bp_gest,
					bp_user=NEW.bp_user,
					bp_proptyp=NEW.bp_proptyp,
					bp_statut=NEW.bp_statut,
					bp_etat=NEW.bp_etat,
					bp_occp=NEW.bp_occp,
					bp_datemes=NEW.bp_datemes,
					bp_avct=NEW.bp_avct,
					bp_typephy=NEW.bp_typephy,
					bp_typelog=NEW.bp_typelog,
					bp_rf_code=NEW.bp_rf_code,
					bp_entrees=NEW.bp_entrees,
					bp_ref_kit=NEW.bp_ref_kit,
					bp_ca_nb=NEW.bp_ca_nb,
					bp_nb_pas=NEW.bp_nb_pas,
					bp_linecod=NEW.bp_linecod,
					bp_oc_code=NEW.bp_oc_code,
					bp_racco=NEW.bp_racco,
					bp_comment=NEW.bp_comment,
					bp_creadat=NEW.bp_creadat,
					bp_majdate=NEW.bp_majdate,
					bp_majsrc=NEW.bp_majsrc,
					bp_abddate=NEW.bp_abddate,
					bp_abdsrc=NEW.bp_abdsrc
				WHERE bp_code=OLD.bp_code
				;
				UPDATE t_cassette SET 
					cs_code=NEW.cs_code,
					cs_nb_pas=NEW.cs_nb_pas,
					cs_bp_code=NEW.cs_bp_code,
					cs_num=NEW.cs_num,
					cs_type=NEW.cs_type,
					cs_face=NEW.cs_face,
					cs_rf_code=NEW.cs_rf_code,
					cs_comment=NEW.cs_comment,
					cs_creadat=NEW.cs_creadat,
					cs_majdate=NEW.cs_majdate,
					cs_majsrc=NEW.cs_majsrc,
					cs_abddate=NEW.cs_abddate,
					cs_abdsrc=NEW.cs_abdsrc
				WHERE cs_code=OLD.cs_code
				;
				RETURN NEW;
			  ELSIF TG_OP = 'DELETE' THEN
				DELETE FROM t_cassette WHERE cs_code=OLD.cs_code;
				DELETE FROM t_ebp WHERE bp_code=OLD.bp_code;
				DELETE FROM t_ptech WHERE pt_code=OLD.pt_code;
				DELETE FROM t_noeud WHERE nd_code=OLD.nd_code;
			   RETURN NULL;
			  END IF;
			  RETURN NEW;
			END;
		$function$;

		CREATE TRIGGER tg_edit_vs_elem_cs_bp_pt_nd
			INSTEAD OF INSERT OR UPDATE OR DELETE ON
			  vs_elem_cs_bp_pt_nd FOR EACH ROW EXECUTE PROCEDURE fn_edit_vs_elem_cs_bp_pt_nd();
			  
		/*vs_elem_cs_bp_lt_st_nd*/
		DROP TRIGGER IF EXISTS tg_edit_vs_elem_cs_bp_lt_st_nd ON vs_elem_cs_bp_lt_st_nd CASCADE;
		DROP FUNCTION IF EXISTS fn_edit_vs_elem_cs_bp_lt_st_nd() CASCADE;

		CREATE OR REPLACE FUNCTION fn_edit_vs_elem_cs_bp_lt_st_nd()
		RETURNS TRIGGER
		LANGUAGE plpgsql
		AS $function$
		   BEGIN
			  IF TG_OP = 'INSERT' THEN
				INSERT INTO  t_noeud VALUES(
					NEW.nd_code,
					NEW.nd_codeext,
					NEW.nd_nom,
					NEW.nd_coderat,
					NEW.nd_r1_code,
					NEW.nd_r2_code,
					NEW.nd_r3_code,
					NEW.nd_r4_code,
					NEW.nd_voie,
					NEW.nd_type,
					NEW.nd_type_ep,
					NEW.nd_comment,
					NEW.nd_dtclass,
					NEW.nd_geolqlt,
					NEW.nd_geolmod,
					NEW.nd_geolsrc,
					NEW.nd_creadat,
					NEW.nd_majdate,
					NEW.nd_majsrc,
					NEW.nd_abddate,
					NEW.nd_abdsrc,
					NEW.geom
					);
				INSERT INTO  t_sitetech VALUES(
					NEW.st_code,
					NEW.st_nd_code,
					NEW.st_codeext,
					NEW.st_nom,
					NEW.st_prop,
					NEW.st_gest,
					NEW.st_user,
					NEW.st_proptyp,
					NEW.st_statut,
					NEW.st_etat,
					NEW.st_dateins,
					NEW.st_datemes,
					NEW.st_avct,
					NEW.st_typephy,
					NEW.st_typelog,
					NEW.st_nblines,
					NEW.st_ad_code,
					NEW.st_comment,
					NEW.st_creadat,
					NEW.st_majdate,
					NEW.st_majsrc,
					NEW.st_abddate,
					NEW.st_abdsrc
					);
				INSERT INTO  t_ltech VALUES(
					NEW.lt_code,
					NEW.lt_codeext,
					NEW.lt_etiquet,
					NEW.lt_st_code,
					NEW.lt_prop,
					NEW.lt_gest,
					NEW.lt_user,
					NEW.lt_proptyp,
					NEW.lt_statut,
					NEW.lt_etat,
					NEW.lt_dateins,
					NEW.lt_datemes,
					NEW.lt_local,
					NEW.lt_elec,
					NEW.lt_clim,
					NEW.lt_occp,
					NEW.lt_idmajic,
					NEW.lt_comment,
					NEW.lt_creadat,
					NEW.lt_majdate,
					NEW.lt_majsrc,
					NEW.lt_abddate,
					NEW.lt_abdsrc
					);
				INSERT INTO  t_ebp VALUES(			
					NEW.bp_code,
					NEW.bp_etiquet,
					NEW.bp_codeext,
					NEW.bp_pt_code,
					NEW.bp_lt_code,
					NEW.bp_sf_code,
					NEW.bp_prop,
					NEW.bp_gest,
					NEW.bp_user,
					NEW.bp_proptyp,
					NEW.bp_statut,
					NEW.bp_etat,
					NEW.bp_occp,
					NEW.bp_datemes,
					NEW.bp_avct,
					NEW.bp_typephy,
					NEW.bp_typelog,
					NEW.bp_rf_code,
					NEW.bp_entrees,
					NEW.bp_ref_kit,
					NEW.bp_ca_nb,
					NEW.bp_nb_pas,
					NEW.bp_linecod,
					NEW.bp_oc_code,
					NEW.bp_racco,
					NEW.bp_comment,
					NEW.bp_creadat,
					NEW.bp_majdate,
					NEW.bp_majsrc,
					NEW.bp_abddate,
					NEW.bp_abdsrc
					);
				INSERT INTO t_cassette VALUES(			
					NEW.cs_code,
					NEW.cs_nb_pas,
					NEW.cs_bp_code,
					NEW.cs_num,
					NEW.cs_type,
					NEW.cs_face,
					NEW.cs_rf_code,
					NEW.cs_comment,
					NEW.cs_creadat,
					NEW.cs_majdate,
					NEW.cs_majsrc,
					NEW.cs_abddate,
					NEW.cs_abdsrc
					);
				RETURN NEW;
			  ELSIF TG_OP = 'UPDATE' THEN
				UPDATE t_noeud SET 
					nd_code=NEW.nd_code,
					nd_codeext=NEW.nd_codeext,
					nd_nom=NEW.nd_nom,
					nd_coderat=NEW.nd_coderat,
					nd_r1_code=NEW.nd_r1_code,
					nd_r2_code=NEW.nd_r2_code,
					nd_r3_code=NEW.nd_r3_code,
					nd_r4_code=NEW.nd_r4_code,
					nd_voie=NEW.nd_voie,
					nd_type=NEW.nd_type,
					nd_type_ep=NEW.nd_type_ep,
					nd_comment=NEW.nd_comment,
					nd_dtclass=NEW.nd_dtclass,
					nd_geolqlt=NEW.nd_geolqlt,
					nd_geolmod=NEW.nd_geolmod,
					nd_geolsrc=NEW.nd_geolsrc,
					nd_creadat=NEW.nd_creadat,
					nd_majdate=NEW.nd_majdate,
					nd_majsrc=NEW.nd_majsrc,
					nd_abddate=NEW.nd_abddate,
					nd_abdsrc=NEW.nd_abdsrc,
					geom=NEW.geom			
				WHERE nd_code=OLD.nd_code
				;
				UPDATE t_sitetech SET 
					st_code=NEW.st_code,
					st_nd_code=NEW.st_nd_code,
					st_codeext=NEW.st_codeext,
					st_nom=NEW.st_nom,
					st_prop=NEW.st_prop,
					st_gest=NEW.st_gest,
					st_user=NEW.st_user,
					st_proptyp=NEW.st_proptyp,
					st_statut=NEW.st_statut,
					st_etat=NEW.st_etat,
					st_dateins=NEW.st_dateins,
					st_datemes=NEW.st_datemes,
					st_avct=NEW.st_avct,
					st_typephy=NEW.st_typephy,
					st_typelog=NEW.st_typelog,
					st_nblines=NEW.st_nblines,
					st_ad_code=NEW.st_ad_code,
					st_comment=NEW.st_comment,
					st_creadat=NEW.st_creadat,
					st_majdate=NEW.st_majdate,
					st_majsrc=NEW.st_majsrc,
					st_abddate=NEW.st_abddate,
					st_abdsrc=NEW.st_abdsrc
				WHERE st_code=OLD.st_code
				;
				UPDATE t_ltech SET 
					lt_code=NEW.lt_code,
					lt_codeext=NEW.lt_codeext,
					lt_etiquet=NEW.lt_etiquet,
					lt_st_code=NEW.lt_st_code,
					lt_prop=NEW.lt_prop,
					lt_gest=NEW.lt_gest,
					lt_user=NEW.lt_user,
					lt_proptyp=NEW.lt_proptyp,
					lt_statut=NEW.lt_statut,
					lt_etat=NEW.lt_etat,
					lt_dateins=NEW.lt_dateins,
					lt_datemes=NEW.lt_datemes,
					lt_local=NEW.lt_local,
					lt_elec=NEW.lt_elec,
					lt_clim=NEW.lt_clim,
					lt_occp=NEW.lt_occp,
					lt_idmajic=NEW.lt_idmajic,
					lt_comment=NEW.lt_comment,
					lt_creadat=NEW.lt_creadat,
					lt_majdate=NEW.lt_majdate,
					lt_majsrc=NEW.lt_majsrc,
					lt_abddate=NEW.lt_abddate,
					lt_abdsrc=NEW.lt_abdsrc
				WHERE lt_code=OLD.lt_code
				;
				UPDATE t_ebp SET 
					bp_code=NEW.bp_code,
					bp_etiquet=NEW.bp_etiquet,
					bp_codeext=NEW.bp_codeext,
					bp_pt_code=NEW.bp_pt_code,
					bp_lt_code=NEW.bp_lt_code,
					bp_sf_code=NEW.bp_sf_code,
					bp_prop=NEW.bp_prop,
					bp_gest=NEW.bp_gest,
					bp_user=NEW.bp_user,
					bp_proptyp=NEW.bp_proptyp,
					bp_statut=NEW.bp_statut,
					bp_etat=NEW.bp_etat,
					bp_occp=NEW.bp_occp,
					bp_datemes=NEW.bp_datemes,
					bp_avct=NEW.bp_avct,
					bp_typephy=NEW.bp_typephy,
					bp_typelog=NEW.bp_typelog,
					bp_rf_code=NEW.bp_rf_code,
					bp_entrees=NEW.bp_entrees,
					bp_ref_kit=NEW.bp_ref_kit,
					bp_ca_nb=NEW.bp_ca_nb,
					bp_nb_pas=NEW.bp_nb_pas,
					bp_linecod=NEW.bp_linecod,
					bp_oc_code=NEW.bp_oc_code,
					bp_racco=NEW.bp_racco,
					bp_comment=NEW.bp_comment,
					bp_creadat=NEW.bp_creadat,
					bp_majdate=NEW.bp_majdate,
					bp_majsrc=NEW.bp_majsrc,
					bp_abddate=NEW.bp_abddate,
					bp_abdsrc=NEW.bp_abdsrc
				WHERE bp_code=OLD.bp_code
				;
				UPDATE t_cassette SET 
					cs_code=NEW.cs_code,
					cs_nb_pas=NEW.cs_nb_pas,
					cs_bp_code=NEW.cs_bp_code,
					cs_num=NEW.cs_num,
					cs_type=NEW.cs_type,
					cs_face=NEW.cs_face,
					cs_rf_code=NEW.cs_rf_code,
					cs_comment=NEW.cs_comment,
					cs_creadat=NEW.cs_creadat,
					cs_majdate=NEW.cs_majdate,
					cs_majsrc=NEW.cs_majsrc,
					cs_abddate=NEW.cs_abddate,
					cs_abdsrc=NEW.cs_abdsrc
				WHERE cs_code=OLD.cs_code
				;		
				RETURN NEW;
			  ELSIF TG_OP = 'DELETE' THEN
				/*INVERSER ?*/
				DELETE FROM t_cassette WHERE cs_code=OLD.cs_code;
				DELETE FROM t_ebp WHERE bp_code=OLD.bp_code;		
				DELETE FROM t_ltech WHERE lt_code=OLD.lt_code;
				DELETE FROM t_sitetech WHERE st_code=OLD.st_code;
				DELETE FROM t_noeud WHERE nd_code=OLD.nd_code;
			   RETURN NULL;
			  END IF;
			  RETURN NEW;
			END;
		$function$;

		CREATE TRIGGER tg_edit_vs_elem_cs_bp_lt_st_nd
			INSTEAD OF INSERT OR UPDATE OR DELETE ON
			  vs_elem_cs_bp_lt_st_nd FOR EACH ROW EXECUTE PROCEDURE fn_edit_vs_elem_cs_bp_lt_st_nd();

			  
		/*vs_elem_bp_sf_nd*/
		DROP TRIGGER IF EXISTS tg_edit_vs_elem_bp_sf_nd ON vs_elem_bp_sf_nd CASCADE;
		DROP FUNCTION IF EXISTS fn_edit_vs_elem_bp_sf_nd() CASCADE;

		CREATE OR REPLACE FUNCTION fn_edit_vs_elem_bp_sf_nd()
		RETURNS TRIGGER
		LANGUAGE plpgsql
		AS $function$
		   BEGIN
			  IF TG_OP = 'INSERT' THEN
				INSERT INTO  t_noeud VALUES(
					NEW.nd_code,
					NEW.nd_codeext,
					NEW.nd_nom,
					NEW.nd_coderat,
					NEW.nd_r1_code,
					NEW.nd_r2_code,
					NEW.nd_r3_code,
					NEW.nd_r4_code,
					NEW.nd_voie,
					NEW.nd_type,
					NEW.nd_type_ep,
					NEW.nd_comment,
					NEW.nd_dtclass,
					NEW.nd_geolqlt,
					NEW.nd_geolmod,
					NEW.nd_geolsrc,
					NEW.nd_creadat,
					NEW.nd_majdate,
					NEW.nd_majsrc,
					NEW.nd_abddate,
					NEW.nd_abdsrc,
					NEW.geom
					);
				INSERT INTO  t_suf VALUES(
					NEW.sf_code,
					NEW.sf_nd_code,
					NEW.sf_ad_code,
					NEW.sf_zp_code,
					NEW.sf_escal,
					NEW.sf_etage,
					NEW.sf_oper,
					NEW.sf_type,
					NEW.sf_prop,
					NEW.sf_resid,
					NEW.sf_local,
					NEW.sf_racco,
					NEW.sf_comment,
					NEW.sf_creadat,
					NEW.sf_majdate,
					NEW.sf_majsrc,
					NEW.sf_abddate,
					NEW.sf_abdsrc
					);
				INSERT INTO  t_ebp VALUES(			
					NEW.bp_code,
					NEW.bp_etiquet,
					NEW.bp_codeext,
					NEW.bp_sf_code,
					NEW.bp_lt_code,
					NEW.bp_sf_code,
					NEW.bp_prop,
					NEW.bp_gest,
					NEW.bp_user,
					NEW.bp_proptyp,
					NEW.bp_statut,
					NEW.bp_etat,
					NEW.bp_occp,
					NEW.bp_datemes,
					NEW.bp_avct,
					NEW.bp_typephy,
					NEW.bp_typelog,
					NEW.bp_rf_code,
					NEW.bp_entrees,
					NEW.bp_ref_kit,
					NEW.bp_ca_nb,
					NEW.bp_nb_pas,
					NEW.bp_linecod,
					NEW.bp_oc_code,
					NEW.bp_racco,
					NEW.bp_comment,
					NEW.bp_creadat,
					NEW.bp_majdate,
					NEW.bp_majsrc,
					NEW.bp_abddate,
					NEW.bp_abdsrc
					);
				RETURN NEW;
			  ELSIF TG_OP = 'UPDATE' THEN
				UPDATE t_noeud SET 
					nd_code=NEW.nd_code,
					nd_codeext=NEW.nd_codeext,
					nd_nom=NEW.nd_nom,
					nd_coderat=NEW.nd_coderat,
					nd_r1_code=NEW.nd_r1_code,
					nd_r2_code=NEW.nd_r2_code,
					nd_r3_code=NEW.nd_r3_code,
					nd_r4_code=NEW.nd_r4_code,
					nd_voie=NEW.nd_voie,
					nd_type=NEW.nd_type,
					nd_type_ep=NEW.nd_type_ep,
					nd_comment=NEW.nd_comment,
					nd_dtclass=NEW.nd_dtclass,
					nd_geolqlt=NEW.nd_geolqlt,
					nd_geolmod=NEW.nd_geolmod,
					nd_geolsrc=NEW.nd_geolsrc,
					nd_creadat=NEW.nd_creadat,
					nd_majdate=NEW.nd_majdate,
					nd_majsrc=NEW.nd_majsrc,
					nd_abddate=NEW.nd_abddate,
					nd_abdsrc=NEW.nd_abdsrc,
					geom=NEW.geom			
				WHERE nd_code=OLD.nd_code
				;
				UPDATE t_suf SET 
					sf_code=NEW.sf_code,
					sf_nd_code=NEW.sf_nd_code,
					sf_ad_code=NEW.sf_ad_code,
					sf_zp_code=NEW.sf_zp_code,
					sf_escal=NEW.sf_escal,
					sf_etage=NEW.sf_etage,
					sf_oper=NEW.sf_oper,
					sf_type=NEW.sf_type,
					sf_prop=NEW.sf_prop,
					sf_resid=NEW.sf_resid,
					sf_local=NEW.sf_local,
					sf_racco=NEW.sf_racco,
					sf_comment=NEW.sf_comment,
					sf_creadat=NEW.sf_creadat,
					sf_majdate=NEW.sf_majdate,
					sf_majsrc=NEW.sf_majsrc,
					sf_abddate=NEW.sf_abddate,
					sf_abdsrc=NEW.sf_abdsrc
				WHERE sf_code=OLD.sf_code
				;
				UPDATE t_ebp SET 
					bp_code=NEW.bp_code,
					bp_etiquet=NEW.bp_etiquet,
					bp_codeext=NEW.bp_codeext,
					bp_sf_code=NEW.bp_sf_code,
					bp_lt_code=NEW.bp_lt_code,
					bp_sf_code=NEW.bp_sf_code,
					bp_prop=NEW.bp_prop,
					bp_gest=NEW.bp_gest,
					bp_user=NEW.bp_user,
					bp_proptyp=NEW.bp_proptyp,
					bp_statut=NEW.bp_statut,
					bp_etat=NEW.bp_etat,
					bp_occp=NEW.bp_occp,
					bp_datemes=NEW.bp_datemes,
					bp_avct=NEW.bp_avct,
					bp_typephy=NEW.bp_typephy,
					bp_typelog=NEW.bp_typelog,
					bp_rf_code=NEW.bp_rf_code,
					bp_entrees=NEW.bp_entrees,
					bp_ref_kit=NEW.bp_ref_kit,
					bp_ca_nb=NEW.bp_ca_nb,
					bp_nb_pas=NEW.bp_nb_pas,
					bp_linecod=NEW.bp_linecod,
					bp_oc_code=NEW.bp_oc_code,
					bp_racco=NEW.bp_racco,
					bp_comment=NEW.bp_comment,
					bp_creadat=NEW.bp_creadat,
					bp_majdate=NEW.bp_majdate,
					bp_majsrc=NEW.bp_majsrc,
					bp_abddate=NEW.bp_abddate,
					bp_abdsrc=NEW.bp_abdsrc
				WHERE bp_code=OLD.bp_code
				;

				RETURN NEW;
			  ELSIF TG_OP = 'DELETE' THEN
				/*INVERSER ?*/
				DELETE FROM t_ebp WHERE bp_code=OLD.bp_code;
				DELETE FROM t_suf WHERE sf_code=OLD.sf_code;
				DELETE FROM t_noeud WHERE nd_code=OLD.nd_code;
			   RETURN NULL;
			  END IF;
			  RETURN NEW;
			END;
		$function$;

		CREATE TRIGGER tg_edit_vs_elem_bp_sf_nd
			INSTEAD OF INSERT OR UPDATE OR DELETE ON
			  vs_elem_bp_sf_nd FOR EACH ROW EXECUTE PROCEDURE fn_edit_vs_elem_bp_sf_nd();

			  

		/*vs_elem_sf_nd*/
		DROP TRIGGER IF EXISTS tg_edit_vs_elem_sf_nd ON vs_elem_sf_nd CASCADE;
		DROP FUNCTION IF EXISTS fn_edit_vs_elem_sf_nd() CASCADE;

		CREATE OR REPLACE FUNCTION fn_edit_vs_elem_sf_nd()
		RETURNS TRIGGER
		LANGUAGE plpgsql
		AS $function$
		   BEGIN
			  IF TG_OP = 'INSERT' THEN
				INSERT INTO  t_noeud VALUES(
					NEW.nd_code,
					NEW.nd_codeext,
					NEW.nd_nom,
					NEW.nd_coderat,
					NEW.nd_r1_code,
					NEW.nd_r2_code,
					NEW.nd_r3_code,
					NEW.nd_r4_code,
					NEW.nd_voie,
					NEW.nd_type,
					NEW.nd_type_ep,
					NEW.nd_comment,
					NEW.nd_dtclass,
					NEW.nd_geolqlt,
					NEW.nd_geolmod,
					NEW.nd_geolsrc,
					NEW.nd_creadat,
					NEW.nd_majdate,
					NEW.nd_majsrc,
					NEW.nd_abddate,
					NEW.nd_abdsrc,
					NEW.geom
					);
				INSERT INTO  t_suf VALUES(
					NEW.sf_code,
					NEW.sf_nd_code,
					NEW.sf_ad_code,
					NEW.sf_zp_code,
					NEW.sf_escal,
					NEW.sf_etage,
					NEW.sf_oper,
					NEW.sf_type,
					NEW.sf_prop,
					NEW.sf_resid,
					NEW.sf_local,
					NEW.sf_racco,
					NEW.sf_comment,
					NEW.sf_creadat,
					NEW.sf_majdate,
					NEW.sf_majsrc,
					NEW.sf_abddate,
					NEW.sf_abdsrc
					);
				RETURN NEW;
			  ELSIF TG_OP = 'UPDATE' THEN
				UPDATE t_noeud SET 
					nd_code=NEW.nd_code,
					nd_codeext=NEW.nd_codeext,
					nd_nom=NEW.nd_nom,
					nd_coderat=NEW.nd_coderat,
					nd_r1_code=NEW.nd_r1_code,
					nd_r2_code=NEW.nd_r2_code,
					nd_r3_code=NEW.nd_r3_code,
					nd_r4_code=NEW.nd_r4_code,
					nd_voie=NEW.nd_voie,
					nd_type=NEW.nd_type,
					nd_type_ep=NEW.nd_type_ep,
					nd_comment=NEW.nd_comment,
					nd_dtclass=NEW.nd_dtclass,
					nd_geolqlt=NEW.nd_geolqlt,
					nd_geolmod=NEW.nd_geolmod,
					nd_geolsrc=NEW.nd_geolsrc,
					nd_creadat=NEW.nd_creadat,
					nd_majdate=NEW.nd_majdate,
					nd_majsrc=NEW.nd_majsrc,
					nd_abddate=NEW.nd_abddate,
					nd_abdsrc=NEW.nd_abdsrc,
					geom=NEW.geom			
				WHERE nd_code=OLD.nd_code
				;
				UPDATE t_suf SET 
					sf_code=NEW.sf_code,
					sf_nd_code=NEW.sf_nd_code,
					sf_ad_code=NEW.sf_ad_code,
					sf_zp_code=NEW.sf_zp_code,
					sf_escal=NEW.sf_escal,
					sf_etage=NEW.sf_etage,
					sf_oper=NEW.sf_oper,
					sf_type=NEW.sf_type,
					sf_prop=NEW.sf_prop,
					sf_resid=NEW.sf_resid,
					sf_local=NEW.sf_local,
					sf_racco=NEW.sf_racco,
					sf_comment=NEW.sf_comment,
					sf_creadat=NEW.sf_creadat,
					sf_majdate=NEW.sf_majdate,
					sf_majsrc=NEW.sf_majsrc,
					sf_abddate=NEW.sf_abddate,
					sf_abdsrc=NEW.sf_abdsrc
				WHERE sf_code=OLD.sf_code
				;
				RETURN NEW;
			  ELSIF TG_OP = 'DELETE' THEN
				/*INVERSER ?*/
				DELETE FROM t_suf WHERE sf_code=OLD.sf_code;
				DELETE FROM t_noeud WHERE nd_code=OLD.nd_code;
			   RETURN NULL;
			  END IF;
			  RETURN NEW;
			END;
		$function$;

		CREATE TRIGGER tg_edit_vs_elem_sf_nd
			INSTEAD OF INSERT OR UPDATE OR DELETE ON
			  vs_elem_sf_nd FOR EACH ROW EXECUTE PROCEDURE fn_edit_vs_elem_sf_nd();
			  

		/*vs_elem_se_nd*/
		DROP TRIGGER IF EXISTS tg_edit_vs_elem_se_nd ON vs_elem_se_nd CASCADE;
		DROP FUNCTION IF EXISTS fn_edit_vs_elem_se_nd() CASCADE;

		CREATE OR REPLACE FUNCTION fn_edit_vs_elem_se_nd()
		RETURNS TRIGGER
		LANGUAGE plpgsql
		AS $function$
		   BEGIN
			  IF TG_OP = 'INSERT' THEN
				INSERT INTO  t_noeud VALUES(
					NEW.nd_code,
					NEW.nd_codeext,
					NEW.nd_nom,
					NEW.nd_coderat,
					NEW.nd_r1_code,
					NEW.nd_r2_code,
					NEW.nd_r3_code,
					NEW.nd_r4_code,
					NEW.nd_voie,
					NEW.nd_type,
					NEW.nd_type_ep,
					NEW.nd_comment,
					NEW.nd_dtclass,
					NEW.nd_geolqlt,
					NEW.nd_geolmod,
					NEW.nd_geolsrc,
					NEW.nd_creadat,
					NEW.nd_majdate,
					NEW.nd_majsrc,
					NEW.nd_abddate,
					NEW.nd_abdsrc,
					NEW.geom
					);
				INSERT INTO  t_siteemission VALUES(
					NEW.se_code,
					NEW.se_nd_code,
					NEW.se_anfr,
					NEW.se_prop,
					NEW.se_gest,
					NEW.se_user,
					NEW.se_proptyp,
					NEW.se_statut,
					NEW.se_etat,
					NEW.se_occp,
					NEW.se_dateins,
					NEW.se_datemes,
					NEW.se_type,
					NEW.se_haut,
					NEW.se_ad_code,
					NEW.se_comment,
					NEW.se_creadat,
					NEW.se_majdate,
					NEW.se_majsrc,
					NEW.se_abddate,
					NEW.se_abdsrc
					);
				RETURN NEW;
			  ELSIF TG_OP = 'UPDATE' THEN
				UPDATE t_noeud SET 
					nd_code=NEW.nd_code,
					nd_codeext=NEW.nd_codeext,
					nd_nom=NEW.nd_nom,
					nd_coderat=NEW.nd_coderat,
					nd_r1_code=NEW.nd_r1_code,
					nd_r2_code=NEW.nd_r2_code,
					nd_r3_code=NEW.nd_r3_code,
					nd_r4_code=NEW.nd_r4_code,
					nd_voie=NEW.nd_voie,
					nd_type=NEW.nd_type,
					nd_type_ep=NEW.nd_type_ep,
					nd_comment=NEW.nd_comment,
					nd_dtclass=NEW.nd_dtclass,
					nd_geolqlt=NEW.nd_geolqlt,
					nd_geolmod=NEW.nd_geolmod,
					nd_geolsrc=NEW.nd_geolsrc,
					nd_creadat=NEW.nd_creadat,
					nd_majdate=NEW.nd_majdate,
					nd_majsrc=NEW.nd_majsrc,
					nd_abddate=NEW.nd_abddate,
					nd_abdsrc=NEW.nd_abdsrc,
					geom=NEW.geom			
				WHERE nd_code=OLD.nd_code
				;
				UPDATE t_siteemission SET 
					se_code=NEW.se_code,
					se_nd_code=NEW.se_nd_code,
					se_anfr=NEW.se_anfr,
					se_prop=NEW.se_prop,
					se_gest=NEW.se_gest,
					se_user=NEW.se_user,
					se_proptyp=NEW.se_proptyp,
					se_statut=NEW.se_statut,
					se_etat=NEW.se_etat,
					se_occp=NEW.se_occp,
					se_dateins=NEW.se_dateins,
					se_datemes=NEW.se_datemes,
					se_type=NEW.se_type,
					se_haut=NEW.se_haut,
					se_ad_code=NEW.se_ad_code,
					se_comment=NEW.se_comment,
					se_creadat=NEW.se_creadat,
					se_majdate=NEW.se_majdate,
					se_majsrc=NEW.se_majsrc,
					se_abddate=NEW.se_abddate,
					se_abdsrc=NEW.se_abdsrc
				WHERE se_code=OLD.se_code
				;
				RETURN NEW;
			  ELSIF TG_OP = 'DELETE' THEN
				/*INVERSER ?*/
				DELETE FROM t_siteemission WHERE se_code=OLD.se_code;
				DELETE FROM t_noeud WHERE nd_code=OLD.nd_code;
			   RETURN NULL;
			  END IF;
			  RETURN NEW;
			END;
		$function$;

		CREATE TRIGGER tg_edit_vs_elem_se_nd
			INSTEAD OF INSERT OR UPDATE OR DELETE ON
			  vs_elem_se_nd FOR EACH ROW EXECUTE PROCEDURE fn_edit_vs_elem_se_nd();
			  

		/*vs_elem_mq_nd*/
		DROP TRIGGER IF EXISTS tg_edit_vs_elem_mq_nd ON vs_elem_mq_nd CASCADE;
		DROP FUNCTION IF EXISTS fn_edit_vs_elem_mq_nd() CASCADE;

		CREATE OR REPLACE FUNCTION fn_edit_vs_elem_mq_nd()
		RETURNS TRIGGER
		LANGUAGE plpgsql
		AS $function$
		   BEGIN
			  IF TG_OP = 'INSERT' THEN
				INSERT INTO  t_noeud VALUES(
					NEW.nd_code,
					NEW.nd_codeext,
					NEW.nd_nom,
					NEW.nd_coderat,
					NEW.nd_r1_code,
					NEW.nd_r2_code,
					NEW.nd_r3_code,
					NEW.nd_r4_code,
					NEW.nd_voie,
					NEW.nd_type,
					NEW.nd_type_ep,
					NEW.nd_comment,
					NEW.nd_dtclass,
					NEW.nd_geolqlt,
					NEW.nd_geolmod,
					NEW.nd_geolsrc,
					NEW.nd_creadat,
					NEW.nd_majdate,
					NEW.nd_majsrc,
					NEW.nd_abddate,
					NEW.nd_abdsrc,
					NEW.geom
					);
				INSERT INTO  t_masque VALUES(
					NEW.mq_id,
					NEW.mq_nd_code,
					NEW.mq_face,
					NEW.mq_col,
					NEW.mq_ligne,
					NEW.mq_cd_code,
					NEW.mq_qualinf,
					NEW.mq_comment,
					NEW.mq_creadat,
					NEW.mq_majdate,
					NEW.mq_majsrc,
					NEW.mq_abddate,
					NEW.mq_abdsrc
					);
				RETURN NEW;
			  ELSIF TG_OP = 'UPDATE' THEN
				UPDATE t_noeud SET 
					nd_code=NEW.nd_code,
					nd_codeext=NEW.nd_codeext,
					nd_nom=NEW.nd_nom,
					nd_coderat=NEW.nd_coderat,
					nd_r1_code=NEW.nd_r1_code,
					nd_r2_code=NEW.nd_r2_code,
					nd_r3_code=NEW.nd_r3_code,
					nd_r4_code=NEW.nd_r4_code,
					nd_voie=NEW.nd_voie,
					nd_type=NEW.nd_type,
					nd_type_ep=NEW.nd_type_ep,
					nd_comment=NEW.nd_comment,
					nd_dtclass=NEW.nd_dtclass,
					nd_geolqlt=NEW.nd_geolqlt,
					nd_geolmod=NEW.nd_geolmod,
					nd_geolsrc=NEW.nd_geolsrc,
					nd_creadat=NEW.nd_creadat,
					nd_majdate=NEW.nd_majdate,
					nd_majsrc=NEW.nd_majsrc,
					nd_abddate=NEW.nd_abddate,
					nd_abdsrc=NEW.nd_abdsrc,
					geom=NEW.geom			
				WHERE nd_code=OLD.nd_code
				;
				UPDATE t_masque SET 
					mq_id=NEW.mq_id,
					mq_nd_code=NEW.mq_nd_code,
					mq_face=NEW.mq_face,
					mq_col=NEW.mq_col,
					mq_ligne=NEW.mq_ligne,
					mq_cd_code=NEW.mq_cd_code,
					mq_qualinf=NEW.mq_qualinf,
					mq_comment=NEW.mq_comment,
					mq_creadat=NEW.mq_creadat,
					mq_majdate=NEW.mq_majdate,
					mq_majsrc=NEW.mq_majsrc,
					mq_abddate=NEW.mq_abddate,
					mq_abdsrc=NEW.mq_abdsrc
				WHERE mq_id=OLD.mq_id
				;
				RETURN NEW;
			  ELSIF TG_OP = 'DELETE' THEN
				/*INVERSER ?*/
				DELETE FROM t_masque WHERE mq_id=OLD.mq_id;
				DELETE FROM t_noeud WHERE nd_code=OLD.nd_code;
			   RETURN NULL;
			  END IF;
			  RETURN NEW;
			END;
		$function$;

		CREATE TRIGGER tg_edit_vs_elem_mq_nd
			INSTEAD OF INSERT OR UPDATE OR DELETE ON
			  vs_elem_mq_nd FOR EACH ROW EXECUTE PROCEDURE fn_edit_vs_elem_mq_nd();
			  

		/*vs_elem_lv_nd*/
		DROP TRIGGER IF EXISTS tg_edit_vs_elem_lv_nd ON vs_elem_lv_nd CASCADE;
		DROP FUNCTION IF EXISTS fn_edit_vs_elem_lv_nd() CASCADE;

		CREATE OR REPLACE FUNCTION fn_edit_vs_elem_lv_nd()
		RETURNS TRIGGER
		LANGUAGE plpgsql
		AS $function$
		   BEGIN
			  IF TG_OP = 'INSERT' THEN
				INSERT INTO  t_noeud VALUES(
					NEW.nd_code,
					NEW.nd_codeext,
					NEW.nd_nom,
					NEW.nd_coderat,
					NEW.nd_r1_code,
					NEW.nd_r2_code,
					NEW.nd_r3_code,
					NEW.nd_r4_code,
					NEW.nd_voie,
					NEW.nd_type,
					NEW.nd_type_ep,
					NEW.nd_comment,
					NEW.nd_dtclass,
					NEW.nd_geolqlt,
					NEW.nd_geolmod,
					NEW.nd_geolsrc,
					NEW.nd_creadat,
					NEW.nd_majdate,
					NEW.nd_majsrc,
					NEW.nd_abddate,
					NEW.nd_abdsrc,
					NEW.geom
					);
				INSERT INTO  t_love VALUES(
					NEW.lv_id,
					NEW.lv_cb_code,
					NEW.lv_nd_code,
					NEW.lv_long,
					NEW.lv_creadat,
					NEW.lv_majdate,
					NEW.lv_majsrc,
					NEW.lv_abddate,
					NEW.lv_abdsrc
					);
				RETURN NEW;
			  ELSIF TG_OP = 'UPDATE' THEN
				UPDATE t_noeud SET 
					nd_code=NEW.nd_code,
					nd_codeext=NEW.nd_codeext,
					nd_nom=NEW.nd_nom,
					nd_coderat=NEW.nd_coderat,
					nd_r1_code=NEW.nd_r1_code,
					nd_r2_code=NEW.nd_r2_code,
					nd_r3_code=NEW.nd_r3_code,
					nd_r4_code=NEW.nd_r4_code,
					nd_voie=NEW.nd_voie,
					nd_type=NEW.nd_type,
					nd_type_ep=NEW.nd_type_ep,
					nd_comment=NEW.nd_comment,
					nd_dtclass=NEW.nd_dtclass,
					nd_geolqlt=NEW.nd_geolqlt,
					nd_geolmod=NEW.nd_geolmod,
					nd_geolsrc=NEW.nd_geolsrc,
					nd_creadat=NEW.nd_creadat,
					nd_majdate=NEW.nd_majdate,
					nd_majsrc=NEW.nd_majsrc,
					nd_abddate=NEW.nd_abddate,
					nd_abdsrc=NEW.nd_abdsrc,
					geom=NEW.geom			
				WHERE nd_code=OLD.nd_code
				;
				UPDATE t_love SET 
					lv_id=NEW.lv_id,
					lv_cb_code=NEW.lv_cb_code,
					lv_nd_code=NEW.lv_nd_code,
					lv_long=NEW.lv_long,
					lv_creadat=NEW.lv_creadat,
					lv_majdate=NEW.lv_majdate,
					lv_majsrc=NEW.lv_majsrc,
					lv_abddate=NEW.lv_abddate,
					lv_abdsrc=NEW.lv_abdsrc
				WHERE lv_id=OLD.lv_id
				;
				RETURN NEW;
			  ELSIF TG_OP = 'DELETE' THEN
				/*INVERSER ?*/
				DELETE FROM t_love WHERE lv_id=OLD.lv_id;
				DELETE FROM t_noeud WHERE nd_code=OLD.nd_code;
			   RETURN NULL;
			  END IF;
			  RETURN NEW;
			END;
		$function$;

		CREATE TRIGGER tg_edit_vs_elem_lv_nd
			INSTEAD OF INSERT OR UPDATE OR DELETE ON
			  vs_elem_lv_nd FOR EACH ROW EXECUTE PROCEDURE fn_edit_vs_elem_lv_nd();
			  

		/*vs_elem_cd_dm_cm*/
		DROP TRIGGER IF EXISTS tg_edit_vs_elem_cd_dm_cm ON vs_elem_cd_dm_cm CASCADE;
		DROP FUNCTION IF EXISTS fn_edit_vs_elem_cd_dm_cm() CASCADE;

		CREATE OR REPLACE FUNCTION fn_edit_vs_elem_cd_dm_cm()
		RETURNS TRIGGER
		LANGUAGE plpgsql
		AS $function$
		   BEGIN
			  IF TG_OP = 'INSERT' THEN
				INSERT INTO t_cheminement VALUES(
					NEW.cm_code,
					NEW.cm_codeext,
					NEW.cm_ndcode1,
					NEW.cm_ndcode2,
					NEW.cm_cm1,
					NEW.cm_cm2,
					NEW.cm_r1_code,
					NEW.cm_r2_code,
					NEW.cm_r3_code,
					NEW.cm_r4_code,
					NEW.cm_voie,
					NEW.cm_gest_do,
					NEW.cm_prop_do,
					NEW.cm_statut,
					NEW.cm_etat,
					NEW.cm_datcons,
					NEW.cm_datemes,
					NEW.cm_avct,
					NEW.cm_typelog,
					NEW.cm_typ_imp,
					NEW.cm_nature,
					NEW.cm_compo,
					NEW.cm_cddispo,
					NEW.cm_fo_util,
					NEW.cm_mod_pos,
					NEW.cm_passage,
					NEW.cm_revet,
					NEW.cm_remblai,
					NEW.cm_charge,
					NEW.cm_larg,
					NEW.cm_fildtec,
					NEW.cm_mut_org,
					NEW.cm_long,
					NEW.cm_lgreel,
					NEW.cm_comment,
					NEW.cm_dtclass,
					NEW.cm_geolqlt,
					NEW.cm_geolmod,
					NEW.cm_geolsrc,
					NEW.cm_creadat,
					NEW.cm_majdate,
					NEW.cm_majsrc,
					NEW.cm_abddate,
					NEW.cm_abdsrc,
					NEW.geom			);
				INSERT INTO t_conduite VALUES(
					NEW.cd_code,
					NEW.cd_codeext,
					NEW.cd_etiquet,
					NEW.cd_cd_code,
					NEW.cd_r1_code,
					NEW.cd_r2_code,
					NEW.cd_r3_code,
					NEW.cd_r4_code,
					NEW.cd_prop,
					NEW.cd_gest,
					NEW.cd_user,
					NEW.cd_proptyp,
					NEW.cd_statut,
					NEW.cd_etat,
					NEW.cd_dateaig,
					NEW.cd_dateman,
					NEW.cd_datemes,
					NEW.cd_avct,
					NEW.cd_type,
					NEW.cd_dia_int,
					NEW.cd_dia_ext,
					NEW.cd_color,
					NEW.cd_long,
					NEW.cd_nbcable,
					NEW.cd_occup,
					NEW.cd_comment,
					NEW.cd_creadat,
					NEW.cd_majdate,
					NEW.cd_majsrc,
					NEW.cd_abddate,
					NEW.cd_abdsrc
					);
				INSERT INTO t_cond_chem VALUES(
					NEW.dm_cd_code,
					NEW.dm_cm_code,
					NEW.dm_creadat,
					NEW.dm_majdate,
					NEW.dm_majsrc,
					NEW.dm_abddate,
					NEW.dm_abdsrc
					);
				RETURN NEW;
			  ELSIF TG_OP = 'UPDATE' THEN
				UPDATE t_cheminement SET 
					cm_code=NEW.cm_code,
					cm_codeext=NEW.cm_codeext,
					cm_ndcode1=NEW.cm_ndcode1,
					cm_ndcode2=NEW.cm_ndcode2,
					cm_cm1=NEW.cm_cm1,
					cm_cm2=NEW.cm_cm2,
					cm_r1_code=NEW.cm_r1_code,
					cm_r2_code=NEW.cm_r2_code,
					cm_r3_code=NEW.cm_r3_code,
					cm_r4_code=NEW.cm_r4_code,
					cm_voie=NEW.cm_voie,
					cm_gest_do=NEW.cm_gest_do,
					cm_prop_do=NEW.cm_prop_do,
					cm_statut=NEW.cm_statut,
					cm_etat=NEW.cm_etat,
					cm_datcons=NEW.cm_datcons,
					cm_datemes=NEW.cm_datemes,
					cm_avct=NEW.cm_avct,
					cm_typelog=NEW.cm_typelog,
					cm_typ_imp=NEW.cm_typ_imp,
					cm_nature=NEW.cm_nature,
					cm_compo=NEW.cm_compo,
					cm_cddispo=NEW.cm_cddispo,
					cm_fo_util=NEW.cm_fo_util,
					cm_mod_pos=NEW.cm_mod_pos,
					cm_passage=NEW.cm_passage,
					cm_revet=NEW.cm_revet,
					cm_remblai=NEW.cm_remblai,
					cm_charge=NEW.cm_charge,
					cm_larg=NEW.cm_larg,
					cm_fildtec=NEW.cm_fildtec,
					cm_mut_org=NEW.cm_mut_org,
					cm_long=NEW.cm_long,
					cm_lgreel=NEW.cm_lgreel,
					cm_comment=NEW.cm_comment,
					cm_dtclass=NEW.cm_dtclass,
					cm_geolqlt=NEW.cm_geolqlt,
					cm_geolmod=NEW.cm_geolmod,
					cm_geolsrc=NEW.cm_geolsrc,
					cm_creadat=NEW.cm_creadat,
					cm_majdate=NEW.cm_majdate,
					cm_majsrc=NEW.cm_majsrc,
					cm_abddate=NEW.cm_abddate,
					cm_abdsrc=NEW.cm_abdsrc,
					geom=NEW.geom
				WHERE cm_code=OLD.cm_code
				;
				UPDATE t_conduite SET 
					cd_code=NEW.cd_code,
					cd_codeext=NEW.cd_codeext,
					cd_etiquet=NEW.cd_etiquet,
					cd_cd_code=NEW.cd_cd_code,
					cd_r1_code=NEW.cd_r1_code,
					cd_r2_code=NEW.cd_r2_code,
					cd_r3_code=NEW.cd_r3_code,
					cd_r4_code=NEW.cd_r4_code,
					cd_prop=NEW.cd_prop,
					cd_gest=NEW.cd_gest,
					cd_user=NEW.cd_user,
					cd_proptyp=NEW.cd_proptyp,
					cd_statut=NEW.cd_statut,
					cd_etat=NEW.cd_etat,
					cd_dateaig=NEW.cd_dateaig,
					cd_dateman=NEW.cd_dateman,
					cd_datemes=NEW.cd_datemes,
					cd_avct=NEW.cd_avct,
					cd_type=NEW.cd_type,
					cd_dia_int=NEW.cd_dia_int,
					cd_dia_ext=NEW.cd_dia_ext,
					cd_color=NEW.cd_color,
					cd_long=NEW.cd_long,
					cd_nbcable=NEW.cd_nbcable,
					cd_occup=NEW.cd_occup,
					cd_comment=NEW.cd_comment,
					cd_creadat=NEW.cd_creadat,
					cd_majdate=NEW.cd_majdate,
					cd_majsrc=NEW.cd_majsrc,
					cd_abddate=NEW.cd_abddate,
					cd_abdsrc=NEW.cd_abdsrc
				WHERE cd_code=OLD.cd_code	
				;
				UPDATE t_cond_chem SET 
					dm_cd_code=NEW.dm_cd_code,
					dm_cm_code=NEW.dm_cm_code,
					dm_creadat=NEW.dm_creadat,
					dm_majdate=NEW.dm_majdate,
					dm_majsrc=NEW.dm_majsrc,
					dm_abddate=NEW.dm_abddate,
					dm_abdsrc=NEW.dm_abdsrc
				WHERE dm_cd_code=OLD.dm_cd_code AND dm_cm_code=OLD.dm_cm_code	
				;
				RETURN NEW;
			  ELSIF TG_OP = 'DELETE' THEN
				DELETE FROM t_cond_chem WHERE dm_cd_code=OLD.dm_cd_code AND dm_cm_code=OLD.dm_cm_code;
				DELETE FROM t_conduite WHERE cd_code=OLD.cd_code;
				DELETE FROM t_cheminement WHERE cm_code=OLD.cm_code;
			   RETURN NULL;
			  END IF;
			  RETURN NEW;
			END;
		$function$;

		CREATE TRIGGER tg_edit_vs_elem_cd_dm_cm
			INSTEAD OF INSERT OR UPDATE OR DELETE ON
			  vs_elem_cd_dm_cm FOR EACH ROW EXECUTE PROCEDURE fn_edit_vs_elem_cd_dm_cm();
			  
		 
		/* Empreintes de documents (vs_elem_do_em)*/
		/*vs_elem_do_em*/
		DROP TRIGGER IF EXISTS tg_edit_vs_elem_do_em ON vs_elem_do_em CASCADE;
		DROP FUNCTION IF EXISTS fn_edit_vs_elem_do_em() CASCADE;

		CREATE OR REPLACE FUNCTION fn_edit_vs_elem_do_em()
		RETURNS TRIGGER
		LANGUAGE plpgsql
		AS $function$
		   BEGIN
			  IF TG_OP = 'INSERT' THEN
				INSERT INTO  t_document VALUES(
					NEW.do_code,
					NEW.do_ref,
					NEW.do_reftier,
					NEW.do_r1_code,
					NEW.do_r2_code,
					NEW.do_r3_code,
					NEW.do_r4_code,
					NEW.do_type,
					NEW.do_indice,
					NEW.do_date,
					NEW.do_classe,
					NEW.do_url1,
					NEW.do_url2,
					NEW.do_comment,
					NEW.do_creadat,
					NEW.do_majdate,
					NEW.do_majsrc,
					NEW.do_abddate,
					NEW.do_abdsrc
					);
				INSERT INTO  t_empreinte VALUES(
					NEW.em_code,
					NEW.em_do_code,
					NEW.em_geolsrc,
					NEW.em_creadat,
					NEW.em_majdate,
					NEW.em_majsrc,
					NEW.em_abddate,
					NEW.em_abdsrc,
					NEW.geom
					);
				RETURN NEW;
			  ELSIF TG_OP = 'UPDATE' THEN
				UPDATE t_document SET 
					do_code=NEW.do_code,
					do_ref=NEW.do_ref,
					do_reftier=NEW.do_reftier,
					do_r1_code=NEW.do_r1_code,
					do_r2_code=NEW.do_r2_code,
					do_r3_code=NEW.do_r3_code,
					do_r4_code=NEW.do_r4_code,
					do_type=NEW.do_type,
					do_indice=NEW.do_indice,
					do_date=NEW.do_date,
					do_classe=NEW.do_classe,
					do_url1=NEW.do_url1,
					do_url2=NEW.do_url2,
					do_comment=NEW.do_comment,
					do_creadat=NEW.do_creadat,
					do_majdate=NEW.do_majdate,
					do_majsrc=NEW.do_majsrc,
					do_abddate=NEW.do_abddate,
					do_abdsrc=NEW.do_abdsrc
				WHERE do_code=OLD.do_code
				;
				UPDATE t_empreinte SET 
					em_code=NEW.em_code,
					em_do_code=NEW.em_do_code,
					em_geolsrc=NEW.em_geolsrc,
					em_creadat=NEW.em_creadat,
					em_majdate=NEW.em_majdate,
					em_majsrc=NEW.em_majsrc,
					em_abddate=NEW.em_abddate,
					em_abdsrc=NEW.em_abdsrc,
					geom=NEW.geom	
				WHERE em_code=OLD.em_code
				;
				RETURN NEW;
			  ELSIF TG_OP = 'DELETE' THEN
				/*INVERSER ?*/
				DELETE FROM t_empreinte WHERE em_code=OLD.em_code;
				DELETE FROM t_document WHERE do_code=OLD.do_code;
			   RETURN NULL;
			  END IF;
			  RETURN NEW;
			END;
		$function$;

		CREATE TRIGGER tg_edit_vs_elem_do_em
			INSTEAD OF INSERT OR UPDATE OR DELETE ON
			  vs_elem_do_em FOR EACH ROW EXECUTE PROCEDURE fn_edit_vs_elem_do_em();

			  
		/* Relations documents-objets (v_elem_od_do) */
		DROP TRIGGER IF EXISTS tg_edit_v_elem_od_do ON v_elem_od_do CASCADE;
		DROP FUNCTION IF EXISTS fn_edit_v_elem_od_do() CASCADE;

		CREATE OR REPLACE FUNCTION fn_edit_v_elem_od_do()
		RETURNS TRIGGER
		LANGUAGE plpgsql
		AS $function$
		   BEGIN
			  IF TG_OP = 'INSERT' THEN
				INSERT INTO  t_document VALUES(
					NEW.do_code,
					NEW.do_ref,
					NEW.do_reftier,
					NEW.do_r1_code,
					NEW.do_r2_code,
					NEW.do_r3_code,
					NEW.do_r4_code,
					NEW.do_type,
					NEW.do_indice,
					NEW.do_date,
					NEW.do_classe,
					NEW.do_url1,
					NEW.do_url2,
					NEW.do_comment,
					NEW.do_creadat,
					NEW.do_majdate,
					NEW.do_majsrc,
					NEW.do_abddate,
					NEW.do_abdsrc
					);
				INSERT INTO  t_docobj VALUES(
					NEW.od_id,
					NEW.od_do_code,
					NEW.od_tbltype,
					NEW.od_codeobj,
					NEW.od_creadat,
					NEW.od_majdate,
					NEW.od_majsrc,
					NEW.od_abddate,
					NEW.od_abdsrc
					);
				RETURN NEW;
			  ELSIF TG_OP = 'UPDATE' THEN
				UPDATE t_document SET 
					do_code=NEW.do_code,
					do_ref=NEW.do_ref,
					do_reftier=NEW.do_reftier,
					do_r1_code=NEW.do_r1_code,
					do_r2_code=NEW.do_r2_code,
					do_r3_code=NEW.do_r3_code,
					do_r4_code=NEW.do_r4_code,
					do_type=NEW.do_type,
					do_indice=NEW.do_indice,
					do_date=NEW.do_date,
					do_classe=NEW.do_classe,
					do_url1=NEW.do_url1,
					do_url2=NEW.do_url2,
					do_comment=NEW.do_comment,
					do_creadat=NEW.do_creadat,
					do_majdate=NEW.do_majdate,
					do_majsrc=NEW.do_majsrc,
					do_abddate=NEW.do_abddate,
					do_abdsrc=NEW.do_abdsrc
				WHERE do_code=OLD.do_code
				;
				UPDATE t_docobj SET 
					od_id=NEW.od_id,
					od_do_code=NEW.od_do_code,
					od_tbltype=NEW.od_tbltype,
					od_codeobj=NEW.od_codeobj,
					od_creadat=NEW.od_creadat,
					od_majdate=NEW.od_majdate,
					od_majsrc=NEW.od_majsrc,
					od_abddate=NEW.od_abddate,
					od_abdsrc=NEW.od_abdsrc
				WHERE od_code=OLD.od_code
				;
				RETURN NEW;
			  ELSIF TG_OP = 'DELETE' THEN
				/*INVERSER ?*/
				DELETE FROM t_docobj WHERE od_code=OLD.od_code;
				DELETE FROM t_document WHERE do_code=OLD.do_code;
			   RETURN NULL;
			  END IF;
			  RETURN NEW;
			END;
		$function$;

		CREATE TRIGGER tg_edit_v_elem_od_do
			INSTEAD OF INSERT OR UPDATE OR DELETE ON
			  v_elem_od_do FOR EACH ROW EXECUTE PROCEDURE fn_edit_v_elem_od_do();
			  
			  
		CREATE TABLE t_cable_patch201(
			cb_code VARCHAR(254) NOT NULL REFERENCES t_cable(cb_code),
			--cb_nd1 VARCHAR(254) REFERENCES t_noeud(nd_code), --EXISTANT v2.0
			--cb_ex1 VARCHAR (254), --Code câble + suffixe (ex : CB000000000001-EX1)
			cb_bp1 VARCHAR(254) REFERENCES t_ebp(bp_code), 
			cb_ba1 VARCHAR(254) REFERENCES t_baie(ba_code), --En cas d'éclatement sur plusieurs baies, saisir la baie principale
			--cb_ex2 VARCHAR (254), --Code câble + suffixe (ex : CB000000000001-EX2)
			--cb_nd2 VARCHAR(254) REFERENCES t_noeud(nd_code), --EXISTANT v2.0
			cb_bp2 VARCHAR(254) REFERENCES t_ebp(bp_code), 
			cb_ba2 VARCHAR(254) REFERENCES t_baie(ba_code), --En cas d'éclatement sur plusieurs baies, saisir la baie principale
			CONSTRAINT "t_cable_patch201_pk" PRIMARY KEY (cb_code)
		);

		/*Patch de la version 2.0 pour les zones arrières de PBO*/

		CREATE TABLE t_zpbo_patch201(
			zp_code VARCHAR(254) NOT NULL REFERENCES t_zpbo(zp_code),
			zp_bp_code VARCHAR (254) REFERENCES t_ebp(bp_code), --ajout prévision 2.1
			CONSTRAINT "t_zpbo_patch201_pk" PRIMARY KEY (zp_code)
		);

		/*Patch de la version 2.0 pour les cassettes*/

		CREATE TABLE t_cassette_patch201(
			cs_code VARCHAR(254) NOT NULL REFERENCES t_cassette(cs_code),
			cs_ti_code VARCHAR(254) REFERENCES t_tiroir(ti_code),
			CONSTRAINT "t_cassette_patch201_pk" PRIMARY KEY (cs_code)
		);

		/*Patch de la version 2.0 pour les locaux techniques*/

		CREATE TABLE t_ltech_patch201(
			lt_code VARCHAR(254) NOT NULL REFERENCES t_ltech(lt_code),
			lt_bat VARCHAR(100), --Bâtiment (NULL si adresse = bâtiment)
			lt_escal VARCHAR (20), --Escalier (NULL si adresse = entrée)
			lt_etage VARCHAR (20), --Etage du local
			CONSTRAINT "t_ltech_patch201_pk" PRIMARY KEY (lt_code)
			);


		CREATE OR REPLACE VIEW v_elem_chiffrage AS 
		 SELECT v.nombre,
			v.description
		   FROM ( SELECT count(*) AS nombre,
					'nbre_appuis_ME'::text AS description
				   FROM t_ptech
				  WHERE t_ptech.pt_etat::text = 'ME'::text
				UNION ALL
				 SELECT count(*) AS count,
					'nbre_troncons_SOUT'::text
				   FROM t_cheminement
				  WHERE t_cheminement.cm_typ_imp::text = '7'::text
				UNION ALL
				 SELECT count(*) AS count,
					'nbre_SUF'::text
				   FROM t_suf
				 
				UNION ALL 

				SELECT 
					count(*) AS tot_pot,
					'nbre_bois'::text
				FROM t_ptech
				WHERE pt_etiquet::text like 'POT%'::text AND pt_nature::text = 'PBOI'::text

				union all

				SELECT 
					count(*) AS tot_pot_bois,
					'nbre_beton'::text
				FROM t_ptech
				WHERE pt_etiquet::text like 'POT%'::text AND pt_nature::text = 'PBET'::text
				
				union all 

				SELECT 
					count(*) AS nombre,
					'nbre_Remplacement'::text AS description
				FROM t_ptech
				WHERE pt_etat::text = 'HS'::text
				 
				UNION ALL
				 SELECT DISTINCT count(*) AS nombre,
					t.description
				   FROM ( SELECT DISTINCT cb.cb_code,
							'nbre_Lineaire_CB_SOUTERRAIN'::text AS description
						   FROM t_cable cb
							 JOIN t_cab_cond cbd ON cbd.cc_cb_code::text = cb.cb_code::text
							 JOIN t_cond_chem cdc ON cdc.dm_cd_code::text = cbd.cc_cd_code::text
							 JOIN t_cheminement cm ON cdc.dm_cm_code::text = cm.cm_code::text
						  WHERE cm.cm_typ_imp::text = '7'::text
						UNION
						 SELECT DISTINCT cb.cb_code,
							'nbre_Lineaire_CB_ARIEN'::text
						   FROM t_cable cb
							 JOIN t_cab_cond cbd ON cbd.cc_cb_code::text = cb.cb_code::text
							 JOIN t_cond_chem cdc ON cdc.dm_cd_code::text = cbd.cc_cd_code::text
							 JOIN t_cheminement cm ON cdc.dm_cm_code::text = cm.cm_code::text
						  WHERE cm.cm_typ_imp::text = ANY (ARRAY['0'::character varying, '1'::character varying]::text[])) t
				  GROUP BY t.description
		  ORDER BY 2) v;

		ALTER TABLE v_elem_chiffrage
		  OWNER TO postgres;

		/*Ajout des nouvelles requeles ci-dessous*/
		
		GRANT USAGE ON SCHEMA """+schema+""" to adn_ing; 
		GRANT CREATE ON SCHEMA """+schema+""" to adn_ing;
		GRANT SELECT, INSERT ON ALL TABLES IN SCHEMA """+schema+""" TO adn_ing;
		GRANT ALL ON TABLE contre_releve TO adn_ing;
		"""

		curs.execute(requete_create_schema)
		#conn.commit()
		#curs.close()
		#conn.close()


	def function_truncate(cur,schema):

		liste_table_truncate=[\
			't_adresse','t_organisme','t_reference','t_noeud','t_znro','t_zsro','t_zpbo',\
			't_zdep','t_sitetech','t_ltech','t_baie','t_tiroir','t_equipement','t_suf',\
			't_ptech','t_ebp','t_cassette','t_cheminement','t_conduite','t_cond_chem',\
			't_masque','t_cable','t_cableline','t_cab_cond','t_love','t_fibre','t_position',\
			't_ropt','t_siteemission','t_document','t_docobj']

		cur.execute("""select schema_name
		from information_schema.schemata where schema_name ='"""+schema+"""'""")

		data_tab=cur.fetchall()
		if data_tab:
			for tab in liste_table_truncate:
				cur.execute('''Truncate table '''+schema+'.'+tab+ ''' CASCADE;''')
		else:
			function_create_schema(cur,schema)

		
	def function_get_field_insert(cur,table_name,schema):
			
		try:
			# Connect to an existing database
			# conn = psycopg2.connect(host=host, dbname=DB, user=user, password=MP)
			# # Open a cursor to perform database operations
			# cur = conn.cursor()
			# Requete pour recuperer les attributes de type date		

			requete_insert="\
				CREATE OR REPLACE FUNCTION get_schema_name(text, out text)\
					AS $$ SELECT $1 $$\
					LANGUAGE SQL;\
				CREATE OR REPLACE FUNCTION get_requete_insert(text) \
					RETURNS table (name_table text,name_colomn text,requete_insert text) AS\
				$BODY$\
				with create_attribut_by_position as (\
				select column_name as name_colomn ,table_name as name_table, table_schema as name_schema\
				from information_schema.columns\
				where\
					table_schema = (select get_schema_name($1)) and table_name like 't_%'  AND data_type not in ('timestamp without time zone','date') \
				order by ordinal_position, table_name )\
				select \
					name_table,\
					array_to_string(array_agg(name_colomn::text),','),\
					'INSERT INTO '||max(name_schema)||'.'||name_table||'('||array_to_string(array_agg(name_colomn::text),',')||') VALUES ('\
					||array_to_string(array_agg( case \
										when name_colomn = 'geom' and name_table in ('t_cheminement','t_cableline')\
											then  'ST_LineMerge(ST_GeomFromText(%s,2154))' \
										when name_colomn = 'geom' and name_table in ('t_adresse','t_noeud','t_empreinte','t_zcoax','t_zdep','t_znro','t_zpbo','t_zsro')\
											then  'ST_GeomFromText(%s,2154)'\
									else '%s' end::text),',')||')' as requete_insert\
				from create_attribut_by_position group by name_table\
				$BODY$\
				LANGUAGE sql VOLATILE;"
		   
			
			name_function='get_requete_insert'#select * from get_requete_insert('pr_4_10_deo')
			cur.execute(requete_insert)
			cur.callproc(name_function,[schema,])

					
			field_type_date=[list(row) for row in cur.fetchall()]
			#field_type
			list_table_name=[req[0] for req in field_type_date]# req[0] for req in field_type_date
			list_field_name=[]# req[1] for req in field_type_date
			list_requet_name=''#[req[2] for req in field_type_date]# req[2] for req in field_type_date
			list_global_name=[req for req in field_type_date]
			
			for j in list_global_name:
				if j[0] == table_name:#'t_cableline':
					var=j[1].split(",")
					for k in var:
						if k != 'geom':
							list_field_name.append(k)
					list_requet_name=j[2]
		
			return list_table_name,list_field_name,list_requet_name,list_global_name
			
		except (Exception, psycopg2.Error) as error:
			mes_error_insertion='Requete non executee {}'.format(error)
			QMessageBox.information(w, "Message-Erreur", mes_error_insertion)
			

	#Function pour recuperer lobjet deune couche a partir de son nom
	def function_getlayer_name(layer_name):
		layers =  [tree_layer.layer() for tree_layer in QgsProject.instance().layerTreeRoot().findLayers()]#Pyqgis3
		for layer in layers:
			layerType = layer.type()
			if layerType == QgsMapLayer.VectorLayer:
				if layer.name() == layer_name:
					return layer

	#Funciton de creations des noms des groups
	def function_create_groupe_name(name_groupe):
		root = QgsProject.instance().layerTreeRoot()
		group = root.findGroup(name_groupe)
		root.removeChildNode(group)
		shapeGroup = root.addGroup(name_groupe)
		return shapeGroup
		
	#Function pour ajouter les tables dans leur groupe respectif

	def function_add_layer_group(layer_to_add, groupe_name):
		QgsProject.instance().addMapLayer(layer_to_add,False)
		groupe_name.insertChildNode(0,QgsLayerTreeLayer(layer_to_add))

	def function_chargement_layer_qgis(path_folder):
		
		if path_folder:
			
			#Declaration des noms des groupes a travers la function de creatino des groups
			shape_group=function_create_groupe_name('SHAPE_GraceTHD')
			csv_group=function_create_groupe_name('CSV_GraceTHD')

			for file_etude in os.listdir(path_folder):
				chemin=path_folder
				name, ext = os.path.splitext(file_etude)
				chem_etude= chemin+'/'+file_etude
				if ext == ".shp":
					layer_shp_etude=QgsVectorLayer(chem_etude,name, 'ogr')
					function_add_layer_group(layer_shp_etude, shape_group)
				if ext == ".csv":
					layer_csv_etude=QgsVectorLayer(chem_etude,name, 'ogr')
					function_add_layer_group(layer_csv_etude, csv_group)
					#print (chemin,';',file_etude,';',chem_etude)

	def function_recup_entite_insert(layer_name,list_field_insert):
		
		list_field_name=[]
		list_field_attributes=[]
		dict_attribut_vide={}
		
		list_field_attributes_not_dupli=[]

		for layers_name_mapLayers in QgsProject.instance().mapLayers().values():
			#print (layers_name_mapLayers.geometryType())
			if layers_name_mapLayers.type() == QgsMapLayer.VectorLayer :#and layers_name_mapLayers.geometryType() in [QgsWkbTypes.PointGeometry,QgsWkbTypes.LineGeometry,QgsWkbTypes.PolygonGeometry]:
				layer = layers_name_mapLayers
				if layer.name() == layer_name:#'t_cableline': 
					filterFields = []
					#fields = list_field_insert#[]#[field.name() for field in layer.fields() if field.name() in list_field_insert]
					for feature in layer.getFeatures():
						geome_text=feature.geometry().asWkt()
						if geome_text:
							#print (geome_text,'shp')
							recup_tuple_attr = tuple(['NULL' if feature[field] in [NULL, '??'] else feature[field] for field in list_field_insert])
							attr_insert=recup_tuple_attr+(geome_text,)
							list_field_attributes.append(attr_insert)
						if not geome_text:
							#print (geome_text,'csv')
							recup_tuple_attr = tuple(['NULL' if feature[field] in ['', '??'] else feature[field] for field in list_field_insert])
							attr_insert=recup_tuple_attr
							list_field_attributes.append(attr_insert)
					
	#    for field_insert in list_field_attributes:
	#        if field_insert not in list_field_attributes_not_dupli:
	#            list_field_attributes_not_dupli.append(field_insert)
		
		return list_field_attributes#list_field_attributes_not_dupli


	#Function dinsertion des entites dans la base
	def bulkInsert(records,cursor,sql_insert_query):
		try:
			
			result = cursor.executemany(sql_insert_query, records)
			
		except (Exception, psycopg2.Error) as error:
			mes_error_insertion='Failed inserting record into mobile table {}'.format(error)
			#print("Failed inserting record into mobile table {}".format(error))
			QMessageBox.information(w, "Message-Erreur_Insertion", sql_insert_query+mes_error_insertion)
			
	#Function Suppression du group ajoute dans QGis
	def functiondelete_layer_qgis(name_groupe):
		root = QgsProject.instance().layerTreeRoot()
		group = root.findGroup(name_groupe)
		if group is not None:
			root.removeChildNode(group)
			
	#Execution chargement des tables
	function_chargement_layer_qgis(path_folder)
	#Filtre pour demander la creation du schema
	#function_create_schema(connection,schema)
	#Execution truncate table
	function_truncate(cur,schema)
			
	liste_table_insert=[\
			't_adresse','t_organisme','t_reference','t_noeud','t_znro','t_zsro','t_zpbo',\
			't_zdep','t_sitetech','t_ltech','t_baie','t_tiroir','t_equipement','t_suf',\
			't_ptech','t_ebp','t_cassette','t_cheminement','t_conduite','t_cond_chem',\
			't_masque','t_cable','t_cableline','t_cab_cond','t_love','t_fibre','t_position',\
			't_ropt','t_siteemission','t_document','t_docobj']

	#Execution des imports des tables
	for insert in liste_table_insert:
		
		name_table=insert#'t_cableline'
		
		list_field_insert=function_get_field_insert(cur,name_table,schema)[1]
		filterFields=function_recup_entite_insert(name_table,list_field_insert)
		list_insert_requete=function_get_field_insert(cur,name_table,schema)[2]
		bulkInsert(filterFields,cursor,list_insert_requete)

	#Execution des suppressions des couches charges dans qgis
	functiondelete_layer_qgis('SHAPE_GraceTHD')
	functiondelete_layer_qgis('CSV_GraceTHD')

	##finally:
	#        # closing database connection.
	if (connection):
		connection.commit()
		cursor.close()
		cur.close
		connection.close()
	QMessageBox.information(w, "Message-Execution-Plugin", 'Import des donnees termine')