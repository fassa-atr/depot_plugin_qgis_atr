import processing,xlrd,psycopg2,sys,xlwt,re
from qgis.PyQt.QtCore import *
from qgis.PyQt.QtGui import *
from qgis.core import * 
from qgis.utils import *
from qgis.PyQt.QtWidgets import *
import time
import datetime



# schema = 'pr_baba_2_2_exe_v_20251231'#'znro_rip16_exe_atr_model'#'pr_2_2_exe_v2_exe_v_20190930'#'pr_3_4_doe' pr_1_1_doe_v2
# client='INEO'#'SOBECA'
# stat_etude='AVP'

# sheet_mcd_attribut='MCD_Attributs'#'test_f'#
# sheet_mcd_table='MCD_Classes'

# sheet_mcd_attribut_column_name_attribut = 'Nom court de lattribut'
# sheet_mcd_table_column_name_table = 'Nom de la table'

# sheet_mcd_attribut_column_name_status = 'MCO'#'DEo'
# #sheet_mcd_table_column_name_status = 'DEXE'


def function_formalisme_mcd(schema,client,stat_etude,
	sheet_mcd_attribut,
	sheet_mcd_table,
	sheet_mcd_attribut_column_name_attribut,
	sheet_mcd_table_column_name_table,
	sheet_mcd_attribut_column_name_status):

	#Parameter connexion base
	DB = 'MCD_ADN_sans_ct'#'gracethd_adn'#'MCD_ADN_sans_ct'
	user = 'postgres'
	MP = 'postgres'#'MYPASSWORD'#'postgres'
	host = '192.168.30.218'#'localhost'#'192.168.30.218'
	port = '5432'#'5439'#'5432'


	#Connexion a la base
	try:
		connection = psycopg2.connect(user=user,password=MP,host=host,port=port,database=DB)
	except(Exception, psycop2.DatabaseError) as error:
		QMessageBox.warning(w, "Message de connexion de la base", 'Erreur de connexion de la base')

	#Declaration de la variable pour les messages derreur
	w = QWidget()

	#Function pour la progession bar1
	def progress_bar(name_etape):
		prog = QProgressDialog(name_etape + ' : Veillez Patienter', 'Cancel', 0, 100)
		prog.setWindowModality(Qt.WindowModal)
		prog.setMinimumDuration(1)
		return prog
		
	#Function pour la progession bar2
	def progress_processing(index,count_entite,progress_dialog):
		f = int(index + 1)
		pcnt = int(f/count_entite * 100/1)
		progress_dialog.setValue(pcnt)
		
	#Function pour executer une requete sql dans la base
	def function_execute_requete(requete_execute,req_fetch,connection):
		curs=connection.cursor()
		try:
			curs.execute(requete_execute)
			if req_fetch:
				data_req=[row for row in curs.fetchall()]
				if data_req:
					return data_req
		except(Exception, psycopg2.DatabaseError) as error:
			QMessageBox.warning(w, "Message dexecution de requete", 'Requete Non Executer : '+unicode(requete_execute))
		curs.close()

	#Function pour verification des digits
	def function_verif_digit(list_value):
		res='False'
		req_expres = r'[0-9][0-9]+$'
		res_req_expres=bool(re.match(req_expres, str(list_value)))
		if res_req_expres == True:
			res='True'
		return res

	#Controle function_adresse
	list_plage_codage=[]

	#Liste_error 
	listing_error_control_ADN=[]
	now = datetime.datetime.now().strftime("%y%m%d")
	prefix_id_error='AUD_'


	#Creation table des plages des identifiants
	create_tab_plage_identifiant="""DROP TABLE if exists """+schema+""".plage_identifiant;
		CREATE TABLE """+schema+""".plage_identifiant
		(
		  name_entreprise text,
		  num_name_entreprise text,
		  ad_code_debut text,
		  ad_code_fin text,
		  cm_r2_code_debut text,
		  cm_r2_code_fin text,
		  cb_etiquet_not_col_debut text,
		  cb_etiquet_not_col_fin text,
		  cb_etiquet_col_debut text,
		  cb_etiquet_col_fin text,
		  pt_etiquet_debut text,
		  pt_etiquet_fin text,
		  bp_etiquet_debut text,
		  bp_etiquet_fin text,
		  zd_r5_code_debut text,
		  zd_r5_code_fin text,
		  do_code_debut text,
		  do_code_fin text  
		);
		CREATE INDEX index_plage_identifiant ON """+schema+""".plage_identifiant
		  USING btree (num_name_entreprise COLLATE pg_catalog."default");
		INSERT INTO """+schema+""".plage_identifiant(
					name_entreprise, num_name_entreprise, ad_code_debut, ad_code_fin, 
					cm_r2_code_debut, cm_r2_code_fin, cb_etiquet_not_col_debut, cb_etiquet_not_col_fin, 
					cb_etiquet_col_debut, cb_etiquet_col_fin, pt_etiquet_debut, pt_etiquet_fin, 
					bp_etiquet_debut, bp_etiquet_fin, zd_r5_code_debut, zd_r5_code_fin, 
					do_code_debut, do_code_fin)
			VALUES 
			('ADTIM FTTH',0, null,null,0001, 0999, 0001, 0999, 00001, 09999, 0001, 0999, 0001, 0999, 0001, 0999,null,null),
			('EIFFAGE', 1, 600000, 649999, 1000, 1999, 1000, 1999, 10000, 19999, 1000, 1999, 1000, 1999, 1000, 1999, 100000000000, 149999999999),
			('INEO', 2, 650000, 699999, 2000, 2999, 2000, 2999, 20000, 29999, 2000, 2999, 2000, 2999, 2000, 2999, 150000000000, 199999999999),
			('SOBECA', 3, 700000, 749999, 3000, 3999, 3000, 3999, 30000, 39999, 3000, 3999, 3000, 3999, 3000, 3999, 200000000000, 249999999999),
			('IMOPTEL', 4, 750000, 799999, 4000, 4999, 4000, 4999, 40000, 49999, 4000, 4999, 4000, 4999, 4000, 4999, 250000000000, 299999999999),
			('SERFIM TIC', 5, 800000, 849999, 5000, 5999, 5000, 5999, 50000, 59999, 5000, 5999, 5000, 5999, 5000, 5999, 300000000000, 399999999999),
			('Attributaire suivant', null,850000, 899999, 6000, 6999, 6000, 6999, 60000, 69999, 6000, 6999, 6000, 6999, 6000, 6999, 350000000000, 439999999999),
			('Attributaire suivant', null,900000, 949999, 7000, 7999, 7000, 7999, 70000, 79999, 7000, 7999, 7000, 7999, 7000, 7999, 400000000000, 499999999999),
			('Attributaire suivant', null,950000, 999999, 8000, 8999, 8000, 8999, 80000, 89999, 8000, 8999, 8000, 8999, 8000, 8999, 450000000000, 559999999999),
			('ADN', 9, null,null,9000, 9999, 9000, 9999, 90000, 99999, 9000, 9999, 9000, 9999, 9000, 9999, null,null)"""

	execute_create_tab_plage_identifiant=function_execute_requete(create_tab_plage_identifiant,'',connection)
	reque_select_plage_identifiant="""select * from """+schema+""".plage_identifiant"""
	list_req_plage_identifiant=function_execute_requete(reque_select_plage_identifiant,'bab',connection)

	def function_adresse_S02():
		bar_progress=progress_bar('Execution de la function_adresse_S02')
		
		#Controler ad_code
		req_adcode="""select ad_code, ad_batcode,st_astext(st_buffer(geom, 0.5)) as geom from """+schema+""".t_adresse"""
		list_adresse=function_execute_requete(req_adcode,'bab',connection)
		#ad_bat_code
		
		if list_adresse:
			for index_S02, S02 in enumerate(list_adresse):
				bonne_plage='False'
				bonne_longueur_ad_code='False'
				bonne_longueur_ad_batcode='False'
				bonne_type_ad_batcode='False'
				bonne_dep_ad_batcode='False'
				geom=S02[-1]
				for index_plage, plage in enumerate(list_req_plage_identifiant):
					if plage[0] == str(client).upper():
						if geom:
							if S02[0]:#ad_code non vide
								longueur_ad_code=len(S02[0])#get Longueur pour ad_code
								plage_entreprise=S02[0][8:]#Plage entreprise pour ad_code
								plage_entreprise_num=S02[0][8:9]##Plage entreprise
								#Plage ad_code en dehors de la plage entreprise
								if int(plage_entreprise) >= int(plage[2]) or int(plage_entreprise) <= int(plage[3]) :#== plage_entreprise_num:
									bonne_plage='True'
								if longueur_ad_code == 14:#check longueur ad_code
									   #print(S02[0],';',S02[1],';',longueur_ad_code,';',plage_entreprise)
									   bonne_longueur_ad_code='True'
							if S02[1]:#ad_batcode non vide
								longueur_ad_batcode=len(S02[1])#get longueur ad_batcode
								type_ad_batcode=S02[1][:3]#get type adresse
								dep_ad_batcode=S02[1][3:5]#get departement
								if longueur_ad_batcode == 20:#check longueur ad_batcode
									bonne_longueur_ad_batcode='True'
								if type_ad_batcode in ('PAV','IMM'):#check type adresse
									bonne_type_ad_batcode='True'
								if len(dep_ad_batcode) == 2:#check departement
									bonne_dep_ad_batcode=function_verif_digit(dep_ad_batcode)
				if bonne_plage=='False' or bonne_longueur_ad_code=='False' or bonne_longueur_ad_batcode=='False' or \
					bonne_type_ad_batcode=='False' or bonne_dep_ad_batcode=='False':
						message_02='Incoherence de nommage ou de plage pour ad_code ou ad_batcode'
						if geom:
							listing_error_control_ADN.append([geom,message_02,S02[0]])
						#print(S02[0],';',S02[1],';',bonne_plage,';',bonne_longueur_ad_code,';',bonne_longueur_ad_batcode,';',bonne_type_ad_batcode,';',bonne_dep_ad_batcode)
							#listing_error_control_ADN.append([geom,message_B05_1])
				progress_processing(index_S02,len(list_adresse),bar_progress)
				if bar_progress.wasCanceled():
					iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
					break
	#Execution function_adresse
	function_adresse_S02()
	#Controle function_ptech
	def function_ptech_s03():
		bar_progress=progress_bar('Execution de la function_ptech_s03')
		req_pt_etiquet="""select pt.pt_code, pt.pt_etiquet,st_astext(st_buffer(nd.geom, 0.5)),pt.pt_statut as geom 
			from """+schema+""".t_ptech pt
			left join """+schema+""".t_noeud nd on nd.nd_code = pt.pt_nd_code"""
		list_pt_etiquet=function_execute_requete(req_pt_etiquet,'bab',connection)
		for index_pt_etiquet, s03_etiquet in enumerate(list_pt_etiquet):
			bonne_plage='False'
			bonne_type_pt='False'
			bonne_code_inseee='False'
			bonne_code_gestion='False'
			bonne_code_increment='False'
			bonne_status='False'
			geom=s03_etiquet[2]
			for index_plage, plage in enumerate(list_req_plage_identifiant):
				if plage[0] == str(client).upper():
					if geom and s03_etiquet[1]:
						type_pt=s03_etiquet[1][:3]#type pt
						code_insee=s03_etiquet[1][4:9]#code departement
						code_gestion=s03_etiquet[1][10:12]#code gestionnaire (FT,BT,HT,DA,AD,EP)
						code_increment=s03_etiquet[1][13:]#code increment
						if type_pt in ('CHB', 'POT', 'RAS', 'AUT'):#check type pt
							bonne_type_pt='True'
						if len(code_insee) == 5:#check code insee
							bonne_code_inseee=function_verif_digit(code_insee)
						if len(code_gestion) == 2 and code_gestion in ('FT','BT','HT','DA','AD','EP'):#check code gestion
							bonne_code_gestion='True'
						if (len(code_increment) == 4 and function_verif_digit(code_increment) == 'True') and type_pt in ('POT', 'RAS', 'AUT','CHB') \
							and code_gestion in ('BT','HT','DA','AD','EP','FT'):#check code increment
								bonne_code_increment='True'
								if int(code_increment) >= int(plage[10]) or int(code_increment) <= int(plage[11]) :#check plage entreprise
									bonne_plage='True'
						elif len(code_increment) != 4 and type_pt in ('POT','CHB') and code_gestion in ('FT'):#check plage entreprise
								bonne_code_increment='True'
								bonne_plage='True'
			if s03_etiquet[3] == stat_etude:#check statut
				bonne_status='True'
			if bonne_plage=='False'or bonne_type_pt=='False' or bonne_code_inseee=='False'\
				or bonne_code_gestion=='False'or bonne_code_increment=='False' or bonne_status=='False':
				message_03='Incoherence de nommage ou de plage ou de status pour pt_etiquet'
				if geom:
					listing_error_control_ADN.append([geom,message_03,s03_etiquet[1]])
	#            print (s03_etiquet[0],';',s03_etiquet[1],\
	#            ';',bonne_plage,';',bonne_type_pt,';',bonne_code_inseee,\
	#            ';',bonne_code_gestion,';',bonne_code_increment,';',bonne_status)
			progress_processing(index_pt_etiquet,len(list_pt_etiquet),bar_progress)
			if bar_progress.wasCanceled():
				iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
				break
	#Execution function_ptech_s03
	function_ptech_s03()
	#Controle function_boite
	def function_boite_S04():
		bar_progress=progress_bar('Execution de la function_boite_S04')
		req_bp_etiquet="""select bp.bp_code, bp.bp_etiquet,st_astext(st_buffer(nd.geom, 0.5)) as geom ,bp.bp_statut
			from """+schema+""".t_ebp bp
			left join """+schema+""".t_ptech pt on pt.pt_code = bp.bp_pt_code
			left join """+schema+""".t_noeud nd on nd.nd_code = pt.pt_nd_code"""#left  left 
		list_bp_etiquet=function_execute_requete(req_bp_etiquet,'bab',connection)
		for index_bp_etiquet, s04_etiquet in enumerate(list_bp_etiquet):
			bonne_plage='False'
			bonne_type_bp='False'
			bonne_code_dep='False'
			bonne_code_pmt='False'
			bonne_code_increment='False'
			bonne_status='False'
			geom=s04_etiquet[2]
			for index_plage, plage in enumerate(list_req_plage_identifiant):
				if plage[0] == str(client).upper():
					if geom and s04_etiquet[1]:
						type_bp=s04_etiquet[1][:3]#type boite
						code_dep=s04_etiquet[1][3:5]#code departement
						code_pmt=s04_etiquet[1][6:10]#code PMT
						code_increment=s04_etiquet[1][11:]#code increment
						if type_bp in ('BPE', 'PBO', 'BFI'):#check type boite
							bonne_type_bp='True'  
						if len(code_dep) == 2:#check code departement
							bonne_code_dep=function_verif_digit(code_dep)
						if len(code_pmt) == 4 :#check code PMT
							bonne_code_pmt='True'
						if len(code_increment) == 4 :#check code increment
								if int(code_increment) >= int(plage[12]) or int(code_increment) <= int(plage[13]) :#check plage entreprise
									bonne_plage='True'
									bonne_code_increment='True'
									#print (type_bp,';',code_dep,';',code_pmt,';',code_increment,';',bonne_code_increment)
			if s04_etiquet[3] == stat_etude:#check statut
				bonne_status='True'
			if bonne_plage=='False'or bonne_type_bp=='False' or bonne_code_dep=='False'\
				or bonne_code_pmt=='False'or bonne_code_increment=='False' or bonne_status=='False':
				message_04='Incoherence de nommage ou de plage ou de status pour bp_etiquet'
				if geom:
					listing_error_control_ADN.append([geom,message_04,s04_etiquet[1]])
	#                print (s04_etiquet[0],';',s04_etiquet[1],\
	#                ';',bonne_plage,';',bonne_type_bp,';',bonne_code_dep,\
	#                ';',bonne_code_pmt,';',bonne_code_increment,';',bonne_status)
			progress_processing(index_bp_etiquet,len(list_bp_etiquet),bar_progress)
			if bar_progress.wasCanceled():
				iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
				break
	#Execution function_boite_S04
	function_boite_S04()
	#Controle function_cheminement
	def function_cheminement_S05():
		bar_progress=progress_bar('Execution de la function_cheminement_S05')
		req_chem="""select cm.cm_code, cm.cm_r2_code,cm.cm_avct,cm.cm_etat,st_astext(st_buffer(cm.geom, 0.5)) as geom
			from """+schema+""".t_cheminement cm where cm.cm_avct = 'C'"""
		list_chem=function_execute_requete(req_chem,'bab',connection)
		for index_chem, chem in enumerate(list_chem):
			bonne_plage='False'
			bonne_type_cm='False'
			bonne_code_insee='False'
			bonne_code_increment='False'
			bonne_status='False'
			geom=chem[-1]
			for index_plage, plage in enumerate(list_req_plage_identifiant):
				if plage[0] == str(client).upper():
					if geom and chem[1]:
						type_cm=chem[1][:3]#type boite
						code_insee=chem[1][3:8]#code departement
						code_increment=chem[1][9:]#code increment
						if type_cm in ('TRA', 'AER', 'FAC') and chem[2] == 'C':#check type boite
							bonne_type_cm='True'  
						if len(code_insee) == 5:#check code departement
							bonne_code_insee=function_verif_digit(code_insee)
						if len(code_increment) == 4 and function_verif_digit(code_increment) == 'True':#check code increment
								if int(code_increment) >= int(plage[4]) or int(code_increment) <= int(plage[5]) :#check plage entreprise
									bonne_plage='True'
									bonne_code_increment='True'
									#print (type_bp,';',code_dep,';',code_pmt,';',code_increment,';',bonne_code_increment)
			if chem[3] == stat_etude:#check statut
				bonne_status='True'
			if bonne_plage=='False'or bonne_type_cm=='False' or bonne_code_insee=='False'\
				or bonne_code_increment=='False' or bonne_status=='False':
				message_05='Incoherence de nommage ou de plage ou de status pour cm_r_2_code a créer'
				if geom:
					listing_error_control_ADN.append([geom,message_05,chem[1]])
	#                print (chem[0],';',chem[1],\
	#                ';',bonne_plage,';',bonne_type_cm,';',bonne_code_insee,\
	#                ';',bonne_code_increment,';',bonne_status)
			progress_processing(index_chem,len(list_chem),bar_progress)
			if bar_progress.wasCanceled():
				iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
				break
	#Execution function_cheminement_S05
	function_cheminement_S05()
	#Controle function_cable
	def function_cable_S07(stat_etude):
		bar_progress=progress_bar('Execution de la function_cable_S07')
		req_cable="""select cb.cb_code, cb.cb_etiquet,cb.cb_statut,cb.cb_nd1,cb.cb_nd2,st_astext(st_buffer(cl.geom, 0.5)) as geom
			from """+schema+""".t_cable cb
			left join """+schema+""".t_cableline cl on cl.cl_cb_code = cb.cb_code"""
		list_cable=function_execute_requete(req_cable,'bab',connection)
		for index_cable, cable in enumerate(list_cable):
			bonne_plage='False'
			bonne_type_cb='False'
			bonne_code_dep='False'
			bonne_code_pmt='False'
			bonne_code_increment='False'
			bonne_status='False'
			bonne_codage_rac='False'
			bonne_codage_col='False'
			geom=cable[-1]
			for index_plage, plage in enumerate(list_req_plage_identifiant):
				if plage[0] == str(client).upper():
					if geom and cable[1]:
						type_cb=cable[1][:3]#type boite
						code_dep=cable[1][3:5]#code departement
						code_pmt=cable[1][6:10]#code PMT
						code_increment=cable[1][11:]#code increment
						if type_cb in ('CFI', 'CDI', 'CTR'):#check type cable Distribution, transport et cable fictifs
							bonne_type_cb='True'  
							if len(code_dep) == 2:#check code departement
								bonne_code_dep=function_verif_digit(code_dep)
							if len(code_pmt) == 4 :#check code PMT
								bonne_code_pmt='True'
							if len(code_increment) == 4 and function_verif_digit(code_increment) == 'True':#check code increment
									if int(code_increment) >= int(plage[6]) or int(code_increment) <= int(plage[7]) :#check plage entreprise
										bonne_plage='True'
										bonne_code_increment='True'
										
						if type_cb in ('CDA', 'CFI'):#check cable raccordement
							bonne_type_cb='True'
							bigramme_rip=cable[1][6:8]#bigramme rip
							code_pmt_rac=cable[1][9:13]#code PMT
							code_increment_rac=cable[1][14:]#code increment
							if len(code_dep) == 2:#check code departement
								bonne_code_dep=function_verif_digit(code_dep)
							if len(code_pmt_rac) == 4 :#check code PMT
								bonne_code_pmt='True'
							if len(bigramme_rip) == 2 and len(code_increment_rac) == 4 and function_verif_digit(code_increment_rac) == 'True':#check code PMT, bigramme and increment
								if int(code_increment_rac) >= int(plage[6]) or int(code_increment_rac) <= int(plage[7]) :#check plage entreprise
									bonne_plage='True'
									bonne_code_increment='True'
						
						if type_cb == 'CAB' and len(code_dep) == 2:#check cable collecte
							bonne_type_cb='True'
							code_increment_col=cable[1][-4:]#code increment
							if len(code_dep) == 2:#check code departement
								bonne_code_dep=function_verif_digit(code_dep)
							if len(code_increment_col) == 5 and function_verif_digit(code_increment_col) == 'True':
								if int(code_increment_col) >= int(plage[8]) or int(code_increment_col) <= int(plage[9]) :#check plage entreprise
									bonne_plage='True'
									bonne_code_increment='True'
								#print (cable[1],';',type_cb,';',bigramme_rip,';',code_pmt_rac,';',code_increment_col)
			if cable[2] == stat_etude:#check statut
				bonne_status='True'
			if cable[1]:
				if (bonne_plage=='False'or bonne_type_cb=='False' or bonne_code_dep=='False'\
					or bonne_code_increment=='False' or bonne_status=='False'):# or bonne_codage_col == 'False' or bonne_codage_rac =='False':
					message_07='Incoherence de nommage ou de plage ou de status pour les cables'
					if geom:
						listing_error_control_ADN.append([geom,message_07,cable[1]])
	#                    print (cable[0],';',cable[1],\
	#                    ';',bonne_plage,';',bonne_type_cb,';',bonne_code_dep,\
	#                    ';',bonne_code_pmt,';',bonne_code_increment,';',bonne_status)#,';',bonne_codage_col,';',bonne_codage_rac
			progress_processing(index_cable,len(list_cable),bar_progress)
			if bar_progress.wasCanceled():
				iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
				break
	#Execution function_cable_S07
	function_cable_S07(stat_etude)
	#Controle function_fibre
	def function_fibre():
		pass
	#Controle function_sitetech
	def function_sitetech_S10():
		bar_progress=progress_bar('Execution de la function_sitetech_s10')
		req_st_nom="""select st.st_code, st.st_nom,st_astext(st_buffer(nd.geom, 0.5)),st.st_statut as geom, st.st_typephy 
			from """+schema+""".t_sitetech st
			left join """+schema+""".t_noeud nd on nd.nd_code = st.st_nd_code"""
		list_st_nom=function_execute_requete(req_st_nom,'bab',connection)
		for index_st_nom, s10_st_nom in enumerate(list_st_nom):
			bonne_type_st='False'
			bonne_code_inseee='False'
			bonne_code_increment='False'
			bonne_status='False'
			geom=s10_st_nom[2]
			
			if s10_st_nom[4] == 'ADR':
				bonne_type_st='ADR'
			elif s10_st_nom[4] == 'BAT':
				bonne_type_st='LT'
			elif s10_st_nom[4] == 'SHE':
				bonne_type_st='SHL'
				
			if geom and s10_st_nom[1]:
				if bonne_type_st == 'ADR':
					bonne_code_inseee = function_verif_digit(s10_st_nom[1][4:9])
				elif bonne_type_st == 'LT':
					bonne_code_inseee = function_verif_digit(s10_st_nom[1][3:8])
				elif bonne_type_st == 'SHL':
					bonne_code_inseee = function_verif_digit(s10_st_nom[1][4:9])
				if len(s10_st_nom[1][-4:]) == 4:
					bonne_code_increment=s10_st_nom[1][-4:]#code increment
			
			if s10_st_nom[3] == stat_etude:#check statut
				bonne_status='True'
			if bonne_type_st=='False' or bonne_code_inseee=='False'\
				or bonne_code_increment=='False' or bonne_status=='False':
				message_10='Incoherence de nommage ou de plage ou de status pour st_nom'
				if geom:
					listing_error_control_ADN.append([geom,message_10,s10_st_nom[1]])
	#                print (s10_st_nom[0],';',s10_st_nom[1],\
	#                ';',bonne_type_st,';',bonne_code_inseee,\
	#                ';',bonne_code_increment,';',bonne_status)
			progress_processing(index_st_nom,len(list_st_nom),bar_progress)
			if bar_progress.wasCanceled():
				iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
				break
	function_sitetech_S10()
	#Controle function_ltech
	def function_ltech_s11():
		bar_progress=progress_bar('Execution de la function_sitetech_s11')
		req_lt_etiquet="""select lt.lt_code, lt.lt_etiquet,st_astext(st_buffer(nd.geom, 0.5)),lt.lt_statut, st.st_typephy
			from """+schema+""".t_ltech lt
				left join """+schema+""".t_sitetech st on lt.lt_st_code = st.st_code
				left join """+schema+""".t_noeud nd on nd.nd_code = st.st_nd_code"""
		list_lt_etiquet=function_execute_requete(req_lt_etiquet,'bab',connection)

		for index_lt_etiquet, s11_lt_etiquet in enumerate(list_lt_etiquet):
			bonne_type_st='False'
			bonne_code_inseee='False'
			bonne_code_increment='False'
			bonne_status='False'
			geom=s11_lt_etiquet[2]
			
			if s11_lt_etiquet[1][:3] == 'NRO':
				bonne_type_st='NRO'
				#print (bonne_type_st,';',s11_lt_etiquet[1])
			elif s11_lt_etiquet[1][:3] == 'PMT':
				bonne_type_st='PMT'
				
			if geom and s11_lt_etiquet[1]:
				bonne_code_inseee = function_verif_digit(s11_lt_etiquet[1][4:9])
				if len(s11_lt_etiquet[1][-4:]) == 4:
					bonne_code_increment=s11_lt_etiquet[1][-4:]#code increment
			
			if s11_lt_etiquet[3] == stat_etude:#check statut
				bonne_status='True'
			if bonne_type_st=='False' or bonne_code_inseee=='False'\
				or bonne_code_increment=='False' or bonne_status=='False':
				message_11='Incoherence de nommage ou de plage ou de status pour lt_etiquet'
				if geom:
					listing_error_control_ADN.append([geom,message_11,s11_lt_etiquet[1]])
	#                print (s11_lt_etiquet[0],';',s11_lt_etiquet[1],\
	#                ';',bonne_type_st,';',bonne_code_inseee,\
	#                ';',bonne_code_increment,';',bonne_status)
			progress_processing(index_lt_etiquet,len(list_lt_etiquet),bar_progress)
			if bar_progress.wasCanceled():
				iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
				break
	function_ltech_s11()
	#Controle function_baie
	def function_baie():
		pass
	#Controle function_tiroir
	def function_tiroir():
		pass
	#Controle function_zpbo
	def function_zpbo_s14():
		bar_progress=progress_bar('Execution de la function_sitetech_s14')
		req_zp_boite="""SET search_path = """+schema+""", public;
			select zp.zp_code, zp.zp_r2_code, zp.zp_r3_code, zp.zp_r4_code,st_astext(st_buffer(zp.geom, 0.5)),zn.zn_nroref,zs.zs_r3_code,bp.bp_etiquet---, zp.zp_nd_code,st.st_nom,r3_code.st_nom as zp_r3_code,lt.lt_etiquet
				from t_zpbo zp
			left join t_znro zn on (zp.zp_r2_code = zn.zn_nroref)
			left join t_zsro zs on (zp.zp_r3_code = zs.zs_r3_code and zs.zs_code=zp.zp_zs_code)
			left join t_ebp bp on (zp.zp_r4_code = bp.bp_etiquet)"""
		
		list_zp_boite=function_execute_requete(req_zp_boite,'bab',connection)
		if list_zp_boite:
			for index_zp_boite, s14_zp_boite in enumerate(list_zp_boite):
				bonne_zp_r2_code='False'
				bonne_zp_r3_code='False'
				bonne_zp_r4_code='False'
				geom=s14_zp_boite[4]
				
				if s14_zp_boite[5]:
					bonne_zp_r2_code='True'
				
				if s14_zp_boite[6]:
					bonne_zp_r3_code='True'
				
				if s14_zp_boite[7]:
					bonne_zp_r4_code='True'
				
				concate_code=str(s14_zp_boite[5]) + '_' + str(s14_zp_boite[6]) + '_' + str(s14_zp_boite[7])

				if bonne_zp_r2_code == 'False' or bonne_zp_r3_code == 'False' or bonne_zp_r4_code == 'False':
					message_14='Incoherence de nommage zp_r2_code ou zp_r3_code or zp_r4_cod pour zpbo'
					if geom:
						listing_error_control_ADN.append([geom,message_14,concate_code])
	#                    print (s14_zp_boite[0],';',s14_zp_boite[1],\
	#                    ';',bonne_zp_r2_code,';',bonne_zp_r3_code,';',bonne_zp_r4_code)
				progress_processing(index_zp_boite,len(list_zp_boite),bar_progress)
				if bar_progress.wasCanceled():
					iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
					break
		
		req_zp_coh_geom="""SET search_path = """+schema+""", public;
			WITH
			conf as
				(select '0.0'::float as tol),		
			zpb as
				(select zp.zp_code as zpb_code, ST_Buffer(zp.geom, conf.tol) as geom
					from t_zpbo as zp, conf)
			SELECT  distinct
				zp1.zp_code,st_astext(st_buffer(zp1.geom, 0.5))
			from   t_zpbo as zp1 
				LEFT JOIN zpb as zpb2 ON zp1.zp_code <> zpb2.zpb_code
			where  (ST_overlaps (zp1.geom, zpb2.geom) or ST_equals(zp1.geom, zpb2.geom));"""
		list_zp_req_coh_geom=function_execute_requete(req_zp_coh_geom,'bab',connection)
		if list_zp_req_coh_geom:
			for index_zp_coh_geom, s14_zp_coh_geom in enumerate(list_zp_req_coh_geom):
				geom=s14_zp_coh_geom[1]
				if geom:
					message_14_2='Incoherence de topologie superposee pour zpbo'
					listing_error_control_ADN.append([geom,message_14_2,s14_zp_coh_geom[0]])
	#                    print (s14_zp_coh_geom[0],';',s14_zp_coh_geom[1])
				progress_processing(index_zp_coh_geom,len(list_zp_req_coh_geom),bar_progress)
				if bar_progress.wasCanceled():
					iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
					break
	function_zpbo_s14()
	#Controle function_zdep
	def function_zdep_s06():
		
		def function_return_plage(var_code_insee_type,code_increment):
			if len(var_code_insee_type) == 5 and function_verif_digit(var_code_insee_type) == 'True' and function_verif_digit(code_increment) == 'True':
				if int(code_increment) >= int(plage[14]) and int(code_increment) <= int(plage[15]) :#check plage entreprise
					bonne_zd_plage='True'
					return bonne_zd_plage
					
		bar_progress=progress_bar('Execution de la function_zdep')
		req_zd_dep="""SET search_path = """+schema+""", public;
			select zd.zd_code, zd.zd_nd_code,zd.zd_r1_code,zd.zd_r2_code,zd.zd_r3_code,
			zd.zd_r4_code,zd.zd_r5_code,zd.zd_statut,st_astext(st_buffer(zd.geom, 0.5)) 
			from t_zdep zd"""
		list_zd_dep=function_execute_requete(req_zd_dep,'bab',connection)
		if list_zd_dep:
			for index_zd_dep, s06_zd_dep in enumerate(list_zd_dep):
				bonne_zd_type='False'
				bonne_zd_statut='False'
				bonne_zd_plage='False'
				geom=s06_zd_dep[-1]
				
				for index_plage, plage in enumerate(list_req_plage_identifiant):
					if plage[0] == str(client).upper() and (s06_zd_dep[6] and s06_zd_dep[5]):
						
						code_increment=s06_zd_dep[6][-4:]
						if s06_zd_dep[6][:3]=='ZIP' and s06_zd_dep[6][:3] == s06_zd_dep[5]:
							bonne_zd_type='True'
							code_insee_ZIP=s06_zd_dep[6][4:9]
							bonne_zd_plage=function_return_plage(code_insee_ZIP,code_increment)
									
						elif s06_zd_dep[6][:4]=='ZIPE' and s06_zd_dep[6][:4] == s06_zd_dep[5]:
							bonne_zd_type='True'
							code_insee_ZIPE=s06_zd_dep[6][5:10]
							bonne_zd_plage=function_return_plage(code_insee_ZIPE,code_increment)
							
						elif s06_zd_dep[6][:2]=='ZI' and s06_zd_dep[6][:2] == s06_zd_dep[5]:
							bonne_zd_type='True'
							code_insee_ZI=s06_zd_dep[6][3:8]
							bonne_zd_plage=function_return_plage(code_insee_ZI,code_increment)
									
						elif s06_zd_dep[6][:4] == 'ZPLU' and s06_zd_dep[6][:4] == s06_zd_dep[5]:
							bonne_zd_type='True'
							code_insee_ZPLU=s06_zd_dep[6][5:10]
							bonne_zd_plage=function_return_plage(code_insee_ZPLU,code_increment)

				if bonne_zd_statut == stat_etude:
					bonne_zd_statut='True'
					
				if bonne_zd_type=='False' or bonne_zd_statut=='False' or bonne_zd_plage=='False':
					message_s06='Incoherence de nommage ou de plage ou de status pour zd_dep'
					if geom:
						listing_error_control_ADN.append([geom,message_s06,s06_zd_dep[6]])
					#print (bonne_zd_type,';',bonne_zd_statut,';',bonne_zd_plage,';',s06_zd_dep[0])
				progress_processing(index_zd_dep,len(list_zd_dep),bar_progress)
				if bar_progress.wasCanceled():
					iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
					break
	function_zdep_s06()
	#Controle function_zsro
	def function_zsro_s13():
		
		bar_progress=progress_bar('Execution de la function_sitetech_s13')
		req_zs_r2_code="""select zs.zs_code, zs.zs_r2_code,st_astext(st_buffer(zs.geom, 0.5)), zs.zs_nd_code,st.st_nom,r3_code.st_nom as zs_r3_code,lt.lt_etiquet
			from """+schema+""".t_zsro zs
				left join """+schema+""".t_sitetech st on (zs.zs_r2_code = st.st_nom and zs.zs_nd_code = st.st_nd_code)
				left join """+schema+""".t_sitetech r3_code on (zs.zs_r3_code = r3_code.st_nom and zs.zs_nd_code = r3_code.st_nd_code)
				left join """+schema+""".t_ltech lt on (zs.zs_refpm = lt.lt_etiquet)"""
		list_zs_r2_code=function_execute_requete(req_zs_r2_code,'bab',connection)
		if list_zs_r2_code:
			for index_zs_r2_code, s13_zs_r2_code in enumerate(list_zs_r2_code):
				bonne_zs_r2_code='False'
				bonne_zs_r3_code='False'
				bonne_zs_refpm='False'
				geom=s13_zs_r2_code[2]
				
				if s13_zs_r2_code[4]:
					bonne_zs_r2_code='True'
				
				if s13_zs_r2_code[5]:
					bonne_zs_r3_code='True'
				
				if s13_zs_r2_code[6]:
					bonne_zs_refpm='True'
				
				concate_code=str(s13_zs_r2_code[4]) + '_' + str(s13_zs_r2_code[5]) + '_' + str(s13_zs_r2_code[6])

				if bonne_zs_r2_code == 'False' or bonne_zs_r3_code == 'False' or bonne_zs_refpm == 'False':
					message_13='Incoherence de nommage pour zs_r2_code ou zs_r3_code ou zs_refpm'
					if geom:
						listing_error_control_ADN.append([geom,message_13,concate_code])
	#                    print (s13_zs_r2_code[0],';',s13_zs_r2_code[1],\
	#                    ';',bonne_zs_r2_code,';',bonne_zs_r3_code,';',bonne_zs_refpm)
				progress_processing(index_zs_r2_code,len(list_zs_r2_code),bar_progress)
				if bar_progress.wasCanceled():
					iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
					break
			
		req_zs_coh_geom="""SET search_path = """+schema+""", public;
			WITH
			conf as
				(select '0.0'::float as tol),		
			znb as
				(select zn.zs_code as znb_code, ST_Buffer(zn.geom, conf.tol) as geom
					from t_zsro as zn, conf)
			SELECT  distinct
				zn1.zs_code,st_astext(st_buffer(zn1.geom, 0.5))
			from   t_zsro as zn1 
				LEFT JOIN znb as znb2 ON zn1.zs_code <> znb2.znb_code
			where  (ST_overlaps (zn1.geom, znb2.geom) or ST_equals(zn1.geom, znb2.geom));"""
		list_zs_req_coh_geom=function_execute_requete(req_zs_coh_geom,'bab',connection)
		if list_zs_req_coh_geom:
			for index_zs_coh_geom, s14_zs_coh_geom in enumerate(list_zs_req_coh_geom):
				geom=s14_zs_coh_geom[1]
				if geom:
					message_13_2='Incoherence de topologie superposee pour zsro'
					listing_error_control_ADN.append([geom,message_13_2,s14_zs_coh_geom[0]])
	#                    print (s14_zs_coh_geom[0],';',s14_zs_coh_geom[1])
				progress_processing(index_zs_coh_geom,len(list_zs_req_coh_geom),bar_progress)
				if bar_progress.wasCanceled():
					iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
					break
		
	function_zsro_s13()
	#Controle function_znro
	def function_znro_S12():
		bar_progress=progress_bar('Execution de la function_sitetech_s12')
		req_zn_nroref="""select zn.zn_code, zn.zn_nroref,st_astext(st_buffer(zn.geom, 0.5)), zn.zn_nd_code,st.st_nom
			from """+schema+""".t_znro zn
				left join """+schema+""".t_sitetech st on (zn.zn_nroref = st.st_nom and zn.zn_nd_code = st.st_nd_code)
			"""
		list_zn_nroref=function_execute_requete(req_zn_nroref,'bab',connection)
		if list_zn_nroref:
			for index_zn_nroref, s12_zn_nroref in enumerate(list_zn_nroref):
				bonne_zn_nroref='False'
				geom=s12_zn_nroref[2]
				
				if s12_zn_nroref[4]:
					bonne_zn_nroref='True'

				if bonne_zn_nroref == 'False':
					message_12='Incoherence de nommage pour zn_nroref'
					if geom:
						listing_error_control_ADN.append([geom,message_12,s12_zn_nroref[4]])
	#                    print (s12_zn_nroref[0],';',s12_zn_nroref[1],\
	#                    ';',bonne_zn_nroref)
				progress_processing(index_zn_nroref,len(list_zn_nroref),bar_progress)
				if bar_progress.wasCanceled():
					iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
					break
	function_znro_S12()
	#Controle function_Calcul du nombre de SUF par ZPBO
	def function_suf_S17():
		def Convert(string,list_append): 
			li = list(string.split(",")) 
			for index_suf, suf in enumerate(li):
				if suf not in list_suf_error:
					list_suf_error.append(suf)
					
		bar_progress=progress_bar('Execution de la function_suf_S17')
		req_suf="""SET search_path = """+schema+""", public;
			with control_attribut as (
			select 
				coalesce(sf.sf_zp_code,'Cest Vide') ::text as zp_attribut,count(*) as nbre_attribut,array_to_string(array_agg(sf.sf_code),',') sf_code_attribut
			from t_suf sf
				left join t_zpbo zp on zp.zp_code=sf.sf_zp_code
			group by sf.sf_zp_code
			order by sf.sf_zp_code),

			control_geom as (
			select 
				coalesce(sf.sf_zp_code,'Cest Vide') ::text as zp_geom,count(*) as nbre_geom,array_to_string(array_agg(sf.sf_code),',') as sf_code_geom
			from t_suf sf
			left join t_noeud nd on nd.nd_code=sf.sf_nd_code
				left join t_zpbo zp on st_within(nd.geom,zp.geom)
			group by sf.sf_zp_code
			order by sf.sf_zp_code)

			select 
				zp_attribut,nbre_attribut,sf_code_attribut,
				zp_geom,nbre_geom,sf_code_geom
			from control_attribut ca
				full join control_geom cg on (cg.zp_geom=ca.zp_attribut) and (cg.nbre_geom=ca.nbre_attribut)
			--where zp_attribut is null or zp_geom is null"""
		list_suf_error=[]
		list_req_suf=function_execute_requete(req_suf,'bab',connection)
		if list_req_suf:
			for index_req_suf, s17_req_suf in enumerate(list_req_suf):
				bonne_req_suf='False'
				sf_code_attribut=s17_req_suf[2]
				sf_code_geom=s17_req_suf[5]
				if s17_req_suf[0] == 'Cest Vide' or s17_req_suf[3] == 'Cest Vide':
					Convert(sf_code_attribut,list_suf_error)
					Convert(sf_code_geom,list_suf_error)
				if s17_req_suf[0] != s17_req_suf[3] and s17_req_suf[1] != s17_req_suf[4]:
					Convert(sf_code_attribut,list_suf_error)
					Convert(sf_code_geom,list_suf_error)
				progress_processing(index_req_suf,len(list_req_suf),bar_progress)
				if bar_progress.wasCanceled():
					iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
					break
		if list_suf_error:
			req_get_result="""SET search_path = """+schema+""", public;
				select sf.sf_code, sf.sf_zp_code,st_astext(st_buffer(nd.geom, 0.5)) from t_suf sf
				left join t_noeud nd on nd.nd_code=sf.sf_nd_code where sf.sf_code in """ + unicode (list_suf_error).replace ('[','(').replace (']',')')
			
			list_req_get_result=function_execute_requete(req_get_result,'bab',connection)
			if list_req_get_result:
				for index_get_resul_suf, get_resul_suf in enumerate(list_req_get_result):
					geom=get_resul_suf[-1]
					message_17='Incoherence du nombre de suf attribut et geometrie'
					if geom:
						listing_error_control_ADN.append([geom,message_17,get_resul_suf[0]])
					#print (get_resul_suf[0],';',get_resul_suf[1],';',get_resul_suf[2])
					progress_processing(index_get_resul_suf,len(list_req_get_result),bar_progress)
					if bar_progress.wasCanceled():
						iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
						break
	function_suf_S17()
	#Controle function_nbre_pt_s18
	def function_nbre_pt_s18():
		bar_progress=progress_bar('Execution de la function_sitetech_s18')
		req_nbre_pt="""SET search_path = """+schema+""", public;
			select 
				pt.pt_code, pt.pt_etiquet, pt.pt_nd_code, pt.pt_prop, pt.pt_gest, pt.pt_statut, pt.pt_etat, pt.pt_avct, pt.pt_typephy, pt.pt_typelog, st_astext(st_buffer(nd.geom, 0.5))
			from t_ptech pt
				left join t_noeud nd on nd.nd_code=pt.pt_nd_code
			where pt.pt_typephy in ('C', 'A','Z') """
		list_nbre_pt=function_execute_requete(req_nbre_pt,'bab',connection)
		if list_nbre_pt:
			compte_chb=0
			compte_a=0
			compte_z=0
			for index_nbre_pt, s18_nbre_pt in enumerate(list_nbre_pt):
				if s18_nbre_pt[8] == 'C':
					compte_chb+=1
					
				elif s18_nbre_pt[8] == 'A':
					compte_a+=1
				elif s18_nbre_pt[8] == 'Z':
					compte_z+=1
				progress_processing(index_nbre_pt,len(list_nbre_pt),bar_progress)
				if bar_progress.wasCanceled():
					iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
					break
			QMessageBox.information(w, "Message-Comptage-NBRE-PT", 'Nbre Chambre : '+str(compte_chb)+'\nNbre Appui : '+str(compte_a)+'\nNbre Potelet : '+str(compte_z))
			#print (compte_chb,';',compte_a,';',compte_z)
	function_nbre_pt_s18()
	#Controle function_nbre_cm_sro_s21_1znro
	def function_nbre_cm_sro_s21_1():
		bar_progress=progress_bar('Execution de la function_sitetech_s21_1')#pr_1_1_doe_v2
		req_nbre_cm_sro="""
			SET search_path = """+schema+""", public;
			select 
				st.st_code, array_agg(st.st_nd_code)st_nd_code, array_agg(st.st_nom) st_nom, array_agg(st.st_typelog) st_typelog, array_agg(cm.cm_code), array_agg(cm.cm_compo), count(*) nbre_cm, st_astext(st_buffer(nd.geom, 0.5))
			from t_sitetech st
				left join t_noeud nd on nd.nd_code = st.st_nd_code
				left join t_cheminement cm on st_dwithin (nd.geom, cm.geom, 100)
			where st.st_typelog = 'SRO' and (cm.cm_compo like '%60%' or cm.cm_compo like '%80%')
			group by st.st_code,nd.geom """
		list_nbre_cm_sro=function_execute_requete(req_nbre_cm_sro,'bab',connection)
		if list_nbre_cm_sro:
			for index_nbre_cm_sro, s21_1_nbre_cm_sro in enumerate(list_nbre_cm_sro):
				bonne_nbre_cm_sro='False'
				geom=s21_1_nbre_cm_sro[-1]
				message_s21_1='Incoherence cm_compo contient 60 ou 80 a moins de 100m du SRO'
				if geom:
					listing_error_control_ADN.append([geom,message_s21_1,s21_1_nbre_cm_sro[5]])
				#print (s21_1_nbre_cm_sro[0],';',s21_1_nbre_cm_sro[1])
				progress_processing(index_nbre_cm_sro,len(list_nbre_cm_sro),bar_progress)
				if bar_progress.wasCanceled():
					iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
					break
	function_nbre_cm_sro_s21_1()
	#Controle function_znro
	def function_decoupe_zsro_s21_3():
		bar_progress=progress_bar('Execution de la function_sitetech_s21_3')
		req_decoupe_zsro="""SET search_path = """+schema+""", public;
			select
				zs.zs_code, zs.zs_nd_code, zs.zs_nblogmt, zs.zs_typeemp, zs.zs_capamax,st_astext(st_buffer(zs.geom, 0.5))
			from t_zsro zs; """
		list_decoupe_zsro=function_execute_requete(req_decoupe_zsro,'bab',connection)
		if list_decoupe_zsro:
			for index_decoupe_zsro, s21_3_decoupe_zsro in enumerate(list_decoupe_zsro):
				bonne_decoupe_zsro='False'
				geom=s21_3_decoupe_zsro[-1]
				if s21_3_decoupe_zsro[2]:
					if int(s21_3_decoupe_zsro[2]) < 300 and int(s21_3_decoupe_zsro[2]) > 500:
						message_s21_1='Incoherence du nombre de suf'
						if geom:
							listing_error_control_ADN.append([geom,message_s21_1,s21_3_decoupe_zsro[2]])

				progress_processing(index_decoupe_zsro,len(list_decoupe_zsro),bar_progress)
				if bar_progress.wasCanceled():
					iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
					break
	function_decoupe_zsro_s21_3()

	#Function pour le control du S01
	Fichier_appuis=QFileDialog.getOpenFileName(None, "Selectionner le fichier de la grille de remplissage ", "", "xlsx files (*.xlsx)")
	def function_s01(var_name_sheet,name_column_table,name_column_status,Fichier_appuis,execute_type,schema):
		
		var_attribut_check='attribut'
		var_table_check='table'
		
		if Fichier_appuis:
			xl_workbook = xlrd.open_workbook(Fichier_appuis[0])#Fichier_appuis_nok[0] avec boite dialogue
			sheet_names = xl_workbook.sheet_names()
			
			#Creation des listes vides pour les resultats finaux dans la creation du dictionnaire
			list_table_name=[]
			list_table_status=[]
			
			for name_sheet in sheet_names:
				if name_sheet == var_name_sheet:#'MCD_Classes':
					worksheet = xl_workbook.sheet_by_name(name_sheet)
					
					#Recuperation des entetes
					first_row = [] # Header
					for col in range(worksheet.ncols):
						first_row.append(str(worksheet.cell_value(1,col)).replace("'",'').upper().lower())
					#print (first_row)
					
					#Recuperation de toues les lignes et des colonnes
					data =[]
					for row in range(1, worksheet.nrows):
						elm = {}
						for col in range(worksheet.ncols):
							elm[first_row[col]]=str(worksheet.cell_value(row,col)).replace("'",'').upper().lower()
						data.append(elm)
					
					#print (data)
					
					# Recuperation de la colonne des noms des tables et la status demande
					for  index_dict, value in enumerate(data):
						for index_value, (key, var_value) in enumerate(value.items()):
							
							if key == name_column_table.upper().lower():
								list_table_name.append(var_value)
				
							if key == name_column_status.upper().lower():
								list_table_status.append(var_value)
								#print (key,';',var_value)
									
			#Return le dictionnaire des noms des tables et leur statu
			#print (list_table_status,';',len (list_table_status),';',list_table_name,';',len (list_table_name))
			#dict_tableName_status = {}
			if len (list_table_name) == len (list_table_status):
				dict_tableName_status = dict(zip(list_table_name, list_table_status))
				#print (dict_tableName_status)
				#return dict_tableName_status
			else:
				QMessageBox.warning(w, "Message Longueur des Listes", 'Les deux Listes ont des longueurs differentes, Veillez verifier les noms des colonnes ' + execute_type)
			
			#Partie du controle des tables obligatoirement remplies
			if execute_type == var_table_check:
				req_create_table_error_table="""set search_path ="""+schema+""", public;
					DROP TABLE if exists check_table_vide;
					CREATE TABLE if not exists check_table_vide
					( nombre text,  tablename text);
					GRANT ALL ON TABLE check_table_vide TO postgres;
					GRANT SELECT, UPDATE, INSERT ON TABLE check_table_vide TO adn_ing;"""
				function_execute_requete(req_create_table_error_table,'',connection)
			
			#Partie du controle des attributs obligatoirement remplis
			if execute_type == var_attribut_check:
				req_create_table_error_attribut="""set search_path ="""+schema+""", public;
					DROP TABLE if exists check_attribut_vide;
					CREATE TABLE if not exists check_attribut_vide
					( attribut text,  columnname text);
					GRANT ALL ON TABLE check_attribut_vide TO postgres;
					GRANT SELECT, UPDATE, INSERT ON TABLE check_attribut_vide TO adn_ing;"""
				function_execute_requete(req_create_table_error_attribut,'',connection)
			
			req_verfif="""select 
					'INSERT INTO '||s.table_schema||'.check_table_vide(nombre, tablename) '||
						'select * from (select count(*), '''||s.table_name||''' as name_table from '||s.table_schema||'.'||s.table_name||') as t where count = 0' as req_compte_tab,
					'INSERT INTO '||s.table_schema||'.check_attribut_vide(attribut, columnname) '||
						'select distinct '||s.column_name||','||quote_literal(s.column_name)||' from '||s.table_schema||'.'||s.table_name || ' where '||s.column_name ||' is null' as req_null_attribut,
					s.table_name, 
					s.column_name 
				from information_schema.columns s
					WHERE s.table_schema = '"""+schema+"""'"""
			
			res_req_verif=function_execute_requete(req_verfif,'bab',connection)
			
			bar_progress=progress_bar('Execution de la function des insertions Table Vide et Attribut Vide Obligatoire, Veillez patientez')
			
			#Partie Verification des attribut obligatoire
			for index_value, (key, var_value) in enumerate(dict_tableName_status.items()):
				req_insert_table='False'
				if var_value == 'O' or var_value == 'O'.lower():
					for res_index_verif, verif in enumerate(res_req_verif):
						if str (key) == str(verif[3]) : #Partie du controle des tables obligatoirement remplies
							function_execute_requete(verif[1],'',connection)
						if str (key) == str(verif[2]) : #Partie du controle des attributs obligatoirement remplis
								req_insert_table=verif[0]
				if req_insert_table != 'False':
					function_execute_requete(req_insert_table,'',connection)
				
				progress_processing(index_value,len(dict_tableName_status.items()),bar_progress)
				if bar_progress.wasCanceled():
					iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
					break
		
		#Synthese
		req_synthese_error_s01="""set search_path = """+schema+""", public;
			select attribut, def, tablename from check_attribut_moins
			union all 
			select attribut, def, tablename from check_attribut_plus
			union all 
			select 'attribut', def, tablename from check_table_manquante
			union all 
			select distinct attribut, 'Attribut vide en etant Obligatoire dans la Grille' as def, columnname from check_attribut_vide
			union all 
			select nombre, 'Table vide en etant Obligatoire dans la Grille' as def, tablename from check_table_vide"""
		#list_synthese_s01=function_execute_requete(req_synthese_error_s01,'bab',connection)

	dict_attribut = function_s01(sheet_mcd_attribut,sheet_mcd_attribut_column_name_attribut,sheet_mcd_attribut_column_name_status,Fichier_appuis,'attribut',schema)# Pour les attributs
	dict_table = function_s01(sheet_mcd_table,sheet_mcd_table_column_name_table,sheet_mcd_attribut_column_name_status,Fichier_appuis,'table',schema)# Pour les tables

	# Rectification du sens de dessin Qgis
	def RectifSensDessin_function_QG(name_point, name_sro, name_cable, type_sitetech_depart, var_atr_typelog):
		
		name_point ='t_noeud'
		name_sro = 'vs_elem_st_nd'
		name_cable = 'correction_daccrochage'
		type_sitetech_depart='NRO+SROL'
		var_atr_typelog='st_typelog'
		
		#Function pour  Get layer dans la BD
		def function_getLayer_bdd(DB,user,MP,host,port,schema,table_name,key,rename_table,column_geom):
			#import qgis.core 
			uri = QgsDataSourceUri()
			uri.setConnection(host, port, DB, user, MP)
			uri.setDataSource(schema, table_name, column_geom,'',key)
			layer = QgsVectorLayer(uri.uri(False), rename_table, "postgres")
			if layer.isValid():
				#QgsProject.instance().addMapLayer(layer)
				return layer
		
		#Function Get layer dans Qgis
		def function_getlayer_QGis(layer_name):
			layers =  [tree_layer.layer() for tree_layer in QgsProject.instance().layerTreeRoot().findLayers()]#Pyqgis3
			for layer in layers:
				layerType = layer.type()
				if layerType == QgsMapLayer.VectorLayer:
					if layer.name() == layer_name:
						return layer
		
		#Function pour corriger les erreurs d'accrochage ligne et point
		def function_accrochage_lines_to_point(distance_buffer):
			
			#Function pour  Get layer dans la BD
			def function_getLayer_bdd(DB,user,MP,host,port,schema,table_name,key,rename_table,column_geom):
				#import qgis.core 
				uri = QgsDataSourceUri()
				uri.setConnection(host, port, DB, user, MP)
				uri.setDataSource(schema, table_name, column_geom,'',key)
				layer = QgsVectorLayer(uri.uri(False), rename_table, "postgres")
				if layer.isValid():
					#QgsProject.instance().addMapLayer(layer)
					return layer
			
			#Function Get layer dans Qgis
			def function_getlayer_QGis(layer_name):
				layers =  [tree_layer.layer() for tree_layer in QgsProject.instance().layerTreeRoot().findLayers()]#Pyqgis3
				for layer in layers:
					layerType = layer.type()
					if layerType == QgsMapLayer.VectorLayer:
						if layer.name() == layer_name:
							return layer

			shape_point = function_getLayer_bdd(DB,user,MP,host,port,schema,'t_noeud','nd_code','t_noeud','geom')
			shape_ligne = function_getLayer_bdd(DB,user,MP,host,port,schema,'vs_elem_cl_cb','cb_code','vs_elem_cl_cb','geom')

			layershape_point_technique = shape_point
			layershape_support = shape_ligne

			correction_daccrochage = QgsVectorLayer("LineString?crs=epsg:2154", "correction_daccrochage", "memory")
			correction_daccrochage_pr2 = correction_daccrochage.dataProvider()
			correction_daccrochage_attr2 = layershape_support.dataProvider().fields().toList()
			correction_daccrochage_pr2.addAttributes(correction_daccrochage_attr2)
			correction_daccrochage.updateFields()

			for shape_support in layershape_support.getFeatures():
				
				res_originee='KO'
				res_extremitee='KO'
				
				geom_support=shape_support.geometry()
				if geom_support != NULL:
					bboxinfra = geom_support.buffer(5, 5).boundingBox()
					request = QgsFeatureRequest()
					request.setFilterRect(bboxinfra)
					
					if geom_support.wkbType()==QgsWkbTypes.MultiLineString:
						geom_support_type=geom_support.asMultiPolyline()
						support_origine=geom_support_type[0][0]
						support_extremite=geom_support_type[-1][-1]
						
					if geom_support.wkbType()==QgsWkbTypes.LineString:
						geom_support_type=geom_support.asPolyline()
						support_origine=geom_support_type[0]
						support_extremite=geom_support_type[-1]
					
						
					for pt in layershape_point_technique.getFeatures(request):
						if (QgsGeometry.fromPointXY(QgsPointXY(support_origine))).equals(pt.geometry()):
							res_originee='OK'
						if (QgsGeometry.fromPointXY(QgsPointXY(support_extremite))).equals(pt.geometry()):
							res_extremitee='OK'
						
					if res_originee=='KO' or res_extremitee=='KO':
						for pt in layershape_point_technique.getFeatures(request):
							geom_pt_type=pt.geometry().asPoint()
							if (QgsGeometry.fromPointXY(QgsPointXY(support_origine))).within(pt.geometry().buffer((float(distance_buffer)),(float(distance_buffer)))):
								#geom_support_type.insert(0,geom_pt_type) #Mode accrochage avec ajout de vertext
								for i, geom_vertex_lines in enumerate(geom_support_type):
									if geom_vertex_lines == support_origine:
										geom_support_type[i] = geom_pt_type
							if (QgsGeometry.fromPointXY(QgsPointXY(support_extremite))).within(pt.geometry().buffer((float(distance_buffer)),(float(distance_buffer)))):
								#geom_support_type.append(geom_pt_type) #Mode accrochage avec ajout de vertext
								for i, geom_vertex_lines in enumerate(geom_support_type):
									if geom_vertex_lines == support_extremite:
										geom_support_type[i] = geom_pt_type

					ft = QgsFeature()
					#print geom_support_type
					if geom_support.wkbType() in [QgsWkbTypes.MultiLineString,QgsWkbTypes.LineString]:
						polyline = QgsGeometry.fromPolylineXY(geom_support_type)
						ft.setAttributes(shape_support.attributes())
						ft.setGeometry(polyline)
						correction_daccrochage_pr2.addFeatures([ft])

			#QgsProject.instance().addMapLayer(correction_daccrochage)
			return correction_daccrochage

		#function_accrochage_lines_to_point(0.3)
		
		shape_point=function_getLayer_bdd(DB,user,MP,host,port,schema,'t_noeud','nd_code','t_noeud','geom')#function_getlayer_QGis(name_point)
		shape_sro=function_getLayer_bdd(DB,user,MP,host,port,schema,'vs_elem_st_nd','st_nom','vs_elem_st_nd','geom')#function_getlayer_QGis(name_sro)
		shape_ligne=function_accrochage_lines_to_point(0.3)#function_getlayer_QGis(name_cable)#function_accrochage_lines_to_point(0.3)#
		
		def return_Not_Null(field):
			if field == NULL:
				return 'Identifiant NULL pour cette entite'
			else :
				return field
			
		layershape_sro = [i for i in shape_sro.getFeatures()]
		layershape_noeud = [i for i in shape_point.getFeatures()]
		layershape_cable = [i for i in shape_ligne.getFeatures()]
		
		listshape_noeud = []
		list_noeud_superpose=[]
		
		geoms_noeud_dup = {}
		index_noeud_dup  = QgsSpatialIndex()
		for current, f in enumerate(layershape_noeud):
			geom_noeud_dup =f.geometry()
			if geom_noeud_dup != NULL  or geom_noeud_dup.isGeosValid():
				geoms_noeud_dup[f.id()] = geom_noeud_dup
				index_noeud_dup.insertFeature(f)
					
		for feature_id, shape_noeuds in enumerate(layershape_noeud):

			geom_noeud=shape_noeuds.geometry()
			noeud_id = shape_noeuds[0]
			shape_noeud = [noeud_id,geom_noeud.asWkt(2),-1,-1,-1,-1]
			listshape_noeud.append(shape_noeud)
			
			#identifier les noeud qui se superposent
			if geom_noeud != NULL or geom_noeud.isGeosValid():
				res_noeud_dup='False'
				candidates = index_noeud_dup.intersects(geom_noeud.boundingBox())
				if candidates:
					for candidate_id in candidates:
						geom_noeud_dup = geoms_noeud_dup[candidate_id]
						if geom_noeud_dup.within(geom_noeud.buffer(0.1,0.1)) and shape_noeuds.id() != candidate_id:
							res_noeud_dup='True'
							#print (geometry[0],';',geometry.id(),';',candidate_id)
				if res_noeud_dup == 'True':
					#print (noeud_id,';',shape_noeuds.id())
					list_noeud_superpose.append(noeud_id)
					
		listshape_sro = []

		for shape_sro  in layershape_sro:
			if shape_sro[var_atr_typelog] == type_sitetech_depart:#var_atr_typelog #shape_sro[4]
				shape_sros = shape_sro.geometry().asWkt(2)
				listshape_sro.append(shape_sros)
				#print ('babab : ', shape_sro[0],';',shape_sro[var_atr_typelog],';',shape_sros)
			
		point_depart_sro=str(min(listshape_sro)).replace('[','').replace(']','').replace('u','').replace("'",'')

		list_shape_cable=[]
		for shape_cable in layershape_cable:
			geom_cable_lines=shape_cable.geometry()
			cable_id=shape_cable[0]
			cable_etiquet=shape_cable['cb_etiquet']
			cable_type=shape_cable['cb_typelog']
			cable_capa=shape_cable['cb_capafo']
			geom_cable_wkt=geom_cable_lines.asWkt()
			geom_cable_lines_lenth=geom_cable_lines.length()
			
			cable_nd1=shape_cable['cb_nd1']
			cable_nd2=shape_cable['cb_nd2']
			
			res_origine='KO'
			res_extremite='KO'

			geom_cable=geom_cable_lines
			if geom_cable.wkbType()==QgsWkbTypes.MultiLineString:
				geom_cable_type=geom_cable.asMultiPolyline()
				cable_origine=geom_cable_type[0][0]
				cable_extremite=geom_cable_type[-1][-1]
				
			if geom_cable.wkbType()==QgsWkbTypes.LineString:
				geom_cable_type=geom_cable.asPolyline()
				cable_origine=geom_cable_type[0]
				cable_extremite=geom_cable_type[-1]
			
			shape_cables_origine=(QgsGeometry.fromPointXY(QgsPointXY(cable_origine))).asWkt(2)
			shape_cables_extremite=(QgsGeometry.fromPointXY(QgsPointXY(cable_extremite))).asWkt(2)
			list_shape_cable.append([cable_id,shape_cables_origine,shape_cables_extremite,0,-1,-1,cable_etiquet,cable_type,cable_capa,geom_cable_wkt,geom_cable_lines_lenth,cable_nd1,cable_nd2])
			
		def cable_parcours_sens(depart_origine_support,pt_amont,ordre,niveau,distance):
			pt_aval = ""
			if niveau < 100000:
				for shape_cable in list_shape_cable:
					# On ne prend que les supports non parcourus dont lorigine est le point dorigine est depart_origine_support
					if (shape_cable[1]==depart_origine_support) and (shape_cable[3]==0):
						#le support est dans le bon sens
						shape_cable[3] = 1
						# on verifie si il y a un point technique en extremite de ce support
						ptextremite_good_sens = 0
						for shape_noeud in listshape_noeud:
							if shape_cable[2] == shape_noeud[1]:
								# si il y a un point technique en extremite, on recommence la reursion a partir de ce point
								ptextremite_good_sens = 1
								cable_parcours_sens(shape_cable[2],shape_noeud[0],ordre,niveau+1,shape_cable[10]+distance)
								pt_aval = return_Not_Null(shape_noeud[0])
								shape_noeud[5] = distance

						shape_cable[4]=return_Not_Null(pt_amont)
						shape_cable[5]=return_Not_Null(pt_aval)
						
					# On ne prend que les supports non parcourus dont l'extremite est le point dorigine est depart_origine_support
					elif (shape_cable[2]==depart_origine_support) and (shape_cable[3]==0):
						#le support nest pas dans le bon sens
						shape_cable[3] = -1
						# on verifie si il y a un point technique en extremite en fait origine) de ce support
						ptextremite_bad_sens = 0
						for shape_noeud in listshape_noeud:
							if shape_cable[1] == shape_noeud[1]:
								# si il y a un point technique en extremite (en fait origine), on recommence la recursion a partir de ce point
								ptextremite_bad_sens = 1
								cable_parcours_sens(shape_cable[1],shape_noeud[0],1,niveau+1,shape_cable[10]+distance)
								pt_aval = return_Not_Null(shape_noeud[0])
								shape_noeud[5] = distance
							
						shape_cable[4]=return_Not_Null(pt_amont)
						shape_cable[5]=return_Not_Null(pt_aval)

				if pt_aval == "" or pt_aval == NULL:
					pt_aval = 'Erreur pas de noeud Extremite'
					for shape_noeud in listshape_noeud:
						if depart_origine_support == shape_noeud[1]:
							pt_aval = shape_noeud[0]
							

				return pt_aval

		cable_parcours_sens(point_depart_sro ,'PM',1,1,0)
		
		
		#Creation shape vide erreur Sens Accrochage
		Erreur_Sens_Accroche = QgsVectorLayer("LineString?crs=epsg:2154", "Erreur_Sens_Accroche", "memory")
		Erreur_Sens_Accroche_pr2 = Erreur_Sens_Accroche.dataProvider()
		
		Erreur_Sens_Accroche_pr2.addAttributes([QgsField('cb_code', QVariant.String),QgsField('cb_etiquet', QVariant.String),\
			QgsField('mes_error', QVariant.String)])
	#    Erreur_Sens_Accroche_attr2 = shape_ligne.dataProvider().fields().toList()
	#    Erreur_Sens_Accroche_pr2.addAttributes(Erreur_Sens_Accroche_attr2)
		Erreur_Sens_Accroche.updateFields()
		Erreur_Sens_Accroche.commitChanges()

		bar_progress=progress_bar('Execution de la verification Sens du dessin, Accrochage')
		message_cb_nd1='Incoherence entre cb_nd1 et cb_nd1 reel'
		message_cb_nd2='Incoherence entre cb_nd12 et cb_nd12 reel'
		for index_cable, cable in enumerate(list_shape_cable):
			geom=cable[9]
			geom_cable=QgsGeometry.fromWkt(geom)
			valide_cb_nd1=message_cb_nd1
			valide_cb_nd2=message_cb_nd2
			buffer_geom_cable=geom_cable.buffer(0.1,0.1).asWkt()
			if cable[3] != 1:
				message='False'
				#outFeat = QgsFeature()
				if cable[3] == 0:
					message_accroche='Cable avec probleme daccrochage ou deconnecter du reseau'
					attrs=[cable[0],cable[6],message_accroche]
					outFeat_acc = QgsFeature()
					outFeat_acc.setGeometry(geom_cable)
					outFeat_acc.setAttributes(attrs)
					Erreur_Sens_Accroche_pr2.addFeatures([outFeat_acc])
					listing_error_control_ADN.append([buffer_geom_cable,message_accroche,cable[6]])
					

				#Inverser le sens
				if cable[3] == -1:
					message_sens='Cable dessine dans le mauvais sens'
					geom_line_Rec=None
					if geom_cable.isGeosValid() :
						if geom_cable.wkbType()==QgsWkbTypes.MultiLineString:
							mls = QgsMultiLineString()
							for line in geom_cable.asGeometryCollection():
								mls.addGeometry(line.constGet().reversed())
							geom_line_Rec = QgsGeometry(mls)
							
						elif geom_cable.wkbType()==QgsWkbTypes.LineString:
							geom_line_Rec = QgsGeometry(geom_cable.constGet().reversed())
					shape_ligne.startEditing()
					for shape_cable_shape in layershape_cable:
						if cable[0] == shape_cable_shape[0]:
							shape_ligne.changeGeometry(shape_cable_shape.id(),geom_line_Rec)
				
					attrs=[cable[0],cable[6],message_sens]
					outFeat_sens = QgsFeature()
					outFeat_sens.setGeometry(geom_cable)
					outFeat_sens.setAttributes(attrs)
					Erreur_Sens_Accroche_pr2.addFeatures([outFeat_sens])
					listing_error_control_ADN.append([buffer_geom_cable,message_sens,cable[6]])
				
	#            outFeat.setGeometry(geom_cable)
	#            Erreur_Sens_Accroche_pr2.addFeatures([outFeat])
			
			#Filtrer les suf qui se superposent
			for noeud_dup in list_noeud_superpose:
				if cable[11] == noeud_dup:
					valide_cb_nd1='True'
				if cable[12] == noeud_dup:
					valide_cb_nd2='True'
			
			#Filter le point de depart de mon parcours du reseau
			if cable[4] == 'PM':
				valide_cb_nd1='True'
			
			#Comparaison nd1 declare et nd1 geographique
			if cable[4] == cable[11]:
				valide_cb_nd1='True'
			
			#Comparaison nd2 declare et nd2 geographique
			if cable[5] == cable[12]:
				valide_cb_nd2='True'

			
			if valide_cb_nd1 == message_cb_nd1:
				attrs_cbnd1=[cable[0],cable[6],message_cb_nd1]
				outFeat_cbnd1 = QgsFeature()
				outFeat_cbnd1.setGeometry(geom_cable)
				outFeat_cbnd1.setAttributes(attrs_cbnd1)
				Erreur_Sens_Accroche_pr2.addFeatures([outFeat_cbnd1])
				listing_error_control_ADN.append([buffer_geom_cable,message_cb_nd1,cable[6]])
			
			if valide_cb_nd2 == message_cb_nd2:
				attrs_cbnd2=[cable[0],cable[6],message_cb_nd2]
				outFeat_cbnd2 = QgsFeature()
				outFeat_cbnd2.setGeometry(geom_cable)
				outFeat_cbnd2.setAttributes(attrs_cbnd2)
				Erreur_Sens_Accroche_pr2.addFeatures([outFeat_cbnd2])
				listing_error_control_ADN.append([buffer_geom_cable,message_cb_nd2,cable[6]])

				
			progress_processing(index_cable,len(list_shape_cable),bar_progress)
			if bar_progress.wasCanceled():
				iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
				break

		shape_ligne.commitChanges()
	#        QgsProject.instance().addMapLayer(Erreur_Sens_Accroche)
	#        QgsProject.instance().addMapLayer(shape_ligne)
	#        QgsProject.instance().addMapLayer(shape_point)
		#QgsProject.instance().addMapLayer(shape_sro)

	#    for index_noeud, shape_noeud in enumerate(listshape_noeud):
	#        if shape_noeud[5] != -1:
	#            #if shape_noeud[5] > 14000:
	#            #print (shape_noeud[0],';',shape_noeud[5])
	#            #pass
	#        progress_processing(index_noeud,len(listshape_noeud),bar_progress)
	#        if bar_progress.wasCanceled():
	#            iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
	#            break

	RectifSensDessin_function_QG('name_point', 'name_sro', 'name_cable', 'type_sitetech_depart', 'var_atr_typelog')    

	#Creation de la table erreur_Control sil nexiste pas
	requete_create_tab="""SET search_path = """+schema+""", public;
		CREATE TABLE if not exists erreur_control_adn (ID text,COMMENTAIRE text,ZAPM text, geom geometry(Polygon,2154));
		ALTER TABLE erreur_control_adn ADD COLUMN IF NOT EXISTS id_code text;
		GRANT ALL ON TABLE erreur_control_adn TO adn_ing;
		GRANT ALL ON TABLE erreur_control_adn TO postgres;
		CREATE INDEX if not exists erreur_control_adn_geom_gist  ON erreur_control_adn  USING gist  (geom);"""
	#Execution de la creation de la table erreur_control
	function_execute_requete(requete_create_tab,'',connection)

	table_erreur_control_adn='erreur_control_adn'
	req_erreur_control_adn="""select count (*)::int from """+schema+"""."""+table_erreur_control_adn
	get_count_erreur_control_adn=function_execute_requete(req_erreur_control_adn,'bab',connection)
	value_get_count_erreur_control_adn=','.join([str(i).replace(',','').replace('(','').replace(')','') for i in get_count_erreur_control_adn])


	#Function pour inserer dans la table derreur control adn
	def function_insert_tab_shape_erreur_control_design(schema,prefix_id_error,\
		value_get_count_erreur_control_adn,now,table_erreur_control_adn):
		
		bar_progress=progress_bar('Insertion des erreurs dans la base sur schema correspondant')
		len_features_error=len([feature for feature in listing_error_control_ADN])
				
		requete_zsro="""select zs_refpm, st_astext(geom) as geom from """+schema+""".t_zsro"""
		layer_zsro=function_execute_requete(requete_zsro,'bab',connection)
		
		#Index ZSRO
		geoms_zsro = {}
		index_zsro  = QgsSpatialIndex()
		for current, f in enumerate(layer_zsro):
			geom_zsro =QgsGeometry.fromWkt(f[1])
			if geom_zsro != NULL  or geom_zsro.isGeosValid():
				attrs=[f[0]]
				elem= QgsFeature()
				elem.setGeometry(geom_zsro)
				elem.setAttributes(attrs)
				geoms_zsro[current] = geom_zsro
				elem.setId(current)
				index_zsro.insertFeature(elem)
		
		count=int(value_get_count_erreur_control_adn)
		for feature_id, geom in enumerate(listing_error_control_ADN):
			#geom_error=QgsGeometry.fromWkt(geom[0])
			if (geom[0] != '' or geom[0] != NULL) and geom[0]:#geom_error.isGeosValid:
				geom_error=QgsGeometry.fromWkt(geom[0])
				if geom_error.isGeosValid:
					Name_PM='Pas de Zone SRO en Intersection ou bien lattribut zs_refpm du shapefile t_zsro est vide'
					id_zsro='-1'
					candidates = index_zsro.intersects(geom_error.boundingBox())
					if candidates:
						for candidate_id in candidates:
							geom_zsro = geoms_zsro[candidate_id]
							if geom_error.intersects(geom_zsro.buffer(0.1,0.1)):
								id_zsro=candidate_id
								
					if id_zsro != '-1':
						for current, f in enumerate(layer_zsro):
							if id_zsro == current:
								Name_PM=f[0]
					
					#if geom[1] != 'Incoherence de nommage ou de plage ou de status pour zp_boite':
					count += 1
					feat = QgsFeature()
					feat.setGeometry(geom_error)
					geome_text=geom_error.asWkt()
					id_code=prefix_id_error+now+'_'+unicode(count).zfill(4)
					id_comment=geom[1]
					attrs=[id_code,id_comment,Name_PM]#,''
					feat.setAttributes(attrs)
					#pr_shape_erreur_control_design.addFeatures([feat])#ST_GeomFromText((ST_Dump(geom)).geom)
					#print (id_code,';',id_comment,';',geome_text)
					
					requete_insert_tab="""INSERT INTO """+schema+"""."""+table_erreur_control_adn+"""(
						id, commentaire, zapm, geom, id_code) VALUES ('"""+str (id_code)+"""','"""+ str (id_comment)+"""', '"""+ str (Name_PM) +"""', 
						ST_GeomFromText(st_astext(ST_Geometryn(ST_GeomFromText('""" + str (geome_text) + """',2154),1)),2154),'"""+str(geom[2]).replace("'",'')+"""');"""

					#Execution de linsertion de la table erreur_control
					#print (requete_insert_tab)
					function_execute_requete(requete_insert_tab,'',connection)
					#break
			
			progress_processing(feature_id,len_features_error,bar_progress)
			if bar_progress.wasCanceled():
				iface.messageBar().pushMessage('Info', 'Action Cancelled', level=Qgis.Info)
				break
		
	#Execution de la function_insert_tab_shape_erreur_control_design
	function_insert_tab_shape_erreur_control_design(schema,prefix_id_error,\
		value_get_count_erreur_control_adn,now,table_erreur_control_adn)


	connection.commit()
	connection.close()
	#print (listing_error_control_ADN)
	QMessageBox.information(w, "Message Execution Plugin", 'Execution du Plugin est finie avec Succes')
    
#Execution de la function generale
# function_formalisme_mcd('pr_1_10_exe_v_20190823',client,stat_etude,sheet_mcd_attribut,
    # sheet_mcd_table,
    # sheet_mcd_attribut_column_name_attribut,
    # sheet_mcd_table_column_name_table,
    # sheet_mcd_attribut_column_name_status)#pr_4_5_exe_v_20190514 schema