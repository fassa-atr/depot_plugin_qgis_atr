#Ajouter style automatiquement dans les donnes de qgis
import processing,xlrd,psycopg2
from qgis.PyQt.QtCore import *
from qgis.PyQt.QtGui import *
from qgis.core import * 
from qgis.utils import *
from qgis.PyQt.QtWidgets import *
from qgis.PyQt.QtXml import QDomDocument
from random import randrange


#Declaration des Parameters de connexion de la base
# DB = 'MCD_ADN_sans_ct'
# user = 'postgres'
# MP = 'postgres'
# host = '192.168.30.218'#'192.168.30.218'
# port = '5432'
# schema = 'test_baba'

def function_application_vues(DB,user,MP,host,port,schema):

	w = QWidget()
	#Declaration des tables et attributs a utiliser

	## CABLAGE
	table_cheminement='t_cheminement'
	table_cableline='vs_elem_cl_cb'
	table_ebp='vs_elem_bp_pt_nd'
	table_ptech='vs_elem_pt_nd'
	table_contre_releve='contre_releve'

	table_ptech_rename='t_ptech'
	table_ebp_rename='t_ebp'
	table_cable_rename='t_cable'

	## INFRA
	table_love='vs_elem_lv_nd'
	table_sitetech='vs_elem_st_nd'

	table_love_rename='t_love'
	table_sitetch_rename='t_sitetech'

	## ZONAGE
	table_znro='t_znro'
	table_zsro='t_zsro'
	table_zpbo='t_zpbo'
	table_zdep='t_zdep'
	table_suf='vs_elem_sf_nd'

	table_suf_rename='t_suf'

	## basemaps
	table_parcelles_znro='vs_parcelles_znro'
	
	##vs_resopt_liens
	name_vs_resopt_liens='vs_resopt_liens'
	##vs_resopt_lienstransport
	name_vs_resopt_lienstransport='vs_resopt_lienstransport'
	##vs_resopt_noeuds
	name_vs_resopt_noeuds='vs_resopt_noeuds'
	##vs_suf_majic
	name_vs_suf_majic='vs_suf_majic'
	
	##Shape_Error_Control
	table_erreur_control='erreur_control_adn'

	## PK pour views
	sf_PrimaryKey = "sf_code"
	st_PrimaryKey = "st_code"
	lv_PrimaryKey = "lv_id"
	cb_PrimaryKey = "cb_code"
	ebp_PrimaryKey = "bp_code"
	pt_PrimaryKey = "pt_code"
	cd_PrimaryKey = "id_par"
	
	vs_resopt_liens_PrimaryKey='gid'
	vs_resopt_lienstransport_PrimaryKey='gid'
	name_vs_resopt_noeuds_PrimaryKey='gid'
	vs_suf_majic_PrimaryKey='gid'

	#class creation_vues_qgis():
		
	#Function pour recuperer la connexion de la base de donnee et rertourn lobjet de la couche
	def function_return_layer(base_name,user_name,password,host_name,port_name,schema_name,table_name,key,rename_table):
		uri = QgsDataSourceUri()
		DB = base_name#"MCD_ADN_sans_ct"
		user = user_name#"adn_ing"
		MP = password#"password"
		host = host_name#"192.168.30.218"
		port = port_name#"5432"
		schema = schema_name#"test"
		uri.setConnection(host, port, DB, user, MP)
		uri.setDataSource(schema, table_name, "geom",'',key)#(schema, table_name, "geom")#Shape
		layer = QgsVectorLayer(uri.uri(False), rename_table, "postgres")
		#print (layer.isValid())
		#QgsProject.instance().addMapLayer(layer)
		return layer

	#Funciton de creations des noms des groups
	def function_create_groupe_name(name_groupe):
		root = QgsProject.instance().layerTreeRoot()
		#name_groupe="Shape_Erreur_Control_Design_ADN"
		group = root.findGroup(name_groupe)
		if group is not None:
			for child in group.children():
				QgsProject.instance().removeMapLayer(child.layerId())
		root.removeChildNode(group)
		shapeGroup = root.addGroup(name_groupe)
		return shapeGroup
		
	#Function pour ajouter les tables dans leur groupe respectif
	def function_add_layer_group(layer_to_add, groupe_name):
		#QgsProject.instance().addMapLayer(layer_to_add,False)
		#groupe_name.insertChildNode(0,QgsLayerTreeLayer(layer_to_add))
		notre_entite=len(list(layer_to_add.getFeatures()))
		if notre_entite > 0:
			QgsProject.instance().addMapLayer(layer_to_add,False)
			groupe_name.insertChildNode(0,QgsLayerTreeLayer(layer_to_add))
		
	#Declaration des objets des tables par la function return layer
	layer_chem=function_return_layer(DB,user,MP,host,port,schema,table_cheminement,'',table_cheminement)
	layer_cableline=function_return_layer(DB,user,MP,host,port,schema,table_cableline,cb_PrimaryKey,table_cable_rename)
	layer_ebp=function_return_layer(DB,user,MP,host,port,schema,table_ebp,ebp_PrimaryKey,table_ebp_rename)
	layer_ptech=function_return_layer(DB,user,MP,host,port,schema,table_ptech,pt_PrimaryKey,table_ptech_rename)
	layer_contre_releve=function_return_layer(DB,user,MP,host,port,schema,table_contre_releve,'',table_contre_releve)

	layer_love=function_return_layer(DB,user,MP,host,port,schema,table_love,lv_PrimaryKey,table_love_rename)
	layer_sitetch=function_return_layer(DB,user,MP,host,port,schema,table_sitetech,st_PrimaryKey,table_sitetch_rename)

	layer_znro=function_return_layer(DB,user,MP,host,port,schema,table_znro,'',table_znro)
	layer_zsro=function_return_layer(DB,user,MP,host,port,schema,table_zsro,'',table_zsro)
	layer_zpbo=function_return_layer(DB,user,MP,host,port,schema,table_zpbo,'',table_zpbo)
	layer_zdep=function_return_layer(DB,user,MP,host,port,schema,table_zdep,'',table_zdep)
	layer_suf=function_return_layer(DB,user,MP,host,port,schema,table_suf,sf_PrimaryKey,table_suf_rename)

	layer_base_maps=function_return_layer(DB,user,MP,host,port,schema,table_parcelles_znro,cd_PrimaryKey,table_parcelles_znro)
	
	
	##vs_resopt_liens
	layer_vs_resopt_liens=function_return_layer(DB,user,MP,host,port,schema,name_vs_resopt_liens,vs_resopt_liens_PrimaryKey,name_vs_resopt_liens)
	layer_vs_resopt_lienstransport=function_return_layer(DB,user,MP,host,port,schema,name_vs_resopt_lienstransport,vs_resopt_lienstransport_PrimaryKey,name_vs_resopt_lienstransport)
	layer_vs_resopt_noeuds=function_return_layer(DB,user,MP,host,port,schema,name_vs_resopt_noeuds,name_vs_resopt_noeuds_PrimaryKey,name_vs_resopt_noeuds)
	layer_vs_suf_majic=function_return_layer(DB,user,MP,host,port,schema,name_vs_suf_majic,vs_suf_majic_PrimaryKey,name_vs_suf_majic)
	
	#Shape_Erreur_Control_Design_ADN
	layer_Erreur_Control_Design=function_return_layer(DB,user,MP,host,port,schema,table_erreur_control,'',table_erreur_control)

	#Declaration des noms des groupes a travers la function de creatino des groups
	cablage_group=function_create_groupe_name('CABLAGE')
	infra_group=function_create_groupe_name('INFRASTRUCTURE')
	zonage_group=function_create_groupe_name('ZONAGE')
	basemaps_group=function_create_groupe_name('BASEMAPS')
	dep_group=function_create_groupe_name('DEP')
	error_control=function_create_groupe_name('Controls_Design_SpatialisationUpNview')

	#Execution des fonction dajout des tables dans leur groups
	function_add_layer_group(layer_chem, cablage_group)
	function_add_layer_group(layer_cableline, cablage_group)
	function_add_layer_group(layer_ebp, cablage_group)
	function_add_layer_group(layer_ptech, cablage_group)
	function_add_layer_group(layer_contre_releve, cablage_group)

	function_add_layer_group(layer_love, infra_group)
	function_add_layer_group(layer_sitetch, infra_group)

	function_add_layer_group(layer_znro, zonage_group)
	function_add_layer_group(layer_zsro, zonage_group)
	function_add_layer_group(layer_zpbo, zonage_group)
	function_add_layer_group(layer_zdep, zonage_group)
	function_add_layer_group(layer_suf, zonage_group)

	function_add_layer_group(layer_base_maps, basemaps_group)
	
	function_add_layer_group(layer_vs_resopt_liens, dep_group)
	function_add_layer_group(layer_vs_resopt_lienstransport, dep_group)
	function_add_layer_group(layer_vs_resopt_noeuds, dep_group)
	function_add_layer_group(layer_vs_suf_majic, dep_group)
	function_add_layer_group(layer_Erreur_Control_Design, error_control)
	

	def function_ajoute_style(DB,user,MP,host,port):
	
		def function_style(layer_name, attribut_name):
			# Get the active layer (must be a vector layer)
			layer = QgsProject.instance().mapLayersByName(layer_name)[0]#"t_zsro"

			# get unique values
			fni = layer.fields().lookupField(attribut_name)#'zs_refpm'
			unique_values = layer.dataProvider().uniqueValues(fni)

			# define categories
			categories = []
			for unique_value in unique_values:
				# initialize the default symbol for this geometry type
				symbol = QgsSymbol.defaultSymbol(layer.geometryType())

				# configure a symbol layer
				layer_style = {}
				layer_style['color'] = '%d, %d, %d' % (randrange(0,256), randrange(0,256), randrange(0,256))
				layer_style['outline'] = '#000000'
				symbol_layer = QgsSimpleFillSymbolLayer.create(layer_style)

				# replace default symbol layer with the configured one
				if symbol_layer is not None:
					symbol.changeSymbolLayer(0, symbol_layer)

				# create renderer object
				category = QgsRendererCategory(unique_value, symbol, str(unique_value))
				# entry for the list of category items
				categories.append(category)

			# create renderer object
			renderer = QgsCategorizedSymbolRenderer(attribut_name, categories)#'zs_refpm'

			# assign the created renderer to the layer
			if renderer is not None:
				layer.setRenderer(renderer)

			layer.triggerRepaint()
	
		connection = psycopg2.connect(user=user,password=MP,host=host,port=port,database=DB)
		cursor = connection.cursor()
		requete="""SELECT styleqml,stylename FROM public.layer_styles;"""# WHERE stylename='t_cheminement'
		cursor.execute(requete)
		all_styles=cursor.fetchall()
		for layers_name_mapLayers in QgsProject.instance().mapLayers().values():
			if layers_name_mapLayers.type() == QgsMapLayer.VectorLayer and layers_name_mapLayers.geometryType() in [QgsWkbTypes.PointGeometry,QgsWkbTypes.LineGeometry,QgsWkbTypes.PolygonGeometry]:
				for i in all_styles:
					if layers_name_mapLayers.name() != 't_zsro' and layers_name_mapLayers.name() == i[1]:
						styledoc = QDomDocument()
						styledoc.setContent(i[0]) 
						layers_name_mapLayers.importNamedStyle(styledoc)
					if layers_name_mapLayers.name() == 't_zsro':
						function_style('t_zsro', 'zs_refpm')
		if (connection):
			connection.commit()
			cursor.close()
			connection.close()
		iface.mapCanvas().refreshAllLayers()
	function_ajoute_style(DB,user,MP,host,port)
	QMessageBox.information(w, "Message-Execution-Plugin", 'Fin Application des sytles des shapes')