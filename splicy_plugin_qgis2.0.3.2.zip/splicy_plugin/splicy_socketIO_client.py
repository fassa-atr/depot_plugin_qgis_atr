# -*- coding: utf-8 -*-
"""
/***************************************************************************
 Splicy
                                 A QGIS plugin
 Enhanced data manipulation between Qgis, PostGIS and a Web Server
                              -------------------
        begin                : 2017-04-20
        git sha              : $Format:%H$
        copyright            : (C) 2017 by CADaGEO
        email                : nicolas.fez@cadageo.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

# Importing socketIO python client.

import time
import json
import uuid

try:
    from qgis.core import Qgis
except ImportError:
    from qgis.core import QGis as Qgis

MAJOR_VERSION, MINOR_VERSION, _ = Qgis.QGIS_VERSION.split('.')[:3]

if MAJOR_VERSION == '3':
    from http.client import HTTPConnection, HTTPSConnection, CannotSendRequest

    from qgis.PyQt.QtCore import pyqtSignal
    from PyQt5.QtCore import QThread

    from .splicy_utils import get_logger
else:
    from httplib import HTTPConnection, HTTPSConnection, CannotSendRequest

    from qgis.PyQt.QtCore import pyqtSignal
    from PyQt4.QtCore import QThread

    from splicy_utils import get_logger



# Definition of global variables.


class SocketIOClient(QThread):
    """SplicyClient implementation.
    Creates a connection to a socketIO server on a new thread.
    """
    clientConnectError = pyqtSignal(str)
    clientConnectQuitting = pyqtSignal()
    clientConnected = pyqtSignal()
    clientDisconnected = pyqtSignal()

    # Command signals
    zoomToFeature = pyqtSignal(dict)
    highlightFeature = pyqtSignal(dict)
    dehighlightFeature = pyqtSignal(dict)
    colorizeEbpCables = pyqtSignal(dict)
    sendSelected = pyqtSignal()
    decolorizeEbpCables = pyqtSignal(dict)
    geomidRequest = pyqtSignal(dict)
    geomidDehighlight = pyqtSignal(dict)

    def __init__(self, projectScope, session_id=None, url=None, logger=None):
        """Constructor.

        :param server: The address of the server.
        :type server: str

        :param iface: The Qgis interface.
        :type iface: QgisInterface

        :param dockwidget: The GUI dockwidget.
        :type dockwidget: QDockWidget
        """
        # Initializing class variables.
        self.runServer = True
        self.logger = logger or get_logger()

        self.config = {}
        self.conn = None
        self.first_run = True
        self.failure_count = 0

        for key in 'proto', 'server', 'api_port', 'dbname', 'user_token':
            splicy_key = 'splicy_{}'.format(key)
            if projectScope.hasVariable(splicy_key):
                self.config[key] = projectScope.variable(splicy_key)

        self.client_id = uuid.uuid4()
        self.session_id = session_id
        self.backend_url = (
            '/api/v1/{}/messages/qgis/{}/{}'.format(
                self.config['dbname'],
                self.client_id,
                self.session_id,
            )
        )
        self.headers = {
            "Content-type": "application/json", "Accept": "text/plain",
            "Auth": self.config['user_token'],
        }
        self.pending_messages = []

        QThread.__init__(self)
        self.logger.debug('End of client.__init__')

    def make_conn(self):
        if self.config['api_port'] == '80' or self.config['proto'] == 'http':
            cls = HTTPConnection
        else:
            cls = HTTPSConnection

        return cls(
            str(self.config['server']),
            int(self.config['api_port']),
            timeout=2,
        )

    def run(self):
        """Executed code while thread is running."""
        # Creating connection with the server.
        # to True.
        self.logger.debug('self.runServer is {}'.format(self.runServer))
        # First run
        try:
            self.first_run = True
            self.send_to_socket()
            self.first_run = False
            if self.failure_count == 0:
                self.clientConnected.emit()
                while self.runServer:
                    time.sleep(0.1)
                    if len(self.pending_messages) > 0:
                        for message in self.pending_messages:
                            self.send_to_socket(message)
                    else:
                        self.send_to_socket()
                self.logger.debug('Out of SocketIoClient.run')
                self.clientDisconnected.emit()
        except Exception as e:
            self.logger.exception(e)
            self.clientConnectError.emit('run')

    def emit(self, message):
        self.send_to_socket(message)

    def send_to_socket(self, message=None):
        # Trying to send a message to the server and catch errors if needed.
        failure = False
        if message is None:
            args = [
                'GET', self.backend_url, '', self.headers,
            ]
        else:
            message = json.dumps(message)
            args = [
                'POST', self.backend_url, message, self.headers,
            ]

        try:
            conn = self.make_conn()
            conn.request(*args)
            response = conn.getresponse()
            payload = response.read()
            if MAJOR_VERSION == "3":
                payload = payload.decode()

            if response.status != 200:
                if response.status == 400:
                    if 'plain HTTP' in payload:
                        self.clientConnectError.emit('config:http')
                    else:
                        self.clientConnectError.emit('plugin_error')
                elif response.status == 500:
                    self.clientConnectError.emit('server_error')
                elif response.status == 401:
                    self.clientConnectError.emit('config:token')
                else:
                    self.clientConnectError.emit('config:unknown')
                failure = True
            else:
                response = json.loads(payload)
                if u'data' in response:
                    for message in response[u'data'][u'message_list']:
                        self.onmessage(message)
                conn.close()

            # Reset failure count
            self.failure_count = 0
        except CannotSendRequest:
            self.logger.debug('SocketIO client exception cannot send request')
            self.clientConnectError.emit('plugin_error_connect')
            failure = True
        except ValueError:
            self.logger.debug('Value Error')
            self.clientConnectError.emit('plugin_error_value')
            failure = True
        except Exception as e:
            self.logger.debug('SocketIO client exception')
            self.logger.exception(e)
            # 111: connection refused (server is down)
            # -2: cannot resolve name
            # 110 or None: timed out (packets are dropped)
            try:
                if not hasattr(e, 'errno'):
                    self.clientConnectError.emit('config:port_or_internal')
                elif e.errno in (111, 110):
                    self.clientConnectError.emit('config:server or port')
                elif 'timed out' in e.args:
                    self.clientConnectError.emit('config:timeout')
                elif e.errno == -2:
                    self.clientConnectError.emit('config:servername')
                else:
                    self.clientConnectError.emit('config:unknown')
            except:
                self.clientConnectError.emit('config:unknown')

            failure = True

        if failure:
            self.failure_count += 1
            if self.failure_count == 5 or self.first_run:
                self.logger.debug('5 failures, stop trying')
                self.clientConnectQuitting.emit()
                self.stop()
            time.sleep(2)

    def onmessage(self, message):
        """Handles if a message is received.

        :param args: The message received.
        :type args: bytes
        """
        self.logger.debug("** in SplicyClient.onMessage")
        # Getting strings from the arguments and check if errors occured.
        # message = self.getSocketIOMessageProperties(*args)
        try:
            command = message['command']
            self.logger.debug("Command: {}".format(message['command']))

            if command == 'zoomToFeature':
                self.zoomToFeature.emit(message['params'])
            elif command == 'sendSelected':
                self.sendSelected.emit()
            elif command == 'highlightFeature':
                self.logger.debug("highlightFeature emit")
                self.highlightFeature.emit(message['params'])
            elif command == 'dehighlightFeature':
                self.logger.debug("dehighlightFeature emit")
                self.dehighlightFeature.emit(message['params'])
            elif command == 'colorizeEbpCables':
                self.logger.debug("colorizeEbpCables emit")
                self.colorizeEbpCables.emit(message['params'])
            elif command == 'decolorizeEbpCables':
                self.logger.debug("decolorizeEbpCables emit")
                self.decolorizeEbpCables.emit(message['params'])
            elif command == 'geomidDehighlight':
                self.geomidDehighlight.emit(message['params'])
        except Exception as e:
            self.logger.exception(e)

    def stop(self):
        """Stops the thread loop."""
        self.runServer = False
