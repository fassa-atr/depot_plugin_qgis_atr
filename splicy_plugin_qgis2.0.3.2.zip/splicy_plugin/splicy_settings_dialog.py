import os
import tempfile

try:
    from qgis.core import Qgis
except ImportError:
    from qgis.core import QGis as Qgis

MAJOR_VERSION, MINOR_VERSION, _ = Qgis.QGIS_VERSION.split('.')[:3]

if MAJOR_VERSION == '3':
    from PyQt5 import QtGui, QtWidgets, uic
    from PyQt5.QtCore import pyqtSignal
    QDialog = QtWidgets.QDialog

    from qgis.core import (
        QgsExpressionContextUtils, QgsProject, QgsVectorLayer,
    )

    from .splicy_utils import (
        logger_enable_debug, logger_disable_debug,
        logger_enable_stdout, logger_disable_stdout,
    )
else:
    from PyQt4 import QtGui, uic
    QDialog = QtGui.QDialog
    from PyQt4.QtCore import pyqtSignal

    from qgis.core import (
        QgsExpressionContextUtils, QgsMapLayerRegistry, QgsVectorLayer,
    )

    from splicy_utils import (
        logger_enable_debug, logger_disable_debug,
        logger_enable_stdout, logger_disable_stdout,
    )


FORM_CLASS, _ = uic.loadUiType(
    os.path.join(
        os.path.dirname(__file__), 'splicy_settings_dialog.ui'
    )
)


class SplicySettingsDialog(QDialog):

    closingPlugin = pyqtSignal()

    def __init__(self, parent=None):
        """Constructor."""
        super(SplicySettingsDialog, self).__init__()
        self.parent = parent

        self.ui = FORM_CLASS()
        self.ui.setupUi(self)
        self.initUi()
        self.connectSignals()

    def connectSignals(self):
        self.ui.saveButton.clicked.connect(self.onSaveClick)
        self.ui.cancelButton.clicked.connect(self.close)

        # Connect boxes
        layerBoxes = [
            self.ui.bpeBox,
            self.ui.cheminementBox,
            self.ui.sitetechBox,
            self.ui.sufBox,
            self.ui.cableBox,
            self.ui.ptechBox,
        ]
        for box in layerBoxes:
            box.currentIndexChanged.connect(self.onLayerComboBoxUpdate)
            self.updateIdBox(box)

        # Tab 3 signals connection
        self.ui.selectedListWidget.itemSelectionChanged.connect(
            self.onSelectedListWidgetClick)
        self.ui.unselectedListWidget.itemSelectionChanged.connect(
            self.onUnselectedListWidgetClick)
        self.ui.selectedListWidget.itemClicked.connect(
            self.onSelectedListWidgetClick)
        self.ui.unselectedListWidget.itemClicked.connect(
            self.onUnselectedListWidgetClick)
        self.ui.listWidgetToggle.clicked.connect(
            self.onListWidgetToggleClick)

    def onSelectedListWidgetClick(self):
        self.ui.listWidgetToggle.setText('<')

    def onUnselectedListWidgetClick(self):
        self.ui.listWidgetToggle.setText('>')

    def onListWidgetToggleClick(self):
        val = self.ui.listWidgetToggle.text()
        if val == '<':
            from_list = self.ui.selectedListWidget
            to_list = self.ui.unselectedListWidget

        else:
            to_list = self.ui.selectedListWidget
            from_list = self.ui.unselectedListWidget

        selected_items = from_list.selectedItems()
        for item in selected_items:
            row = from_list.indexFromItem(item).row()
            from_list.takeItem(row)
            to_list.addItem(item)

        self.ui.unselectedListWidget.sortItems()
        self.ui.selectedListWidget.sortItems()

    def initUi(self):
        projectScope = self.parent.getProjectScope()

        if MAJOR_VERSION == '3':
            instance = QgsProject.instance()
        else:
            instance = QgsMapLayerRegistry.instance()

        self.map_layers = instance.mapLayers()

        self.layer_dict = {
            layer.id(): layer.name()
            for layer in self.map_layers.values()
        }
        self.reversed_layer_dict = {
            value: key for key, value in self.layer_dict.items()
        }

        if len(self.layer_dict) == 0:
            return

        # Configure layer dropdowns
        layer_widget_list = (
            ('bp_layer', self.ui.bpeBox,
             'vs_elem_bp_pt_nd_copier20160113002313929'),
            ('cm_layer', self.ui.cheminementBox,
             't_cheminement_copier20160112233706557'),
            ('st_layer', self.ui.sitetechBox,
             'vs_elem_st_nd_copier20160113000512827'),
            ('sf_layer', self.ui.sufBox,
             'vs_elem_sf_nd_copier20160112235538232'),
            ('cb_layer', self.ui.cableBox,
             'vs_elem_cl_cb_copier20170728030735688'),
            ('pt_layer', self.ui.ptechBox,
             'vs_elem_pt_nd_copier20160113022106459'),
        )
        layer_dict = self.layer_dict
        for config_key, widget, default in layer_widget_list:
            value = ""
            if projectScope.hasVariable(config_key):
                if projectScope.variable(config_key) in self.layer_dict:
                    value = layer_dict[projectScope.variable(config_key)]
            else:
                if default in layer_dict:
                    value = layer_dict[default]

            widget.clear()
            widget.addItems(['', ] + sorted(self.layer_dict.values()))
            widget.setCurrentIndex(widget.findText(value))

        value = 'https'
        if projectScope.hasVariable('splicy_proto'):
            value = projectScope.variable('splicy_proto')

        index = self.ui.splicyProtoEdit.findText(value)
        self.ui.splicyProtoEdit.setCurrentIndex(index)

        edit_widget_list = (
            ('splicy_port', self.ui.splicyPortEdit, '443'),
            ('splicy_api_port', self.ui.splicyApiPortEdit, '443'),
            ('splicy_dbname', self.ui.splicyDbnameEdit, ''),
            ('splicy_server', self.ui.splicyServerEdit, 'localhost'),
            ('splicy_user_token', self.ui.splicyUserTokenEdit, ''),
        )
        for config_key, widget, default in edit_widget_list:
            value = default
            if projectScope.hasVariable(config_key):
                value = projectScope.variable(config_key)

            if value != None:
                # Not using "is not None" here because value can be a
                # QPyNullVariant
                widget.setText(value)

        # Configure layer id dropdowns
        id_widget_list = (
            ('bp_layer_id', self.ui.bpeIdBox, 'bp_code'),
            ('cm_layer_id', self.ui.cheminementIdBox, 'cm_code'),
            ('st_layer_id', self.ui.sitetechIdBox, 'st_code'),
            ('sf_layer_id', self.ui.sufIdBox, 'sf_code'),
            ('cb_layer_id', self.ui.cableIdBox, 'cb_code'),
            ('pt_layer_id', self.ui.ptechIdBox, 'pt_code'),
        )
        for layer_id, widget, default in id_widget_list:
            value = (
                str(projectScope.variable(layer_id))
                if projectScope.hasVariable(layer_id)
                else default
            )
            widget.setCurrentIndex(widget.findText(value))

        # Configure list view
        for layer in self.map_layers.values():
            if not isinstance(layer, QgsVectorLayer):
                continue
            delegated = layer.customProperty('delegated') == 'true'
            if not delegated:
                self.ui.unselectedListWidget.addItem(layer.name())
            else:
                self.ui.selectedListWidget.addItem(layer.name())

        self.ui.unselectedListWidget.sortItems()
        self.ui.selectedListWidget.sortItems()

        # Init debug tab
        if projectScope.hasVariable('stdout_logging'):
            check_state = int(projectScope.variable('stdout_logging'))
            self.ui.stdoutLoggingCheckbox.setCheckState(check_state)

        if projectScope.hasVariable('debug_logging'):
            check_state = int(projectScope.variable('debug_logging'))
            self.ui.enableLoggingDebugCheckbox.setCheckState(check_state)

        self.update_log_browser()

    def update_log_browser(self):
        tempdir = tempfile.gettempdir()
        logfilepath = os.path.join(tempdir, 'splicy_plugin.log')

        with open(logfilepath) as handle:
            self.ui.logBrowser.setPlainText(handle.read())

    def onLayerComboBoxUpdate(self, text):
        self.updateIdBox(self.sender())

    def updateIdBox(self, layer_box):
        combo_box_dict = {
            self.ui.bpeBox: self.ui.bpeIdBox,
            self.ui.cheminementBox: self.ui.cheminementIdBox,
            self.ui.sitetechBox: self.ui.sitetechIdBox,
            self.ui.sufBox: self.ui.sufIdBox,
            self.ui.cableBox: self.ui.cableIdBox,
            self.ui.ptechBox: self.ui.ptechIdBox,
        }
        id_box = combo_box_dict[layer_box]
        id_box.clear()

        if len(self.reversed_layer_dict) == 0:
            return

        current_selection = layer_box.currentText()
        if current_selection != '':
            layer_id = self.reversed_layer_dict[current_selection]
            layer = self.parent.getLayer(layer_id)
            if layer is not None:
                id_box.addItems([field.name() for field in layer.fields()])

    def closeEvent(self, event):
        self.closingPlugin.emit()
        event.accept()

    def onSaveClick(self):
        """Updates GraceTHD project configuration."""

        qecu = QgsExpressionContextUtils
        var_dict = {
            'bp_layer': self.ui.bpeBox,
            'cm_layer': self.ui.cheminementBox,
            'st_layer': self.ui.sitetechBox,
            'sf_layer': self.ui.sufBox,
            'cb_layer': self.ui.cableBox,
            'pt_layer': self.ui.ptechBox,
            'bp_layer_id': self.ui.bpeIdBox,
            'cm_layer_id': self.ui.cheminementIdBox,
            'st_layer_id': self.ui.sitetechIdBox,
            'sf_layer_id': self.ui.sufIdBox,
            'cb_layer_id': self.ui.cableIdBox,
            'pt_layer_id': self.ui.ptechIdBox,
            'splicy_proto': self.ui.splicyProtoEdit,
            'splicy_port': self.ui.splicyPortEdit,
            'splicy_api_port': self.ui.splicyApiPortEdit,
            'splicy_dbname': self.ui.splicyDbnameEdit,
            'splicy_server': self.ui.splicyServerEdit,
            'splicy_user_token': self.ui.splicyUserTokenEdit,
            'debug_logging': self.ui.enableLoggingDebugCheckbox,
            'stdout_logging': self.ui.stdoutLoggingCheckbox,
        }
        boolean_dict = {}
        splicy_params = {}

        for key, widget in var_dict.items():
            if hasattr(widget, 'currentText'):
                val = widget.currentText()
                if key != 'splicy_proto' and '_id' not in key and val != '':
                    # This is a layer, store actual id
                    val = self.reversed_layer_dict[val]

            elif hasattr(widget, 'checkState'):
                val = boolean_dict[key] = widget.checkState()

            else:
                val = widget.text()

            key_list = (
                'splicy_port', 'splicy_dbname',
                'splicy_server', 'splicy_proto',
                'splicy_api_port', 'splicy_user_token',
            )
            if key in key_list:
                splicy_params[key] = val

            if val == '' and key not in key_list:
                continue

            if MAJOR_VERSION == '3':
                qecu.setProjectVariable(QgsProject.instance(), key, val)
            else:
                qecu.setProjectVariable(key, val)

        splicy_url = (
            "{splicy_proto}://{splicy_server}:{splicy_port}/{splicy_dbname}"
            .format(**splicy_params)
        )
        if MAJOR_VERSION == '3':
            qecu.setProjectVariable(
                QgsProject.instance(), "splicy_url", splicy_url
            )
        else:
            qecu.setProjectVariable("splicy_url", splicy_url)

        if boolean_dict['debug_logging'] == 2:
            logger_enable_debug()
        else:
            logger_disable_debug()

        if boolean_dict['stdout_logging'] == 2:
            logger_enable_stdout()
        else:
            logger_disable_stdout()

        # Fetch selected layers
        selected_layer_id_list = []
        for layer_row in range(self.ui.selectedListWidget.count()):
            list_item = self.ui.selectedListWidget.item(layer_row)
            layer_name = list_item.text()
            layer_id = self.reversed_layer_dict[layer_name]
            selected_layer_id_list.append(layer_id)

        # Unconfigure edit form for layers
        for layer in self.map_layers.values():
            if not isinstance(layer, QgsVectorLayer):
                continue
            if layer.id() in selected_layer_id_list:
                layer.setCustomProperty('delegated', 'true')
            else:
                layer.setCustomProperty('delegated', 'false')

        self.parent.refreshLayerDelegation()

        self.close()
