# -*- coding: utf-8 -*-
"""
/***************************************************************************
 Splicy
                                 A QGIS plugin
 Enhanced data manipulation between Qgis, PostGIS and a Web Server
                              -------------------
        begin                : 2017-04-20
        git sha              : $Format:%H$
        copyright            : (C) 2017 by CADaGEO
        email                : nicolas.fez@cadageo.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

try:
    from qgis.PyQt.QtGui import QColor
except ImportError:
    from PyQt4.QtGui import QColor
from qgis.gui import QgsRubberBand


class SplicyActions:
    """SplicyActions implementation.
    Executes Splicy actions triggered by Splicy.
    """

    def __init__(self, iface):
        """Constructor.

        :param iface: The Qgis interface.
        :type iface: QgisInterface
        """

        # Initializing class variables.
        self.iface = iface
        self.sourceEvid = {}

    def setActiveLayer(self, layerName):
        """Sets the active layer to the layer selected.

        :param layerName: The name of the layer to select.
        :type layerName: string
        """
        mapCanvas = self.iface.mapCanvas()
        for layer in mapCanvas.layers():
            if layer.name() == layerName:
                self.iface.setActiveLayer(layer)
                mapCanvas.setCurrentLayer(layer)
                return

    def setAttributesSelected(self, jsonArtifact):
        """Action select an element.

        :param jsonArtifact: the json artifact which contains the needed values.
        :type jsonArtifact: dict, string
        """
        self.setActiveLayer(jsonArtifact['layerName'])
        activeLayer = self.iface.activeLayer()
        selectedFeature = None
        element = jsonArtifact['element']
        for feature in activeLayer.getFeatures():
            if str(feature.attributes()[0]) == element[0]:
                selectedFeature = feature.id()
                break
        if selectedFeature is None:
            return
        activeLayer.select([selectedFeature])
        self.iface.actionZoomToLayer().trigger()
        self.iface.mapCanvas().selectionChanged.emit(activeLayer)

    def setAttributesDeselected(self, jsonArtifact):
        """Action deselect an element.

        :param jsonArtifact: the json artifact which contains the needed values.
        :type jsonArtifact: dict, string
        """
        self.setActiveLayer(jsonArtifact['layerName'])
        activeLayer = self.iface.activeLayer()
        selectedFeature = None
        element = jsonArtifact['element']
        for feature in activeLayer.getFeatures():
            if str(feature.attributes()[0]) == element[0]:
                selectedFeature = feature.id()
                break
        if selectedFeature is None:
            return
        activeLayer.deselect([selectedFeature])
        self.iface.actionZoomToLayer().trigger()
        self.iface.mapCanvas().selectionChanged.emit(activeLayer)

    def setLayerSelected(self, jsonArtifact):
        """Action select a layer.

        :param jsonArtifact: The json artifact which contains the needed values.
        :type jsonArtifact: dict, string
        """
        self.setActiveLayer(jsonArtifact['layerName'])

    def identifyCables(self, jsonArtifact):
        """Action identify cables.

        :param jsonArtifact: The json artifact which contains the needed values.
        :type jsonArtifact: dict, string
        """
        table = None
        element = None
        cableName = None
        color = None
        for layer in self.iface.mapCanvas().layers():
            if layer.name() == jsonArtifact['table']:
                table = layer
                break
        if table is None:
            return
        for el in jsonArtifact['elements']:
            for feature in table.getFeatures():
                if feature.attributes()[0] == el:
                    element = feature
                    cableName = el
                    color = jsonArtifact['elements'][el]['color']
                    break
            if element is None:
                return
            code = cableName
            if code in self.sourceEvid:
                self.sourceEvid[code].reset()
            color = color.replace('#', '')
            color = bytearray.fromhex(color)
            self.sourceEvid[code] = QgsRubberBand(self.iface.mapCanvas())
            self.sourceEvid[code].setColor(QColor(color[0], color[1], color[2], 255))
            self.sourceEvid[code].setWidth(5)
            self.sourceEvid[code].setToGeometry(element.geometry(), table)
        self.iface.elementSelected.emit()

    def selectBpe(self, jsonArtifact):
        """Action identify a BPE.

        :param jsonArtifact: The json artifact which contains the needed values.
        :type jsonArtifact: dict, string
        """
        table = None
        element = None
        for layer in self.iface.mapCanvas().layers():
            if layer.name() == jsonArtifact['table']:
                table = layer
                break
        if table is None:
            return
        for feature in table.getFeatures():
            if feature.attributes()[0] == jsonArtifact['element']:
                element = feature
                break
        if element is None:
            return
        code = jsonArtifact['element']
        if code in self.sourceEvid:
            self.sourceEvid[code].reset()
        self.sourceEvid[code] = QgsRubberBand(self.iface.mapCanvas())
        self.sourceEvid[code].setColor(QColor(0, 255, 0, 255))
        self.sourceEvid[code].setWidth(10)
        self.sourceEvid[code].setToGeometry(element.geometry(), table)
        self.iface.elementSelected.emit()

    # TODO: Deprecate deselectBpe to deselectElements.

    def deselectBpe(self, jsonArtifact):
        """Action deselect elements.

        :param jsonArtifact: The json artifact which contains the needed values.
        :type jsonArtifact: dict, string
        """

        code = jsonArtifact['element']
        if code in self.sourceEvid:
            self.sourceEvid[code].reset()

    def deselectElements(self, jsonArtifact):
        """Action deselect elements.

        :param jsonArtifact: The json artifact which contains the needed values.
        :type jsonArtifact: dict, string
        """
        for el in jsonArtifact['elements']:
            if el in self.sourceEvid:
                self.sourceEvid[el].reset()

    def zoomElement(self, jsonArtifact):
        """Action zoom element.

        :param jsonArtifact: The json artifact which contains the needed values.
        :type jsonArtifact: dict, string
        """
        table = None
        element = None
        for layer in self.iface.mapCanvas().layers():
            if layer.name() == jsonArtifact['table']:
                table = layer
                break
        if table is None:
            return
        for feature in table.getFeatures():
            if feature.attributes()[0] == jsonArtifact['element']:
                element = feature
                break
        if element is None:
            return
        self.iface.zoomElementLayer = table
        self.iface.zoomElementFeatureId = element.id()
        self.iface.elementZoomed.emit()

    def getElementAttributes(self, jsonArtifact):
        """Action get element attributes.

        :param jsonArtifact: The json artifact which contains the needed values.
        :type jsonArtifact: dict, string
        """
        table = None
        try:
            for layer in QgsMapLayerRegistry.instance().mapLayers().values():
                if layer.name() == jsonArtifact['layerName']:
                    table = layer
                    break
            if table is None:
                return
            for feature in table.getFeatures():
                if feature.attributes()[0] == jsonArtifact['element']:
                    self.iface.elementAttributes = feature
                    self.iface.elementAttributesAsked.emit()
                    break
        except:
            for layer in QgsProject.instance().mapLayers().values():
                if layer.name() == jsonArtifact['layerName']:
                    table = layer
                    break
            if table is None:
                return
            for feature in table.getFeatures():
                if feature.attributes()[0] == jsonArtifact['element']:
                    self.iface.elementAttributes = feature
                    self.iface.elementAttributesAsked.emit()
                    break

    # TODO: Deprecate deselectBpe to deselectElements.

    def resetColoration(self):
        """Action reset coloration"""
        for key, value in self.sourceEvid.items():
            value.reset()

    def refreshSplicy(self):
        """Refreshes the plugin"""
        self.iface.splicyRefreshed.emit()

    def clientConnected(self):
        """Triggered when the client is connected"""
        self.iface.clientConnected.emit()

    def clientConnectError(self):
        """Trigger when the client can't connect"""
        self.iface.clientConnectError.emit()

    def serverConnectError(self):
        """Triggered when the server couldn't connect"""
        self.iface.serverConnectError.emit()

    def serverDisconnected(self):
        """Triggered when the server is disconnected"""
        self.iface.serverDisconnected.emit()

    def changeSession(self):
        """Triggered when the socketIO session has changed"""
        self.iface.sessionChanged.emit()
