# -*- coding: utf-8 -*-
"""
/***************************************************************************
 Splicy
                                 A QGIS plugin
 Enhanced data manipulation between Qgis, PostGIS and a Web Server
                              -------------------
        begin                : 2017-04-20
        git sha              : $Format:%H$
        copyright            : (C) 2017 by CADaGEO
        email                : nicolas.fez@cadageo.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

# Common imports
import os
import uuid
import webbrowser

# Importing every Qt Libraries that are needed.
try:
    from qgis.core import Qgis
except ImportError:
    from qgis.core import QGis as Qgis

# from PyQt4 import uic
#from qgis.core import *     # NOQA
#from qgis.utils import *    # NOQA
#from qgis.gui import *      # NOQA
from qgis.gui import QgsRubberBand

MAJOR_VERSION, MINOR_VERSION, _ = Qgis.QGIS_VERSION.split('.')[:3]

if MAJOR_VERSION == '3':
    from PyQt5.QtCore import (
        QObject, QSettings, QTranslator, qVersion, QCoreApplication
    )
    from PyQt5.QtGui import QIcon, QColor
    from PyQt5.QtWidgets import QAction
    from qgis.PyQt.QtCore import pyqtSignal
    from qgis.core import QgsProject, QgsVectorLayer
    from qgis._core import QgsExpressionContextUtils

    from .splicy_settings_dialog import SplicySettingsDialog
    from .splicy_socketIO_client import SocketIOClient
    from .splicy_utils import get_logger
    from .resources_5_rc import qInitResources   # NOQA
else:
    from PyQt4.QtCore import *  # NOQA
    from PyQt4.QtGui import *   # NOQA
    from PyQt4.QtGui import QAction, QIcon, QColor
    from PyQt4.QtCore import (
        QObject, pyqtSignal, QTranslator, QSettings, QCoreApplication,
        qVersion,
    )
    from resources_4_rc import qInitResources   # NOQA
    from qgis.core import (
        QgsProject, QgsExpressionContextUtils, QgsMapLayerRegistry,
        QgsVectorLayer,
    )
    from qgis.gui import QgsMessageBar

    from splicy_settings_dialog import SplicySettingsDialog
    from splicy_socketIO_client import SocketIOClient
    from splicy_utils import get_logger


plugin_instance = None
plugin_dirname = os.path.dirname(__file__)


CABLE_COLOR_LIST = [
    '#8dd3c7',
    '#bebada',
    '#fb8072',
    '#80b1d3',
    '#fdb462',
    '#b3de69',
    '#fccde5',
    '#d9d9d9',
    '#bc80bd',
    '#ccebc5',
    '#ffed6f',
    '#ffffb3',
]


class Splicy(QObject):
    """QGIS Plugin Implementation."""

    # Declaration of every signal callable by the client thread.
    elementSelected = pyqtSignal()
    elementZoomed = pyqtSignal()
    elementAttributesAsked = pyqtSignal()
    splicyRefreshed = pyqtSignal()
    clientConnected = pyqtSignal()
    clientConnectError = pyqtSignal()
    sessionChanged = pyqtSignal()

    def __init__(self, iface):
        """Constructor.

        :param iface: An interface instance that will be passed to this class
            which provides the hook by which you can manipulate the QGIS
            application at run time.
        :type iface: QgsInterface
        """
        QObject.__init__(self)
        self.logger = get_logger()
        self.logger.debug("======== Plugin init ========")

        # Declaring instance variables.
        self.iface = iface
        self.actions = []
        self.menu = self.tr(u'&Splicy')
        self.toolbar = self.iface.addToolBar(u'Splicy')
        self.toolbar.setObjectName(u'Splicy')

        self.pluginIsActive = False
        self.dockwidget = None
        self.settings_dialog = None
        self.connected_to_splicy = False
        self.waiting_for_stop = self.waiting_for_start = False
        self.socket_client = None
        self._layers_dict = {}
        self._feature_cache = {}
        self.selected_dict = {
            'bp': [],
            'st': [],
            'cb': [],
            'sf': [],
            'cm': [],
            'pt': [],
        }
        self.highlighted_feature_dict = {}
        self.added_feature_dict = {}

        global plugin_instance
        plugin_instance = self

        if MAJOR_VERSION == '3':
            self.instance = QgsProject.instance()
        else:
            self.instance = QgsMapLayerRegistry.instance()

        self.setupI8N()
        self.connect_signals()
        self.updateLayerDict()
        self.session_id = uuid.uuid4()

        layer_list = self.instance.mapLayers().values()
        for layer in layer_list:
            self._layers_dict[layer.id()] = layer

    def getProjectScope(self):
        if MAJOR_VERSION == '3':
            return QgsExpressionContextUtils.projectScope(self.instance)
        else:
            return QgsExpressionContextUtils.projectScope()

    def setupI8N(self):
        # Initializing locale.
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            plugin_dirname,
            'i18n',
            'splicy_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)

            if qVersion() > '4.3.3':
                QCoreApplication.installTranslator(self.translator)

    def tr(self, message):
        """Gets the translation for a string using Qt translation API.

        :param message: String for translation.
        :type message: str, QString

        :returns: Translated version of message.
        :rtype: QString
        """
        return QCoreApplication.translate('Splicy', message)

    def connect_signals(self):
        iface = self.iface

        # Assigning signals to corresponding function.
        iface.elementSelected = self.elementSelected
        iface.elementZoomed = self.elementZoomed
        iface.elementAttributesAsked = self.elementAttributesAsked
        iface.splicyRefreshed = self.splicyRefreshed
        iface.sessionChanged = self.sessionChanged

        iface.elementSelected.connect(self.refreshCanvas)
        iface.splicyRefreshed.connect(self.refreshSplicy)
        iface.sessionChanged.connect(self.changeSession)

        # SocketIO connection signals
        iface.clientConnected = self.clientConnected
        iface.clientConnectError = self.clientConnectError

        iface.clientConnected.connect(self.onClientConnect)
        iface.clientConnectError.connect(self.onClientConnectError)

        iface.mapCanvas().selectionChanged.connect(self.onSelectionChanged)

        self.instance.layersAdded.connect(self.onLayersAdded)

        # Enable plugin icons only if a project has been loaded
        # QgsProject.instance() cannot be replaced by self.instance
        # (qgis2 compat)
        QgsProject.instance().readProject.connect(self.enable_plugin)

    def enable_plugin(self, *args, **kwargs):
        for action in self.actions[1:]:
            if not action.isEnabled():
                action.setEnabled(True)

    def add_action(self, icon_path, text, callback, enabled_flag=False,
                   add_to_menu=True, add_to_toolbar=True, status_tip=None,
                   whats_this=None, parent=None):
        """Adds a toolbar icon to the toolbar.

        :param icon_path: Path to the icon for this action. Can be a resource
            path (e.g. ':/plugins/foo/bar.png') or a normal file system path.
        :type icon_path: str

        :param text: Text that should be shown in menu items for this action.
        :type text: str

        :param callback: Function to be called when the action is triggered.
        :type callback: function

        :param enabled_flag: A flag indicating if the action should be enabled
            by default. Defaults to True.
        :type enabled_flag: bool

        :param add_to_menu: Flag indicating whether the action should also
            be added to the menu. Defaults to True.
        :type add_to_menu: bool

        :param add_to_toolbar: Flag indicating whether the action should also
            be added to the toolbar. Defaults to True.
        :type add_to_toolbar: bool

        :param status_tip: Optional text to show in a popup when mouse pointer
            hovers over the action.
        :type status_tip: str

        :param parent: Parent widget for the new action. Defaults None.
        :type parent: QWidget

        :param whats_this: Optional text to show in the status bar when the
            mouse pointer hovers over the action.

        :returns: The action that was created. Note that the action is also
            added to self.actions list.
        :rtype: QAction
        """
        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            self.toolbar.addAction(action)

        if add_to_menu:
            self.iface.addPluginToWebMenu(self.menu, action)

        self.actions.append(action)

        return action

    def initGui(self):
        """Creates the menu entries and toolbar icons inside the QGIS GUI."""
        # Only enable actions if we have layers (and a qgs file open)
        enabled = len(self._layers_dict) > 0

        # Creating Splicy dockwidget toolbar icon.
        self.add_action(
            ':/plugins/splicy/img/icon.png',
            text=self.tr(u'Ouvrir Splicy dans le navigateur'),
            callback=self.open_splicy_browser,
            parent=self.iface.mainWindow(),
            enabled_flag=False,
        )

        self.add_action(
            ':/plugins/splicy/img/icon_disconnected.png',
            text=self.tr(u'Démarrer Splicy'),
            callback=self.toggle_socketio,
            parent=self.iface.mainWindow(),
            enabled_flag=enabled,
        )

        # Creating the 'showAttributesTable' action toolbar icon.
        self.add_action(
            ':/plugins/splicy/img/settings.png',
            text=self.tr(u'Paramètres Splicy'),
            callback=self.runDockwidget,
            parent=self.iface.mainWindow(),
            enabled_flag=enabled,
        )

    def onClosePlugin(self):
        """Cleanup necessary items here when plugin dockwidget is closed"""
        # Disconnecting the plugin.
        self.dockwidget.closingPlugin.disconnect(self.onClosePlugin)
        self.pluginIsActive = False

    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        self.logger.debug("================== Unload plugin")
        global plugin_instance
        plugin_instance = None

        # Removing every actions.

        for action in self.actions:
            self.iface.removePluginWebMenu(
                self.tr(u'&Splicy'),
                action)
            self.iface.removeToolBarIcon(action)

        # Disconnecting running processes.

        if self.socket_client is not None:
            self.logger.debug("Stopping socket io client")
            self.stop_client()

        # Removing the toolbar.

        del self.toolbar

    def hasLayer(self, layer_id):
        return layer_id in self._layers_dict

    def getLayer(self, layer_id):
        return self._layers_dict[layer_id]

    def updateLayerDict(self):
        if MAJOR_VERSION == '2':
            values = QgsMapLayerRegistry.instance().mapLayers().values()
        else:
            values = QgsProject.instance().mapLayers().values()

        self._layers_dict = {
            layer.id(): layer
            for layer in values
        }

    def toggle_socketio(self):
        """Launches the whole solution."""
        self.logger.debug('Toggle socketIO')
        if self.waiting_for_stop or self.waiting_for_start:
            self.logger.debug(
                'Aborting because: waiting for stop is '
                '{stop}, waiting for start is {start}'.format(
                    stop=self.waiting_for_stop, start=self.waiting_for_start
                )
            )
            return

        if self.connected_to_splicy:
            self.logger.debug('SplicyClient already started')
            if not self.waiting_for_stop:
                self.logger.debug('... waiting for stop')
                self.waiting_for_stop = True
                self.stop_client()
        else:
            if not self.waiting_for_start:
                self.logger.debug('start client')
                self.start_client()
                self.waiting_for_start = True

    def start_client(self):
        """
            Stops the current connection with the server and starts a new one.
        """
        # Checking if an instance of SplicyClient is already running.
        if self.socket_client is not None:
            self.logger.debug('Another splicyclient instance is running, stop')
            self.stop_client()

        self.socket_client = SocketIOClient(
            self.getProjectScope(),
            session_id=self.session_id,
            logger=self.logger,
        )
        socket_client = self.socket_client
        socket_client.clientConnectError.connect(self.onClientConnectError)
        socket_client.clientConnectQuitting.connect(
            self.onClientConnectQuitting
        )
        socket_client.clientDisconnected.connect(self.onClientDisconnected)
        socket_client.clientConnected.connect(self.onClientConnect)
        socket_client.zoomToFeature.connect(self.onZoomToFeature)
        socket_client.highlightFeature.connect(self.onHighlightFeature)
        socket_client.dehighlightFeature.connect(self.onDehighlightFeature)
        socket_client.colorizeEbpCables.connect(self.onColorizeEbpCables)
        socket_client.sendSelected.connect(self.sendSelected)
        socket_client.decolorizeEbpCables.connect(self.onDecolorizeEbpCables)
        socket_client.geomidDehighlight.connect(self.onGeomidDehighlight)
        self.logger.debug('socket_client.start')
        self.socket_client.start()

    def stop_client(self):
        """Stops the current connection with the server."""
        self.connected_to_splicy = False
        self.logger.debug('socket_client.stop')
        self.socket_client.stop()

    def messageBarWarning(self, message):
        if MAJOR_VERSION == '3':
            self.iface.messageBar().pushMessage(
                "Avertissement", message, level=Qgis.Warning, duration=3,
            )
        else:
            self.iface.messageBar().pushMessage(
                "Avertissement", message,
                level=QgsMessageBar.WARNING, duration=3,
            )

    def messageBarInfo(self, message):
        if MAJOR_VERSION == '3':
            self.iface.messageBar().pushMessage(
                "Info", message, level=Qgis.Info, duration=3,
            )
        else:
            self.iface.messageBar().pushMessage(
                "Info", message, level=QgsMessageBar.INFO, duration=3,
            )

    def messageBarError(self, message):
        if MAJOR_VERSION == '3':
            self.iface.messageBar().pushMessage(
                "Erreur", message, level=Qgis.Critical, duration=3,
            )
        else:
            self.iface.messageBar().pushMessage(
                "Erreur", message, level=QgsMessageBar.CRITICAL, duration=3,
            )

    def onClientConnect(self):
        self.connected_to_splicy = True

        run_action = self.actions[1]
        run_action.setIcon(QIcon(":/plugins/splicy/img/icon_connected.png"))
        run_action.setToolTip(self.tr(u'Arrêter Splicy'))

        self.messageBarInfo('La connexion vers Splicy est active')

        open_browser_action = self.actions[0]
        open_browser_action.setEnabled(True)

        self.open_splicy_browser()
        self.waiting_for_start = False
        self.refreshLayerDelegation()

    def open_splicy_browser(self):
        project_scope = self.getProjectScope()
        self.logger.debug('Open browser on splicy')
        if project_scope.hasVariable('splicy_url'):
            value = project_scope.variable('splicy_url')
            self.logger.debug('.. url is {url}'.format(url=value))
            webbrowser.open(value, new=2)

    def onClientConnectError(self, error_code):
        message = u"Problème de connexion à Splicy (code erreur : {})"
        self.messageBarWarning(message.format(error_code))

    def onClientConnectQuitting(self):
        self.waiting_for_start = False

    def onClientDisconnected(self):
        self.logger.debug('on serverDisconnect')
        self.connected_to_splicy = False

        run_action = self.actions[1]
        run_action.setIcon(QIcon(":/plugins/splicy/img/icon_disconnected.png"))
        run_action.setToolTip(self.tr(u'Démarrer Splicy'))

        self.messageBarInfo('La connexion vers Splicy est inactive')

        open_browser_action = self.actions[0]
        open_browser_action.setEnabled(False)

        self.logger.debug('self.waiting_for_stop to False')
        self.waiting_for_stop = False
        self.socket_client = None
        self.refreshLayerDelegation()

    def getSelectionArrayByLayer(self, layer, prefix=None):
        """Retrieves every selected feature from the layer passed as parameter.

        :param layer: The layer to analyze.
        :type layer: QgsVectorLayer


        :returns selectionArray: A list containing every selected feature.
        :rtype: list, str
        """

    def refreshSplicy(self):
        """
        Sends a socketIO message containing data to every clients connected
        to the current Qgis session
        """
        # Refreshing the web client.
        self.sendSelected()

    def sendSelected(self):
        """Sends the selected features to Splicy

        :param box: The name of the box to analyze.
        :type box: string
        """
        # Getting the active layer and catch possible errors.
        # Find correspondance with config
        if self.socket_client is None:
            return

        jsonArtifact = {
            'command': 'selectedFeatures',
            'params': {
                'selected_dict': self.selected_dict,
            },
        }

        # Sending the artifact
        self.socket_client.emit(jsonArtifact)

    def getPrefixFromLayer(self, layer):
        project_scope = self.getProjectScope()
        for prefix in self.selected_dict.keys():
            if project_scope.hasVariable(prefix + '_layer'):
                if project_scope.variable(prefix + '_layer') == layer.id():
                    return prefix

        return None

    def onFeatureDeleted(self, feature_id):
        self.onSelectionChanged(self.sender())

    def onSelectionChanged(self, layer):
        """Triggered when the selection is changed in the Qgis canvas

        :param layer: The layer on which the selection changed.
        :type layer: QgsVectorLayer
        """
        prefix = self.getPrefixFromLayer(layer)
        project_scope = self.getProjectScope()

        if prefix is None:
            self.logger.debug("Layer prefix is None")
            return

        if prefix and project_scope.hasVariable(str(prefix) + '_layer_id'):
            id_field = project_scope.variable(str(prefix) + '_layer_id')
        else:
            self.logger.debug("Couldn't find layer prefix")
            return None

        self.selected_dict[prefix] = []
        layer_fields = None
        for index, selected_feature in enumerate(layer.selectedFeatures()):
            if layer_fields is None:
                layer_fields = selected_feature.fields()
            if index > 20:
                break

            if len(selected_feature.fields()) == 0:
                continue

            feature_dict = {
                'code': (
                    selected_feature[id_field]
                    if selected_feature[id_field] else ''
                ),
            }

            if layer_fields.indexFromName(prefix + 'codeext') >= 0:
                feature_dict['codeext'] = (
                    selected_feature[prefix + '_codeext']
                    if selected_feature[prefix + '_codeext'] else ''
                )
            if layer_fields.indexFromName(prefix + '_etiquet') >= 0:
                feature_dict['etiquet'] = (
                    selected_feature[prefix + '_etiquet']
                    if selected_feature[prefix + '_etiquet'] else ''
                )
            if layer_fields.indexFromName(prefix + '_nom') >= 0:
                feature_dict['nom'] = (
                    selected_feature[prefix + '_nom']
                    if selected_feature[prefix + '_nom'] else ''
                )
            self.selected_dict[prefix].append(feature_dict)
        self.sendSelected()

    def onLayersAdded(self, layers):
        # Update form code if needed
        for layer in layers:
            if not isinstance(layer, QgsVectorLayer):
                continue

            form_config = layer.editFormConfig()
            if form_config.initFunction() != "":
                layer.setCustomProperty('delegated', 'true')
                self.deconfigureLayerDelegationToSplicy(layer)

            layer.featureDeleted.connect(self.onFeatureDeleted)
            self._layers_dict[layer.id()] = layer
        self.enable_plugin()

    def refreshLayerDelegation(self):
        if MAJOR_VERSION == '3':
            values = QgsProject.instance().mapLayers().values()
        else:
            values = QgsMapLayerRegistry.instance().mapLayers().values()

        for layer in values:
            if not isinstance(layer, QgsVectorLayer):
                continue

            delegated = layer.customProperty('delegated') == 'true'
            if delegated and self.socket_client is not None:
                self.configureLayerDelegationToSplicy(layer)
            else:
                self.deconfigureLayerDelegationToSplicy(layer)

    def deconfigureLayerDelegationToSplicy(self, layer):
        form_config = layer.editFormConfig()
        form_config.setUiForm("")

        form_config.setInitFilePath("")
        form_config.setInitFunction("")
        form_config.setInitCode("")
        codesourceid = form_config.PythonInitCodeSource(0)
        form_config.setInitCodeSource(codesourceid)

        if MAJOR_VERSION == '3':
            layer.setEditFormConfig(form_config)

    def configureLayerDelegationToSplicy(self, layer):
        # self.logger.debug(u'Delegate to splicy {}'.format(layer.id()))

        ui_path = os.path.join(plugin_dirname, 'addfeature.ui')
        code_path = os.path.join(plugin_dirname, 'addfeature.py')

        form_config = layer.editFormConfig()

        form_config.setUiForm(ui_path)
        form_config.setInitFunction("my_form_open")
        with open(code_path) as handler:
            form_config.setInitCode(handler.read())
        codesourceid = form_config.PythonInitCodeSource(2)
        form_config.setInitCodeSource(codesourceid)
        layer.editingStopped.connect(self.dehighlightAll)

        if MAJOR_VERSION == '3':
            layer.setEditFormConfig(form_config)

    def dehighlightAll(self):
        on_layer = self.sender()
        for geomid, value in self.added_feature_dict.items():
            geom, qrb, layer, table = value

            if layer == on_layer:
                qrb.reset()
                layer.triggerRepaint()

    def showAttributeTable(self):
        """Opens the Qgis attributes table."""
        self.iface.showAttributeTable(self.iface.activeLayer())

    def refreshCanvas(self):
        """
            Refresh the Qgis map canvas.
            Called when the corresponding signal is triggered.
        """
        self.iface.mapCanvas().refresh()

    # #### Actions triggered from Splicy ####
    def getFeatureFromCode(self, feature_code, layer=None):
        # Find correct layer
        prefix = feature_code[:2]
        var_name = prefix.lower() + '_layer'
        project_scope = self.getProjectScope()

        if project_scope.hasVariable(var_name):
            layer_id = project_scope.variable(var_name)
        else:
            return None, None

        if layer is None:
            if self.hasLayer(layer_id):
                layer = self.getLayer(layer_id)
            else:
                message = "Couldn't find layer with id" + str(layer_id)
                self.messageBarWarning(message)
                return

        feature = self._feature_cache.get(feature_code, None)
        if feature is not None:
            return feature, layer

        for feature in layer.getFeatures():
            if feature.attributes()[0] == feature_code:
                self._feature_cache[feature_code] = feature
                return feature, layer

        return None, None

    def onZoomToFeature(self, params):
        """
            Zooms on a specific element.
            Called when the corresponding signal is triggered.

            :param params: params in the form of :
                { 'feature_code': <feature_code> }
        """

        feature_code = params['feature_code']
        feature, layer = self.getFeatureFromCode(feature_code)
        if feature is None:
            self.messageBarWarning(
                "Couldn't find feature: " + str(feature_code)
            )
            return

        self.zoom(feature, layer)

    def clearHighlightedFeatures(self):
        for rubber_band in self.highlighted_feature_dict.values():
            rubber_band.reset()
        self.highlighted_feature_dict = {}

    def zoom(self, feature, layer, level=800):
        self.iface.mapCanvas().zoomScale(800)
        self.iface.mapCanvas().zoomToFeatureIds(layer, [feature.id()])

    def highlight(self, feature, feature_code, layer, color_str=None):
        if color_str is None:
            color = QColor(0, 255, 0, 255)
        else:
            color = QColor(color_str)

        qrb = QgsRubberBand(self.iface.mapCanvas())
        qrb.setColor(color)
        qrb.setWidth(5)
        qrb.setToGeometry(feature.geometry(), layer)

        self.highlighted_feature_dict[feature_code] = qrb

        return qrb

    def dehighlight(self, feature_code):
        rubber_band = self.highlighted_feature_dict.get(feature_code, None)
        if rubber_band is None:
            return

        rubber_band.reset()
        self.highlighted_feature_dict.pop(feature_code)

    def onDehighlightFeature(self, params):
        """
            De-highlight a given feature
        """
        feature_code = params['feature_code']
        self.dehighlight(feature_code)

    def onHighlightFeature(self, params):
        """
            Highlight a given feature

            :param params: params in the form of :
                { '': <> }
        """
        feature_code = params['feature_code']
        feature, layer = self.getFeatureFromCode(feature_code)
        if feature is None:
            self.messageBarWarning("Couldn't find feature" + str(feature_code))
            return
#        self.clearHighlightedFeatures()

        # Might already be highlighted, avoid re-highlighting
        if feature_code not in self.highlighted_feature_dict:
            self.highlight(feature, feature_code, layer)

    def onDecolorizeEbpCables(self, params):
        for cb_code in params['cable_list']:
            self.dehighlight(cb_code)

    def onColorizeEbpCables(self, params):
        feature_code = params['feature_code']
        ebp, ebp_layer = self.getFeatureFromCode(params['feature_code'])
        if ebp is None:
            self.messageBarWarning("Couldn't find feature" + str(feature_code))
            return

#        self.clearHighlightedFeatures()

        # self.highlight(ebp, feature_code, ebp_layer)
        # No zoom for now
        # self.zoom(ebp, ebp_layer)

        cb_layer = None
        cb_list = []
        # First, find all cables (time consuming)
        for pos, cb_code in enumerate(params['cable_list']):
            if cb_layer is None:
                cable, cb_layer = self.getFeatureFromCode(cb_code)
            else:
                cable, _layer = self.getFeatureFromCode(cb_code, cb_layer)
            if cable is None:
                self.logger.debug("can't find cable {}".format(cb_code))
                continue
            color = CABLE_COLOR_LIST[pos % len(CABLE_COLOR_LIST)]
            cb_list.append((cb_code, cable, color))

        # Now that all cables are found, colorize all of them quickly
        for cb_code, cable, color in cb_list:
            self.highlight(cable, cb_code, cb_layer, color)

    def onGeomidDehighlight(self, params):
        if 'geomid' not in params:
            return

        geomid = params['geomid']
        geom, qrb, layer, table = (
            self.added_feature_dict.get(geomid, [None] * 4)
        )
        if qrb:
            qrb.reset()
            layer.triggerRepaint()

    def changeSession(self):
        """Changes the Qgis session thanks to socketIO"""

        if self.dockwidget is not None:
            self.dockwidget.sessionId.setText(
                'Identifiant de la session: '
            )

    def viewConfigured(self):
        """Checks that every needed view has already been configured"""
        project_scope = self.getProjectScope()
        long_condition = (
            project_scope.hasVariable('project_bpe') and
            len(project_scope.variable('project_bpe')) > 0 and
            project_scope.hasVariable('project_cable') and
            len(project_scope.variable('project_cable')) > 0
        )
        return long_condition

    def runDockwidget(self):
        """Run method that loads and starts the plugin"""

        # Checking if the dockwidget is currently running or not.

        if self.settings_dialog:
            self.settings_dialog.reject()

        self.settings_dialog = SplicySettingsDialog(parent=self)
        self.settings_dialog.open()
        self.settings_dialog.update_log_browser()


# ## WIP code
#        ########################################################
#        layer = self.iface.activeLayer()
#        logger.debug(list(QgsMapLayerRegistry.instance().mapLayers()))
#        a = QgsMapLayerRegistry.instance()
#        layer = a.mapLayers()["t_conduite20180220103438246"]
#        layer.selectAll()
#        c = layer.fields()
#        d = list(c)[0]
#        ########################################################
#
#        ########################################################
#        layer.selectedFeatureCount()
#        layer.selectedFeaturesId()
        ########################################################
