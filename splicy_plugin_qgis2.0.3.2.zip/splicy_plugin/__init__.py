# -*- coding: utf-8 -*-
"""
/***************************************************************************
 Splicy
                                 A QGIS plugin
 Enhanced data manipulation between QGis, PostGIS and a Web Server
                             -------------------
        begin                : 2017-04-20
        copyright            : (C) 2017 by CADaGEO
        email                : nicolas.fez@cadageo.com
        git sha              : $Format:%H$
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
 This script initializes the plugin, making it known to QGIS.
"""

import os
import sys
import stat
import subprocess
from subprocess import PIPE, Popen
try:
    from qgis.core import Qgis
except ImportError:
    from qgis.core import QGis as Qgis

MAJOR_VERSION, MINOR_VERSION, _ = Qgis.QGIS_VERSION.split('.')[:3]

subprocess_kwargs = {
    'shell': True,
}
if hasattr(subprocess, 'STARTUPINFO'):
    startupinfo = subprocess.STARTUPINFO()
    startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    subprocess_kwargs['startupinfo'] = startupinfo


def classFactory(iface):  # pylint: disable=invalid-name
    """Load Splicy class from file Splicy.

    :param iface: A QGIS interface instance.
    :type iface: QgsInterface
    """
    if MAJOR_VERSION == '3':
        from .splicy_main import Splicy
    else:
        from splicy_main import Splicy
    return Splicy(iface)
