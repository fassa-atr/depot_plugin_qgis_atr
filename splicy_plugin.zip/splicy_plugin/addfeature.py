import re
import os
import uuid
import functools
try:
    from qgis.core import Qgis
except ImportError:
    from qgis.core import QGis as Qgis

MAJOR_VERSION, MINOR_VERSION, _ = Qgis.QGIS_VERSION.split('.')[:3]

if MAJOR_VERSION == '3':
    from PyQt5.QtCore import QTimer
    from PyQt5.QtGui import QColor
    from PyQt5.QtWidgets import QDialog
    from qgis.core import QgsProject
    from qgis._core import QgsExpressionContextUtils
else:
    from PyQt4.QtCore import QTimer
    from PyQt4.QtGui import QColor, QDialog
    from qgis.core import QgsExpressionContextUtils

from splicy_plugin.splicy_main import plugin_instance
from qgis.gui import QgsRubberBand
import webbrowser


source_re_list = (
    r'.*table="gracethd"\."(.*)".*',
    r'.*table="quot;gracethd"quot;\."quot;(.*)"quot;.*',
)

table_correspondance = {
    'bp_code': 't_ebp',
    'nd_code': 't_noeud',
    'st_code': 't_sitetech',
    'cb_code': 't_cable',
    'cm_code': 't_cheminement',
    'sf_code': 't_suf',
    'pt_code': 't_ptech',
}


def close_dialog(dialog, *args, **kwargs):
    if dialog is not None:
        dialog.reject()


def my_form_open(form, layer, feature):
    geomid = "{}".format(uuid.uuid4())
    geom = feature.geometry()
    socket_client = plugin_instance.socket_client
    if MAJOR_VERSION == '2':
        project_scope = QgsExpressionContextUtils.projectScope()
    else:
        project_scope = QgsExpressionContextUtils.projectScope(
            QgsProject.instance()
        )

    if not project_scope.hasVariable('splicy_url'):
        return

    splicy_url = project_scope.variable('splicy_url')

    if geom is None:
        return

    model = None
    code_attr = None
    source = layer.source()
    for key, _model in table_correspondance.items():
        if key in source:
            model = _model
            code_attr = key
            break

    if socket_client is not None:
        if code_attr not in [field.name() for field in feature.fields()]:
            # FIXME: display user error
            return

        code = feature[code_attr]
        if isinstance(code, unicode):
            # We have a code: open feature
            uri = os.path.join(
                splicy_url, '{}/{}'.format(
                    model, code
                )
            )
        else:
            # We don't have a code: open create page
            canvas = form.parent().parent()
            qrb = QgsRubberBand(canvas)
            color = QColor('#FF00FF')
            qrb.setColor(color)
            qrb.setWidth(5)
            # Colorize added feature
            qrb.setToGeometry(feature.geometry(), layer)

            table = ""
            for source_re in source_re_list:
                match = re.match(source_re, layer.source())
                if match and match.groups():
                    table = match.groups()[0]
                    break

            if MAJOR_VERSION == '2':
                geometry = geom.exportToWkt()
            else:
                geometry = geom.asWkt()

            plugin_instance.socket_client.emit({
                'command': 'storeGeometry',
                'params': {
                    'geomid': geomid,
                    'geometry': geometry,
                    'tablename': table,
                }
            })
            plugin_instance.added_feature_dict[geomid] = (
                geometry, qrb, layer, table
            )

            uri = os.path.join(
                splicy_url, '{}/new?geomid={}'.format(
                    model, geomid
                )
            )

        webbrowser.open(uri, new=2)

    dialog = form
    # In qgis 3 the dialog is not the direct parent anymore
    for i in range(10):
        dialog = dialog.parent()
        if isinstance(dialog, QDialog):
            break
    temp_close_dialog = functools.partial(close_dialog, dialog)
    QTimer.singleShot(10, temp_close_dialog)
