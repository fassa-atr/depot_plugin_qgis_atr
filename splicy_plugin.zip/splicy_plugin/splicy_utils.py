import os
import sys
import logging
import tempfile

formatter = logging.Formatter(
    '%(asctime)s : %(levelname)s : %(message)s'
)


def logger_enable_debug():
    logger = logging.getLogger('splicy')
    logger.setLevel(logging.DEBUG)


def logger_disable_debug():
    logger = logging.getLogger('splicy')
    logger.setLevel(logging.CRITICAL)


def logger_enable_stdout():
    logger = logging.getLogger('splicy')
    already_has_stdout_handler = False

    for handler in logger.handlers:
        if isinstance(handler, logging.FileHandler):
            continue

        if isinstance(handler, logging.StreamHandler):
            already_has_stdout_handler = True

    if not already_has_stdout_handler:
        sh = logging.StreamHandler(sys.stdout)
        sh.setFormatter(formatter)
        logger.addHandler(sh)


def logger_disable_stdout():
    logger = logging.getLogger('splicy')
    stdout_handler = None

    for handler in logger.handlers:
        if isinstance(handler, logging.FileHandler):
            continue

        if isinstance(handler, logging.StreamHandler):
            stdout_handler = handler

    if stdout_handler:
        logger.handlers.remove(stdout_handler)


def get_logger():
    logger = logging.getLogger('splicy')
    logger.setLevel(logging.CRITICAL)

    if len(logger.handlers) == 0:
        tempdir = tempfile.gettempdir()

        fh = logging.FileHandler(
            filename=os.path.join(tempdir, 'splicy_plugin.log'),
            mode='w',
        )
        fh.setFormatter(formatter)
        logger.addHandler(fh)


    return logger


logger = get_logger()


if __name__ == '__main__':
    logger = get_logger()
    logger_enable_stdout()
    logger_enable_debug()

    logger.debug('test')
